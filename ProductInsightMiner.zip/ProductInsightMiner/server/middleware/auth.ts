import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';

// Extended request interface with user property
export interface AuthRequest extends Request {
  user?: {
    id: number;
    username: string;
    role: string;
  };
}

// Authentication middleware
export async function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    if (req.session && (req.session as any).userId) {
      const userId = (req.session as any).userId;
      const user = await storage.getUser(userId);
      
      if (user) {
        req.user = {
          id: user.id,
          username: user.username,
          role: user.role || 'user' // Default role if not set
        };
      }
    }
    
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    next(error);
  }
}

// Require authentication middleware
export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ message: 'Authentication required' });
  }
  
  next();
}

// Role-based authorization middleware
export function requireRole(roles: string[]) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    
    next();
  };
}

// Record analytics middleware
export async function analyticsMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    // Only log non-asset requests
    if (!req.path.match(/\.(js|css|ico|png|jpg|jpeg|gif|svg)$/)) {
      const ipAddress = req.ip || req.socket.remoteAddress || 'unknown';
      const userAgent = req.headers['user-agent'] || 'unknown';
      
      // Store analytics asynchronously (don't wait for it)
      storage.recordVisit({
        ipAddress,
        userAgent,
        path: req.path,
        duration: 0 // Duration will be updated on response finish if client supports it
      }).catch(err => {
        console.error('Error recording visit:', err);
      });
    }
    
    next();
  } catch (error) {
    console.error('Analytics middleware error:', error);
    next(); // Continue even if analytics recording fails
  }
}
