import { Request, Response, NextFunction } from 'express';
import { storage } from './storage';
import crypto from 'crypto';

// Generate a hash for a password
export function hashPassword(password: string): string {
  // In a production environment, use a proper salted hash
  // This is a simplified version for demo purposes
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Verify a password against a stored hash
export function verifyPassword(password: string, hash: string): boolean {
  const passwordHash = hashPassword(password);
  return passwordHash === hash;
}

// Interface for request with user
export interface AuthRequest extends Request {
  user?: {
    id: number;
    username: string;
    role: string;
  };
}

// Authentication middleware
export function authenticate(req: AuthRequest, res: Response, next: NextFunction) {
  // Check if user is authenticated via session
  if (req.session && (req.session as any).userId) {
    const userId = (req.session as any).userId;
    console.log(`Session contains userId: ${userId}`);
    return storage.getUser(userId)
      .then(user => {
        if (user) {
          console.log(`User authenticated successfully: ${user.username}`);
          req.user = {
            id: user.id,
            username: user.username,
            role: user.role
          };
          next();
        } else {
          console.log('User not found in database despite valid session. Clearing session.');
          // If user doesn't exist anymore, clear the session
          if (req.session) {
            req.session.destroy(err => {
              if (err) {
                console.error('Error destroying session:', err);
              }
            });
          }
          res.status(401).json({ message: 'Unauthorized' });
        }
      })
      .catch(err => {
        console.error('Error authenticating user:', err);
        res.status(500).json({ message: 'Internal server error' });
      });
  } else {
    console.log('No userId in session, returning unauthorized');
    res.status(401).json({ message: 'Unauthorized' });
  }
}

// Authorization middleware (role-based)
export function authorize(roles: string[]) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    
    if (roles.includes(req.user.role)) {
      next();
    } else {
      res.status(403).json({ message: 'Forbidden: Insufficient permissions' });
    }
  };
}

// Register a new user
export async function registerUser(username: string, email: string, password: string): Promise<boolean> {
  try {
    // Check if username or email already exists
    const existingUser = await storage.getUserByUsername(username);
    const existingEmail = await storage.getUserByEmail(email);
    
    if (existingUser) {
      throw new Error('Username already exists');
    }
    
    if (existingEmail) {
      throw new Error('Email already exists');
    }
    
    // Create new user with hashed password
    await storage.createUser({
      username,
      email,
      password: hashPassword(password),
      role: 'user',
      followedTeams: []
    });
    
    return true;
  } catch (error) {
    console.error('Error registering user:', error);
    throw error;
  }
}

// Login a user
export async function loginUser(username: string, password: string): Promise<number | null> {
  try {
    console.log(`Finding user by username: ${username}`);
    const user = await storage.getUserByUsername(username);
    
    if (!user) {
      console.log(`User not found: ${username}`);
      return null;
    }
    
    console.log(`User found: ${username} (ID: ${user.id}), verifying password`);
    // Log hashed version for debugging
    const hashedPassword = hashPassword(password);
    console.log(`Provided password hash: ${hashedPassword.substring(0, 10)}...`);
    console.log(`Stored password hash: ${user.password.substring(0, 10)}...`);
    
    if (verifyPassword(password, user.password)) {
      console.log(`Password verification successful for user: ${username}`);
      return user.id;
    }
    
    console.log(`Password verification failed for user: ${username}`);
    return null;
  } catch (error) {
    console.error('Error logging in user:', error);
    throw error;
  }
}
