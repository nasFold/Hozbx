import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { footballAPI } from './api/footballApi';

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  console.log('WebSocket server initialized');
  
  // Keep track of active matches for real-time updates
  let activeMatches: any[] = [];
  let connectedClients: WebSocket[] = [];
  
  // Fetch active matches initially and set up interval for updates
  const updateActiveMatches = async () => {
    try {
      const timezone = 'UTC'; // Default timezone
      
      // Try to get live matches first
      const liveMatches = await footballAPI.getEvents({ 
        match_live: '1',
        timezone
      });
      
      // Fallback to today's matches if no live matches
      if (!liveMatches || liveMatches.length === 0) {
        const today = new Date().toISOString().split('T')[0];
        const response = await footballAPI.getEvents({ 
          from: today,
          to: today,
          timezone
        });
        activeMatches = response;
      } else {
        activeMatches = liveMatches;
      }
      
      broadcastUpdates();
    } catch (error) {
      console.error('Error fetching active matches:', error);
    }
  };
  
  // Broadcast updates to all connected clients
  const broadcastUpdates = () => {
    const data = JSON.stringify({
      type: 'matchUpdate',
      matches: activeMatches,
      timestamp: new Date().toISOString()
    });
    
    connectedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  };
  
  // Initialize active matches
  updateActiveMatches();
  
  // Update matches every 5 seconds
  const updateInterval = setInterval(updateActiveMatches, 5000);
  
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    connectedClients.push(ws);
    
    // Send initial data immediately on connection
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'matchUpdate',
        matches: activeMatches,
        timestamp: new Date().toISOString()
      }));
    }
    
    // Handle client messages
    ws.on('message', (message) => {
      try {
        const parsedMessage = JSON.parse(message.toString());
        
        // Handle specific match requests
        if (parsedMessage.type === 'subscribeMatch' && parsedMessage.matchId) {
          handleMatchSubscription(ws, parsedMessage.matchId);
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      connectedClients = connectedClients.filter(client => client !== ws);
    });
    
    // Handle errors
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      connectedClients = connectedClients.filter(client => client !== ws);
    });
  });
  
  // Handle match-specific subscriptions
  async function handleMatchSubscription(ws: WebSocket, matchId: string) {
    try {
      // Fetch detailed match information
      const matchDetails = await footballAPI.getEvents({
        match_id: matchId,
        withPlayerStats: '1'
      });
      
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'matchDetail',
          matchId,
          data: matchDetails,
          timestamp: new Date().toISOString()
        }));
      }
    } catch (error) {
      console.error(`Error fetching match details for match ${matchId}:`, error);
    }
  }
  
  // Clean up interval when server closes
  return {
    close: () => {
      clearInterval(updateInterval);
    }
  };
}
