import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { WebSocketProvider } from "@/contexts/WebSocketContext";

// Pages
import HomePage from "@/pages/HomePage";
import MatchesPage from "@/pages/MatchesPage";
import MatchDetailPage from "@/pages/MatchDetailPage";
import LeaguesPage from "@/pages/LeaguesPage";
import LeagueDetailPage from "@/pages/LeagueDetailPage";
import TeamPage from "@/pages/TeamPage";
import PlayerPage from "@/pages/PlayerPage";
import NewsPage from "@/pages/NewsPage";
import NewsDetailPage from "@/pages/NewsDetailPage";
import SearchPage from "@/pages/SearchPage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";
import AccountPage from "@/pages/AccountPage";
import PinnedMatchesPage from "@/pages/PinnedMatchesPage";
import AdminPage from "@/pages/AdminPage";
import OwnerPage from "@/pages/OwnerPage";
import NotFound from "@/pages/not-found";

export default function App() {
  return (
    <WebSocketProvider>
      <div className="min-h-screen bg-background font-sans antialiased">
        <div className="relative flex min-h-screen flex-col pb-16 md:pb-0">
          <div className="flex-1">
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/matches" component={MatchesPage} />
              <Route path="/match/:id" component={MatchDetailPage} />
              <Route path="/leagues" component={LeaguesPage} />
              <Route path="/league/:id" component={LeagueDetailPage} />
              <Route path="/team/:id" component={TeamPage} />
              <Route path="/player/:id" component={PlayerPage} />
              <Route path="/news" component={NewsPage} />
              <Route path="/news/:slug" component={NewsDetailPage} />
              <Route path="/search" component={SearchPage} />
              <Route path="/login" component={LoginPage} />
              <Route path="/register" component={RegisterPage} />
              <Route path="/account" component={AccountPage} />
              <Route path="/pinned" component={PinnedMatchesPage} />
              <Route path="/admin" component={AdminPage} />
              <Route path="/owner" component={OwnerPage} />
              <Route component={NotFound} />
            </Switch>
          </div>
        </div>
        <Toaster />
      </div>
    </WebSocketProvider>
  );
}