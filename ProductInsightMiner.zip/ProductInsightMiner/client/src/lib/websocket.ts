let socket: WebSocket | null = null;
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;
const reconnectDelay = 3000; // 3 seconds

export type WebSocketListener = (event: MessageEvent) => void;
type WebSocketEventType = 'message' | 'open' | 'close' | 'error';

// Map of event types to listeners
const listeners: Map<WebSocketEventType, Set<(event: any) => void>> = new Map([
  ['message', new Set()],
  ['open', new Set()],
  ['close', new Set()],
  ['error', new Set()]
]);

export const connectWebSocket = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
      resolve();
      return;
    }
    
    try {
      // Determine WebSocket protocol based on page protocol
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      socket = new WebSocket(wsUrl);
      
      socket.onopen = (event) => {
        console.log('WebSocket connection established');
        reconnectAttempts = 0;
        notifyListeners('open', event);
        resolve();
      };
      
      socket.onmessage = (event) => {
        notifyListeners('message', event);
      };
      
      socket.onclose = (event) => {
        console.log('WebSocket connection closed');
        notifyListeners('close', event);
        
        // Attempt to reconnect if the connection was previously established
        if (reconnectAttempts < maxReconnectAttempts) {
          console.log(`Attempting to reconnect (${reconnectAttempts + 1}/${maxReconnectAttempts})...`);
          reconnectTimer = setTimeout(() => {
            reconnectAttempts++;
            connectWebSocket().catch(console.error);
          }, reconnectDelay);
        } else {
          console.log('Max reconnect attempts reached. Switching to polling fallback.');
          startPollingFallback();
        }
      };
      
      socket.onerror = (event) => {
        console.error('WebSocket error:', event);
        notifyListeners('error', event);
        reject(new Error('WebSocket connection error'));
      };
    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
      reject(error);
      startPollingFallback();
    }
  });
};

export const disconnectWebSocket = (): void => {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  
  if (socket) {
    socket.close();
    socket = null;
  }
  
  // Clear all listeners
  listeners.forEach(listenerSet => listenerSet.clear());
};

export const addWebSocketListener = (type: WebSocketEventType, listener: (event: any) => void): void => {
  const listenerSet = listeners.get(type);
  if (listenerSet) {
    listenerSet.add(listener);
  }
};

export const removeWebSocketListener = (type: WebSocketEventType, listener: (event: any) => void): void => {
  const listenerSet = listeners.get(type);
  if (listenerSet) {
    listenerSet.delete(listener);
  }
};

export const sendWebSocketMessage = (data: any): void => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(data));
  } else {
    console.warn('WebSocket is not connected. Message not sent:', data);
  }
};

export const subscribeToMatch = (matchId: string): void => {
  sendWebSocketMessage({
    type: 'subscribeMatch',
    matchId
  });
};

// Private helper function to notify all listeners of a specific event
const notifyListeners = (type: WebSocketEventType, event: any): void => {
  const listenerSet = listeners.get(type);
  if (listenerSet) {
    listenerSet.forEach(listener => {
      try {
        listener(event);
      } catch (error) {
        console.error(`Error in WebSocket ${type} listener:`, error);
      }
    });
  }
};

// Fallback polling mechanism when WebSocket fails
let pollingInterval: ReturnType<typeof setInterval> | null = null;
const pollingDelay = 5000; // 5 seconds

const startPollingFallback = (): void => {
  if (pollingInterval) {
    return;
  }
  
  console.log('Starting polling fallback mechanism');
  
  pollingInterval = setInterval(async () => {
    try {
      // Poll for live matches
      const response = await fetch('/api/football/events?match_live=1');
      if (response.ok) {
        const data = await response.json();
        
        // Simulate a WebSocket message event
        notifyListeners('message', {
          data: JSON.stringify({
            type: 'matchUpdate',
            matches: data,
            timestamp: new Date().toISOString()
          })
        });
      }
    } catch (error) {
      console.error('Error in polling fallback:', error);
    }
  }, pollingDelay);
};

export const stopPollingFallback = (): void => {
  if (pollingInterval) {
    clearInterval(pollingInterval);
    pollingInterval = null;
  }
};
