import { QueryFunction } from '@tanstack/react-query';

// Get user's timezone - hardcoded to Asia/Makassar per requirements
export const getUserTimezone = (): string => {
  return 'Asia/Makassar';
};

// Format date for API
export function formatDateForAPI(date: Date): string {
  try {
    // Pastikan objek date valid
    if (!(date instanceof Date) || isNaN(date.getTime())) {
      console.warn('Invalid date object provided to formatDateForAPI');
      // Fallback ke tanggal hari ini
      date = new Date();
    }

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  } catch (e) {
    console.error('Error in formatDateForAPI:', e);
    // Fallback ke format tanggal hari ini
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
}

// Helper untuk memparse tanggal dari string dengan aman
export function parseDateSafely(dateString: string): Date {
  try {
    // Handle format YYYY-MM-DD
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
      const [year, month, day] = dateString.split('-').map(Number);
      const date = new Date(year, month - 1, day);

      // Validasi hasil date
      if (!isNaN(date.getTime())) {
        return date;
      }
    }

    // Fallback, coba parse langsung
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      return date;
    }

    // Jika gagal, kembalikan tanggal saat ini
    console.warn(`Failed to parse date string: ${dateString}`);
    return new Date();
  } catch (e) {
    console.error(`Error parsing date string ${dateString}:`, e);
    return new Date();
  }
}

// Fungsi untuk mendapatkan tanggal awal untuk data historis (5 tahun ke belakang)
export function getHistoricalStartDate(): string {
  const currentDate = new Date();
  // Ambil 5 tahun ke belakang untuk data historis
  const startDate = new Date(currentDate);
  startDate.setFullYear(currentDate.getFullYear() - 5);

  // Gunakan tanggal 1 Januari untuk memastikan kita mendapatkan seluruh season
  startDate.setMonth(0); // January
  startDate.setDate(1);

  return formatDateForAPI(startDate);
}

// Fungsi untuk mendapatkan tanggal akhir untuk data future (2 tahun ke depan)
export function getFutureEndDate(): string {
  const currentDate = new Date();
  // Ambil 2 tahun ke depan untuk data masa depan
  const endDate = new Date(currentDate);
  endDate.setFullYear(currentDate.getFullYear() + 2);

  // Gunakan tanggal 31 Desember untuk memastikan kita mendapatkan seluruh season
  endDate.setMonth(11); // December
  endDate.setDate(31);

  return formatDateForAPI(endDate);
}

// Mendapatkan nama season berdasarkan tanggal
export function getCurrentSeasonName(): string {
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth();

  // Pada sepak bola, biasanya season dimulai Juli/Agustus dan berakhir Mei/Juni tahun berikutnya
  // Jika bulan saat ini Juli-Desember, maka seasonnya adalah tahun ini/tahun depan
  // Jika bulan saat ini Januari-Juni, maka seasonnya adalah tahun kemarin/tahun ini
  if (currentMonth >= 6) { // Juli-Desember
    return `${currentYear}/${currentYear + 1}`;
  } else { // Januari-Juni
    return `${currentYear - 1}/${currentYear}`;
  }
}

// Fungsi untuk mendapatkan rentang tanggal season saat ini
export function getCurrentSeasonDateRange(): { start: string, end: string } {
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth();

  // Tentukan apakah kita berada di awal musim (Juli-Desember) atau akhir musim (Januari-Juni)
  let seasonStart: Date, seasonEnd: Date;

  if (currentMonth >= 6) { // Juli-Desember (awal musim)
    seasonStart = new Date(currentYear, 6, 1); // 1 Juli tahun ini
    seasonEnd = new Date(currentYear + 1, 5, 30); // 30 Juni tahun depan
  } else { // Januari-Juni (akhir musim)
    seasonStart = new Date(currentYear - 1, 6, 1); // 1 Juli tahun lalu
    seasonEnd = new Date(currentYear, 5, 30); // 30 Juni tahun ini
  }

  return {
    start: formatDateForAPI(seasonStart),
    end: formatDateForAPI(seasonEnd)
  };
}

// Format time with user's locale and timezone (24-hour format)
export const formatTime = (timeString: string, dateString?: string): string => {
  if (!timeString) return '';

  try {
    // Get user's timezone
    const userTimezone = getUserTimezone();
    
    // Handle HH:MM format
    if (/^\d{2}:\d{2}$/.test(timeString)) {
      const [hours, minutes] = timeString.split(':').map(Number);
      
      // Create a date object with the correct date and time
      let dateObj;
      if (dateString && /^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
        // The API uses Asia/Makassar timezone for its responses
        // Create a date in that timezone first, then convert to user's timezone
        const serverTimezone = 'Asia/Makassar';
        
        // Create full ISO string with specific timezone
        // Note: We're not using Z (UTC) notation here since the time is in Asia/Makassar
        const dateTimeString = `${dateString}T${timeString}:00`;
        
        // Get the timezone offset differences
        const serverDate = new Date(dateTimeString);
        const serverOptions = new Intl.DateTimeFormat('en-US', { timeZone: serverTimezone }).format(serverDate);
        const userOptions = new Intl.DateTimeFormat('en-US', { timeZone: userTimezone }).format(serverDate);
        
        // If serverOptions and userOptions are different days, adjust accordingly
        dateObj = new Date(dateTimeString);
        
        // Log for detailed debugging
        console.log(`Server time (${serverTimezone}): ${serverOptions}`);
        console.log(`User time (${userTimezone}): ${userOptions}`);
      } else {
        // Otherwise use current date
        dateObj = new Date();
        dateObj.setHours(hours, minutes, 0, 0);
      }
      
      // Log for debugging
      console.log(`Time conversion: ${timeString} on ${dateString} => ${dateObj.toISOString()} in ${userTimezone}`);
      
      // Format the time using Intl.DateTimeFormat with the user's timezone (24-hour format)
      return new Intl.DateTimeFormat(undefined, {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
        timeZone: userTimezone
      }).format(dateObj);
    }
    
    // Try standard date parsing as fallback
    const date = new Date(timeString);
    if (isNaN(date.getTime())) {
      return timeString; // Return original if parsing fails
    }
    
    return new Intl.DateTimeFormat(undefined, {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: userTimezone
    }).format(date);
  } catch (error) {
    console.warn(`Error formatting time: ${timeString}, date: ${dateString}`, error);
    return timeString;
  }
};

// Format date with user's locale
export const formatDate = (dateString: string): string => {
  if (!dateString) return '';

  try {
    const userTimezone = getUserTimezone();
    
    // Check if the date is in YYYY-MM-DD format
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
      const [year, month, day] = dateString.split('-').map(Number);
      // Create date with timezone consideration (noon to avoid date boundary issues)
      const dateTimeString = `${dateString}T12:00:00`;
      const date = new Date(dateTimeString);
      
      if (isNaN(date.getTime())) {
        return dateString; // Return original if date is invalid
      }
      
      return new Intl.DateTimeFormat(undefined, {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        timeZone: userTimezone
      }).format(date);
    }
    
    // Try standard date parsing as fallback
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      return dateString; // Return original if parsing fails
    }
    
    return new Intl.DateTimeFormat(undefined, {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      timeZone: userTimezone
    }).format(date);
  } catch (error) {
    console.warn(`Error formatting date: ${dateString}`, error);
    return dateString;
  }
};

// Function to determine match status (live, upcoming, finished)
export const getMatchStatus = (match: any): 'live' | 'upcoming' | 'finished' => {
  // Check if the match is live
  if (match.match_live === '1') {
    return 'live';
  }
  
  // Check if the match is finished
  if (match.match_status === 'FT' || match.match_status === 'AP' || 
      match.match_status === 'Finished') {
    return 'finished';
  }
  
  // If not live or finished, it's upcoming
  return 'upcoming';
};

// Function to get the date time for a match for sorting
export const getMatchDateTime = (match: any): Date => {
  try {
    if (match.match_date && match.match_time) {
      // Create a date object from match date and time
      const dateTimeStr = `${match.match_date}T${match.match_time}:00`;
      const dateTime = new Date(dateTimeStr);
      if (!isNaN(dateTime.getTime())) {
        return dateTime;
      }
    }
    
    // Fallback to current date if parsing fails
    return new Date();
  } catch (error) {
    console.warn('Error parsing match date time', error);
    return new Date();
  }
};

// Function to sort matches in order of priority (live > upcoming > finished)
export const sortMatches = (matches: any[]): any[] => {
  if (!matches || !matches.length) return [];
  
  // Current time for comparison
  const now = new Date();
  
  return [...matches].sort((a, b) => {
    const statusA = getMatchStatus(a);
    const statusB = getMatchStatus(b);
    
    // First priority: sort by status (live > upcoming > finished)
    if (statusA !== statusB) {
      // Live matches always at the top
      if (statusA === 'live') return -1;
      if (statusB === 'live') return 1;
      
      // Upcoming matches above finished matches
      if (statusA === 'upcoming' && statusB === 'finished') return -1;
      if (statusA === 'finished' && statusB === 'upcoming') return 1;
    }
    
    // Second priority: sort by time within same status
    if (statusA === statusB) {
      if (statusA === 'live' || statusA === 'upcoming') {
        // Live or upcoming: earlier first
        return getMatchDateTime(a).getTime() - getMatchDateTime(b).getTime();
      } else if (statusA === 'finished') {
        // Finished: most recent first
        return getMatchDateTime(b).getTime() - getMatchDateTime(a).getTime();
      }
    }
    
    // Default case
    return 0;
  });
};

// Get relative time (e.g., "2 hours ago")
export const getRelativeTime = (dateString: string): string => {
  if (!dateString) return '';

  try {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.round(diffMs / 1000);
    const diffMin = Math.round(diffSec / 60);
    const diffHour = Math.round(diffMin / 60);
    const diffDay = Math.round(diffHour / 24);

    if (diffSec < 60) {
      return `${diffSec} second${diffSec === 1 ? '' : 's'} ago`;
    } else if (diffMin < 60) {
      return `${diffMin} minute${diffMin === 1 ? '' : 's'} ago`;
    } else if (diffHour < 24) {
      return `${diffHour} hour${diffHour === 1 ? '' : 's'} ago`;
    } else if (diffDay < 30) {
      return `${diffDay} day${diffDay === 1 ? '' : 's'} ago`;
    } else {
      return formatDate(dateString);
    }
  } catch (error) {
    return dateString;
  }
};

// Format date for H2H section (e.g., "Apr 10, 2023")
export const formatRelativeDate = (dateString: string): string => {
  if (!dateString) return '';

  try {
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  } catch (error) {
    return dateString;
  }
};

// API endpoints
export const API = {
  // Football data endpoints
  football: {
    countries: '/api/football/countries',
    leagues: '/api/football/leagues',
    teams: '/api/football/teams',
    players: '/api/football/players',
    standings: '/api/football/standings',
    events: '/api/football/events',
    h2h: '/api/football/h2h',
    topscorers: '/api/football/topscorers',
    odds: '/api/football/odds',
    predictions: '/api/football/predictions',
  },

  // News endpoints
  news: {
    list: '/api/news',
    detail: (slug: string) => `/api/news/${slug}`,
  },

  // User endpoints
  auth: {
    register: '/api/auth/register',
    login: '/api/auth/login',
    logout: '/api/auth/logout',
    me: '/api/auth/me',
  },

  // User teams endpoints
  user: {
    teams: '/api/user/teams',
    removeTeam: (teamId: string) => `/api/user/teams/${teamId}`,
    pinnedMatches: '/api/user/pinned-matches',
    removePinnedMatch: (matchId: string) => `/api/user/pinned-matches/${matchId}`,
  },

  // Admin endpoints
  admin: {
    news: {
      create: '/api/admin/news',
      update: (id: number) => `/api/admin/news/${id}`,
      delete: (id: number) => `/api/admin/news/${id}`,
    },
  },

  // Owner endpoints
  owner: {
    config: '/api/owner/config',
    analytics: {
      daily: '/api/owner/analytics/daily',
    },
    logs: '/api/owner/logs',
  },
};

// API request function
export async function apiRequest(
  method: string,
  url: string,
  data?: unknown,
): Promise<Response> {
  const options: RequestInit = {
    method,
    headers: data ? { 'Content-Type': 'application/json' } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: 'include',
  };

  const response = await fetch(url, options);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(
      errorData.message || `Request failed with status ${response.status}`
    );
  }

  return response;
}

// This function is already defined above, removing duplicate declaration

// Create query function with timezone
export const createQueryFn = <T>(url: string, params: Record<string, string> = {}): QueryFunction<T> => {
  return async ({ queryKey }) => {
    const timezone = getUserTimezone();
    const urlObj = new URL(window.location.origin + url);

    // Add timezone parameter
    urlObj.searchParams.append('timezone', timezone);

    // Log timezone being used
    console.log(`User time (${timezone}): ${new Date().toLocaleDateString('en-US', {timeZone: timezone, month: 'numeric', day: 'numeric', year: 'numeric'})}`);

    // Add other parameters
    Object.entries(params).forEach(([key, value]) => {
      if (value) {
        urlObj.searchParams.append(key, value);
      }
    });

    const response = await fetch(urlObj.toString(), {
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error(`Request failed with status ${response.status}`);
    }

    return await response.json();
  };
};