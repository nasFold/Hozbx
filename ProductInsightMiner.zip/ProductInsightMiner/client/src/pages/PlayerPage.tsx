import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams } from 'wouter';
import { API } from '@/lib/api';
import { Player } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function PlayerPage() {
  const { id } = useParams<{ id: string }>();
  
  // Fetch player data
  const { data: playerData, isLoading } = useQuery<Player[]>({
    queryKey: [API.football.players, { player_id: id }],
    queryFn: async () => {
      // Tambahkan parameter withTeam=true untuk mendapatkan data tim klub juga
      const response = await fetch(`${API.football.players}?player_id=${id}&withTeam=true`);
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      return response.json();
    },
    enabled: !!id,
  });
  
  const player = playerData?.[0];
  
  if (!id) {
    return (
      <PageContainer showBack title="Player Details">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Invalid Player</p>
          <p className="text-muted-foreground">No player ID was provided.</p>
        </div>
      </PageContainer>
    );
  }
  
  if (isLoading) {
    return (
      <PageContainer showBack title="Player Details">
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading player details..." />
        </div>
      </PageContainer>
    );
  }
  
  if (!player) {
    return (
      <PageContainer showBack title="Player Details">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Player not found</p>
          <p className="text-muted-foreground">The player you're looking for doesn't exist or has been removed.</p>
        </div>
      </PageContainer>
    );
  }
  
  // Calculate age from birthdate
  const getPlayerAge = (birthdate: string) => {
    if (!birthdate) return player.player_age;
    
    const bdate = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - bdate.getFullYear();
    const monthDiff = today.getMonth() - bdate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < bdate.getDate())) {
      age--;
    }
    
    return age.toString();
  };
  
  // Format player stats for charts
  const getPlayerStatsData = () => {
    const stats: {name: string, value: number}[] = [
      { name: 'Goals', value: parseInt(player.player_goals || '0') },
      { name: 'Assists', value: parseInt(player.player_assists || '0') },
      { name: 'Yellow Cards', value: parseInt(player.player_yellow_cards || '0') },
      { name: 'Red Cards', value: parseInt(player.player_red_cards || '0') },
      { name: 'Matches', value: parseInt(player.player_match_played || '0') }
    ];
    
    return stats;
  };
  
  // Format advanced stats
  const getAdvancedStatsData = () => {
    const stats: {name: string, value: number}[] = [];
    
    if (player.player_type === "Goalkeepers") {
      stats.push({ name: 'Saves', value: parseInt(player.player_saves || '0') });
      stats.push({ name: 'Clean Sheets', value: parseInt(player.player_goals_conceded || '0') === 0 ? 1 : 0 });
      stats.push({ name: 'Goals Conceded', value: parseInt(player.player_goals_conceded || '0') });
      stats.push({ name: 'Inside Box Saves', value: parseInt(player.player_inside_box_saves || '0') });
    } else {
      if (player.player_shots_total) stats.push({ name: 'Shots', value: parseInt(player.player_shots_total || '0') });
      if (player.player_passes) stats.push({ name: 'Passes', value: parseInt(player.player_passes || '0') });
      if (player.player_tackles) stats.push({ name: 'Tackles', value: parseInt(player.player_tackles || '0') });
      if (player.player_crosses_total) stats.push({ name: 'Crosses', value: parseInt(player.player_crosses_total || '0') });
      if (player.player_dribble_attempts) stats.push({ name: 'Dribbles', value: parseInt(player.player_dribble_attempts || '0') });
    }
    
    return stats;
  };
  
  // Get player position in readable format
  const getPositionText = (type: string) => {
    if (type === "Goalkeepers") return "Goalkeeper";
    if (type === "Defenders") return "Defender";
    if (type === "Midfielders") return "Midfielder";
    if (type === "Forwards") return "Forward";
    return type;
  };
  
  return (
    <PageContainer showBack title={player.player_name}>
      {/* Player Header */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center">
            <div className="w-32 h-32 rounded-full overflow-hidden bg-secondary flex items-center justify-center mb-4 sm:mb-0 sm:mr-6">
              {player.player_image ? (
                <img 
                  src={player.player_image} 
                  alt={player.player_name} 
                  className="w-full h-full object-cover"
                  onError={(e) => { 
                    (e.target as HTMLImageElement).src = 'https://via.placeholder.com/128/121F3D/FFFFFF?text=Player'; 
                  }}
                />
              ) : (
                <span className="text-4xl font-bold">{player.player_number || '?'}</span>
              )}
            </div>
            
            <div className="text-center sm:text-left">
              <h1 className="text-2xl font-bold">{player.player_name}</h1>
              
              <div className="flex flex-wrap justify-center sm:justify-start gap-2 mt-2">
                <span className="text-sm px-2 py-1 bg-primary text-primary-foreground rounded-full">
                  #{player.player_number || '?'}
                </span>
                <span className="text-sm px-2 py-1 bg-secondary text-secondary-foreground rounded-full">
                  {getPositionText(player.player_type)}
                </span>
                {player.player_is_captain === "1" && (
                  <span className="text-sm px-2 py-1 bg-amber-500 text-amber-50 rounded-full">
                    Captain
                  </span>
                )}
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Age</p>
                  <p className="font-medium">{getPlayerAge(player.player_birthdate)}</p>
                </div>
                {player.player_country && (
                  <div>
                    <p className="text-muted-foreground">Country</p>
                    <p className="font-medium">{player.player_country}</p>
                  </div>
                )}
                <div>
                  <p className="text-muted-foreground">Team</p>
                  <p className="font-medium truncate">{player.team_name}</p>
                </div>
                {player.team_key && (
                  <div>
                    <p className="text-muted-foreground">Club</p>
                    <p className="font-medium truncate">{player.team_key}</p>
                  </div>
                )}
                {player.player_rating && (
                  <div>
                    <p className="text-muted-foreground">Rating</p>
                    <p className="font-medium">{parseFloat(player.player_rating).toFixed(1)}</p>
                  </div>
                )}
                <div>
                  <p className="text-muted-foreground">Matches</p>
                  <p className="font-medium">{player.player_match_played}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Goals</p>
                  <p className="font-medium">{player.player_goals}</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Player Stats Tabs */}
      <Tabs defaultValue="stats" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="stats">Season Stats</TabsTrigger>
          <TabsTrigger value="advanced">Advanced Stats</TabsTrigger>
        </TabsList>
        
        {/* Basic Stats */}
        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle>Season Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={getPlayerStatsData()} layout="vertical">
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        borderColor: 'hsl(var(--border))',
                        color: 'hsl(var(--card-foreground))'
                      }}
                    />
                    <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-6">
                <div>
                  <p className="text-sm text-muted-foreground">Matches</p>
                  <p className="text-lg font-semibold">{player.player_match_played}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Goals</p>
                  <p className="text-lg font-semibold">{player.player_goals}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Assists</p>
                  <p className="text-lg font-semibold">{player.player_assists}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Yellow Cards</p>
                  <p className="text-lg font-semibold">{player.player_yellow_cards}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Red Cards</p>
                  <p className="text-lg font-semibold">{player.player_red_cards}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Minutes</p>
                  <p className="text-lg font-semibold">{player.player_match_played ? (parseInt(player.player_match_played) * 90).toLocaleString() : "0"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Advanced Stats */}
        <TabsContent value="advanced">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={getAdvancedStatsData()} layout="vertical">
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        borderColor: 'hsl(var(--border))',
                        color: 'hsl(var(--card-foreground))'
                      }}
                    />
                    <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-6">
                {player.player_type === "Goalkeepers" ? (
                  <>
                    <div>
                      <p className="text-sm text-muted-foreground">Saves</p>
                      <p className="text-lg font-semibold">{player.player_saves || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Inside Box Saves</p>
                      <p className="text-lg font-semibold">{player.player_inside_box_saves || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Goals Conceded</p>
                      <p className="text-lg font-semibold">{player.player_goals_conceded || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Clearances</p>
                      <p className="text-lg font-semibold">{player.player_clearances || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Passes</p>
                      <p className="text-lg font-semibold">{player.player_passes || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Pass Accuracy</p>
                      <p className="text-lg font-semibold">{
                        player.player_passes && player.player_passes_accuracy 
                          ? `${Math.round((parseInt(player.player_passes_accuracy) / parseInt(player.player_passes)) * 100)}%` 
                          : '0%'
                      }</p>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <p className="text-sm text-muted-foreground">Shots</p>
                      <p className="text-lg font-semibold">{player.player_shots_total || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Passes</p>
                      <p className="text-lg font-semibold">{player.player_passes || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Key Passes</p>
                      <p className="text-lg font-semibold">{player.player_key_passes || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Tackles</p>
                      <p className="text-lg font-semibold">{player.player_tackles || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Dribbles</p>
                      <p className="text-lg font-semibold">{player.player_dribble_attempts || '0'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Dribble Success</p>
                      <p className="text-lg font-semibold">{
                        player.player_dribble_attempts && player.player_dribble_succ 
                          ? `${Math.round((parseInt(player.player_dribble_succ) / parseInt(player.player_dribble_attempts)) * 100)}%` 
                          : '0%'
                      }</p>
                    </div>
                    {player.player_crosses_total && (
                      <div>
                        <p className="text-sm text-muted-foreground">Crosses</p>
                        <p className="text-lg font-semibold">{player.player_crosses_total}</p>
                      </div>
                    )}
                    {player.player_fouls_committed && (
                      <div>
                        <p className="text-sm text-muted-foreground">Fouls</p>
                        <p className="text-lg font-semibold">{player.player_fouls_committed}</p>
                      </div>
                    )}
                    {player.player_interceptions && (
                      <div>
                        <p className="text-sm text-muted-foreground">Interceptions</p>
                        <p className="text-lg font-semibold">{player.player_interceptions}</p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}
