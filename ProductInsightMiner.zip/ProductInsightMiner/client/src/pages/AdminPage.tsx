import React, { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { API, apiRequest } from '@/lib/api';
import { News } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import useAuth from '@/hooks/useAuth';
import LoadingSpinner from '@/components/LoadingSpinner';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Edit, FileImage, Plus, Trash2, X } from 'lucide-react';

// Define the news form schema
const newsSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  content: z.string().min(20, "Content must be at least 20 characters"),
  image: z.string().url("Please enter a valid image URL"),
  tags: z.string().optional(),
});

type NewsFormValues = z.infer<typeof newsSchema>;

interface CloudinaryResponse {
  secure_url: string;
}

export default function AdminPage() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [currentNews, setCurrentNews] = useState<News | null>(null);
  const [tags, setTags] = useState<string[]>([]);
  const [tag, setTag] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Check if user is admin or owner
  const isAuthorized = user?.role === 'admin' || user?.role === 'owner';
  
  // Fetch all news
  const { data: news, isLoading: newsLoading } = useQuery<News[]>({
    queryKey: [API.news.list, { limit: 50 }],
    enabled: isAuthenticated && isAuthorized,
  });
  
  // Initialize form
  const form = useForm<NewsFormValues>({
    resolver: zodResolver(newsSchema),
    defaultValues: {
      title: "",
      content: "",
      image: "",
      tags: ""
    }
  });
  
  // Create news mutation
  const createNews = useMutation({
    mutationFn: (data: Omit<NewsFormValues, 'tags'> & { tags: string[] }) => 
      apiRequest('POST', API.admin.news.create, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [API.news.list] });
      form.reset();
      setTags([]);
      toast({
        title: "News created",
        description: "Your news article has been published successfully"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create news",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Update news mutation
  const updateNews = useMutation({
    mutationFn: ({ id, data }: { id: number, data: Omit<NewsFormValues, 'tags'> & { tags: string[] } }) => 
      apiRequest('PUT', API.admin.news.update(id), data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [API.news.list] });
      setCurrentNews(null);
      form.reset();
      setTags([]);
      toast({
        title: "News updated",
        description: "Your news article has been updated successfully"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update news",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Delete news mutation
  const deleteNews = useMutation({
    mutationFn: (id: number) => 
      apiRequest('DELETE', API.admin.news.delete(id)),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [API.news.list] });
      setConfirmDelete(null);
      toast({
        title: "News deleted",
        description: "The news article has been deleted successfully"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete news",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // If not authenticated or authorized, redirect to login
  React.useEffect(() => {
    if (!isLoading && (!isAuthenticated || !isAuthorized)) {
      toast({
        title: "Access denied",
        description: "You don't have permission to access the admin panel",
        variant: "destructive"
      });
      setLocation('/login');
    }
  }, [isLoading, isAuthenticated, isAuthorized, setLocation, toast]);
  
  // Handle form submission
  const onSubmit = async (values: NewsFormValues) => {
    const newsData = {
      title: values.title,
      content: values.content,
      image: values.image,
      tags: tags
    };
    
    if (currentNews) {
      updateNews.mutate({ id: currentNews.id, data: newsData });
    } else {
      createNews.mutate(newsData);
    }
  };
  
  // Handle image upload to Cloudinary
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    setIsUploading(true);
    
    const formData = new FormData();
    formData.append('file', files[0]);
    formData.append('upload_preset', 'Sibola');
    
    try {
      const response = await fetch(`https://api.cloudinary.com/v1_1/dmovxvd5z/image/upload`, {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload image');
      }
      
      const data = await response.json() as CloudinaryResponse;
      form.setValue('image', data.secure_url);
      toast({
        title: "Image uploaded",
        description: "Image has been uploaded successfully"
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload image to Cloudinary",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  // Handle tag input
  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && tag.trim()) {
      e.preventDefault();
      if (!tags.includes(tag.trim())) {
        setTags([...tags, tag.trim()]);
      }
      setTag('');
    }
  };
  
  // Remove tag
  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(t => t !== tagToRemove));
  };
  
  // Edit news
  const handleEditNews = (news: News) => {
    setCurrentNews(news);
    form.reset({
      title: news.title,
      content: news.content,
      image: news.image,
      tags: ''
    });
    setTags(news.tags);
  };
  
  // Cancel edit
  const handleCancelEdit = () => {
    setCurrentNews(null);
    form.reset();
    setTags([]);
  };
  
  if (isLoading) {
    return (
      <PageContainer showBack title="Admin Panel">
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading..." />
        </div>
      </PageContainer>
    );
  }
  
  return (
    <PageContainer showBack title="Admin Panel">
      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="create">Create News</TabsTrigger>
          <TabsTrigger value="manage">Manage News</TabsTrigger>
        </TabsList>
        
        {/* Create News Tab */}
        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>{currentNews ? 'Edit News Article' : 'Create News Article'}</CardTitle>
              <CardDescription>
                {currentNews 
                  ? 'Make changes to the existing news article' 
                  : 'Create a new news article to be published on the site'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter news title" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Content</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Enter news content (HTML supported)" 
                            className="min-h-[200px]" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="image"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Featured Image URL</FormLabel>
                        <div className="flex gap-2">
                          <FormControl>
                            <Input placeholder="Image URL" {...field} />
                          </FormControl>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={isUploading}
                          >
                            {isUploading ? <LoadingSpinner size="sm" /> : <FileImage className="h-4 w-4 mr-2" />}
                            Upload
                          </Button>
                          <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleImageUpload}
                            accept="image/*"
                            className="hidden"
                          />
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Image Preview */}
                  {form.watch('image') && (
                    <div className="mt-2 relative w-full h-40 bg-muted rounded-md overflow-hidden">
                      <img 
                        src={form.watch('image')} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = 'https://via.placeholder.com/800x400/121F3D/FFFFFF?text=Image+Preview';
                        }}
                      />
                    </div>
                  )}
                  
                  {/* Tags */}
                  <div>
                    <FormLabel>Tags</FormLabel>
                    <div className="flex gap-2 mb-2 flex-wrap">
                      {tags.map((t, i) => (
                        <Badge key={i} variant="secondary" className="flex items-center gap-1">
                          {t}
                          <X 
                            className="h-3 w-3 cursor-pointer" 
                            onClick={() => removeTag(t)}
                          />
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Input
                        value={tag}
                        onChange={e => setTag(e.target.value)}
                        onKeyDown={handleTagKeyDown}
                        placeholder="Add tag and press Enter"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2 pt-4">
                    {currentNews && (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleCancelEdit}
                      >
                        Cancel
                      </Button>
                    )}
                    <Button 
                      type="submit" 
                      disabled={createNews.isPending || updateNews.isPending}
                    >
                      {createNews.isPending || updateNews.isPending ? (
                        <LoadingSpinner size="sm" />
                      ) : currentNews ? 'Update Article' : 'Publish Article'}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Manage News Tab */}
        <TabsContent value="manage">
          <Card>
            <CardHeader>
              <CardTitle>Manage News Articles</CardTitle>
              <CardDescription>View, edit or delete existing news articles</CardDescription>
            </CardHeader>
            <CardContent>
              {newsLoading ? (
                <div className="py-8 flex justify-center">
                  <LoadingSpinner text="Loading news articles..." />
                </div>
              ) : news && news.length > 0 ? (
                <div className="space-y-4">
                  {news.map(article => (
                    <div 
                      key={article.id} 
                      className="flex flex-col md:flex-row gap-4 p-4 bg-secondary/50 rounded-lg"
                    >
                      <div className="w-full md:w-20 h-20 rounded-md overflow-hidden flex-shrink-0">
                        <img 
                          src={article.image} 
                          alt={article.title} 
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.currentTarget.src = 'https://via.placeholder.com/80/121F3D/FFFFFF?text=News';
                          }}
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium mb-1">{article.title}</h3>
                        <div className="flex flex-wrap gap-1 mb-2">
                          {article.tags.map((tag, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">
                          Published: {new Date(article.publishedAt).toLocaleString()}
                        </p>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleEditNews(article)}
                          >
                            <Edit className="h-4 w-4 mr-1" />
                            Edit
                          </Button>
                          
                          <Dialog open={confirmDelete === article.id} onOpenChange={(open) => {
                            if (!open) setConfirmDelete(null);
                          }}>
                            <DialogTrigger asChild>
                              <Button 
                                variant="destructive" 
                                size="sm"
                                onClick={() => setConfirmDelete(article.id)}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Delete
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Confirm Deletion</DialogTitle>
                                <DialogDescription>
                                  Are you sure you want to delete this news article? This action cannot be undone.
                                </DialogDescription>
                              </DialogHeader>
                              <div className="bg-muted p-3 rounded-md flex items-start space-x-3">
                                <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
                                <div>
                                  <h4 className="font-medium">{article.title}</h4>
                                  <p className="text-sm text-muted-foreground">
                                    Published: {new Date(article.publishedAt).toLocaleString()}
                                  </p>
                                </div>
                              </div>
                              <DialogFooter>
                                <Button 
                                  variant="outline" 
                                  onClick={() => setConfirmDelete(null)}
                                >
                                  Cancel
                                </Button>
                                <Button 
                                  variant="destructive" 
                                  onClick={() => deleteNews.mutate(article.id)}
                                  disabled={deleteNews.isPending}
                                >
                                  {deleteNews.isPending ? (
                                    <LoadingSpinner size="sm" />
                                  ) : "Delete"}
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-muted mb-4">
                    <Plus className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No news articles yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Create your first news article by switching to the Create tab
                  </p>
                  <Button onClick={() => document.querySelector('[value="create"]')?.dispatchEvent(new Event('click'))}>
                    Create News Article
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}
