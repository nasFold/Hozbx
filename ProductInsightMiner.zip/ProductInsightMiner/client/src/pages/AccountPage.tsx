import React, { useState } from 'react';
import { useLocation } from 'wouter';
import PageContainer from '@/components/PageContainer';
import useAuth from '@/hooks/useAuth';
import useUserTeams from '@/hooks/useUserTeams';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { User, LogOut, UserCog, Shield, ChevronRight, Star, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function AccountPage() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading, logout, logoutLoading } = useAuth();
  const { followedTeams, isLoading: teamsLoading, removeTeam } = useUserTeams();
  const { toast } = useToast();
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  
  const handleLogout = async () => {
    setIsConfirmOpen(false);
    
    try {
      await logout();
      toast({
        title: "Logged out",
        description: "You have been successfully logged out"
      });
      setLocation('/');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out",
        variant: "destructive"
      });
    }
  };
  
  const handleUnfollowTeam = async (teamId: string, teamName: string) => {
    try {
      await removeTeam(teamId);
      toast({
        title: "Team unfollowed",
        description: `You are no longer following ${teamName}`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to unfollow team",
        variant: "destructive"
      });
    }
  };
  
  const navigateToLogin = () => {
    setLocation('/login');
  };
  
  const navigateToRegister = () => {
    setLocation('/register');
  };
  
  const navigateToAdminPanel = () => {
    setLocation('/admin');
  };
  
  const navigateToOwnerPanel = () => {
    setLocation('/owner');
  };
  
  if (isLoading) {
    return (
      <PageContainer title="Account">
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading account data..." />
        </div>
      </PageContainer>
    );
  }
  
  // Not logged in view
  if (!isAuthenticated) {
    return (
      <PageContainer title="Account">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Sign In Required</CardTitle>
            <CardDescription>Please log in or register to access your account</CardDescription>
          </CardHeader>
          <CardFooter className="flex gap-4">
            <Button onClick={navigateToLogin} className="flex-1">
              Log In
            </Button>
            <Button onClick={navigateToRegister} variant="outline" className="flex-1">
              Register
            </Button>
          </CardFooter>
        </Card>
        
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Account Benefits</h2>
          
          <div className="flex items-start space-x-3 p-3 bg-card rounded-lg">
            <Star className="h-5 w-5 mt-0.5 text-primary" />
            <div>
              <h3 className="font-medium">Follow your favorite teams</h3>
              <p className="text-sm text-muted-foreground">Keep track of your favorite teams and get their matches pinned at the top</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-3 bg-card rounded-lg">
            <UserCog className="h-5 w-5 mt-0.5 text-primary" />
            <div>
              <h3 className="font-medium">Personalized experience</h3>
              <p className="text-sm text-muted-foreground">Tailor your Sibola experience to your preferences</p>
            </div>
          </div>
        </div>
      </PageContainer>
    );
  }
  
  return (
    <PageContainer title="My Account">
      {/* User Info Card */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex items-center">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mr-4">
              <User className="h-8 w-8 text-secondary-foreground" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{user?.username}</h2>
              <p className="text-sm text-muted-foreground capitalize">
                Role: <span className="font-semibold">{user?.role}</span>
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Tabs */}
      <Tabs defaultValue="teams" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="teams">Teams</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        {/* Teams Tab */}
        <TabsContent value="teams">
          <Card>
            <CardHeader>
              <CardTitle>Followed Teams</CardTitle>
              <CardDescription>Teams you are currently following</CardDescription>
            </CardHeader>
            <CardContent>
              {teamsLoading ? (
                <div className="h-20 flex items-center justify-center">
                  <LoadingSpinner text="Loading teams..." />
                </div>
              ) : followedTeams.length > 0 ? (
                <div className="space-y-3">
                  {followedTeams.map(team => (
                    <div 
                      key={team.id} 
                      className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg"
                    >
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-background flex items-center justify-center mr-3">
                          {team.logo ? (
                            <img 
                              src={team.logo} 
                              alt={team.name} 
                              className="w-8 h-8 object-contain"
                              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/32/121F3D/FFFFFF?text=T' }}
                            />
                          ) : (
                            <span className="text-sm font-bold">{team.name.charAt(0)}</span>
                          )}
                        </div>
                        <span className="font-medium">{team.name}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-muted-foreground hover:text-foreground"
                          onClick={() => handleUnfollowTeam(team.id, team.name)}
                        >
                          Unfollow
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => setLocation(`/team/${team.id}`)}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-secondary mb-4">
                    <Star className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No teams followed yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Follow teams to see their matches prioritized in your feed
                  </p>
                  <Button onClick={() => setLocation('/leagues')}>
                    Browse Leagues
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Settings Tab */}
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Admin Panel */}
              {/* Debug: Output user role - {user?.role} */}
              {(user?.role === 'admin' || user?.role === 'owner') && (
                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mr-3">
                      <Shield className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <span className="font-medium">Admin Panel</span>
                      <p className="text-sm text-muted-foreground">Manage news content</p>
                    </div>
                  </div>
                  <Button variant="outline" onClick={navigateToAdminPanel}>
                    Open
                  </Button>
                </div>
              )}
              
              {/* Owner Panel */}
              {user?.role === 'owner' && (
                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mr-3">
                      <UserCog className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <span className="font-medium">Owner Panel</span>
                      <p className="text-sm text-muted-foreground">Site configuration and monitoring</p>
                    </div>
                  </div>
                  <Button variant="outline" onClick={navigateToOwnerPanel}>
                    Open
                  </Button>
                </div>
              )}
              
              <Separator />
              
              {/* Logout */}
              <div className="flex items-center justify-between p-3 bg-destructive/10 rounded-lg">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center mr-3">
                    <LogOut className="h-5 w-5 text-destructive" />
                  </div>
                  <span className="font-medium">Log out</span>
                </div>
                <AlertDialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">Logout</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                      <AlertDialogDescription>
                        You will be logged out of your account.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={handleLogout}
                        disabled={logoutLoading}
                      >
                        {logoutLoading ? (
                          <LoadingSpinner size="sm" />
                        ) : "Logout"}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}
