import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, Link } from 'wouter';
import { API, formatDateForAPI, getUserTimezone } from '@/lib/api';
import { Team, Match } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import MatchCard from '@/components/MatchCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import TeamFollowButton from '@/components/TeamFollowButton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Calendar, Users } from 'lucide-react';

export default function TeamPage() {
  const { id } = useParams<{ id: string }>();
  const timezone = getUserTimezone();
  const today = formatDateForAPI(new Date());
  
  // Fetch team data
  const { data: teamData, isLoading: teamLoading } = useQuery<Team[]>({
    queryKey: [API.football.teams, { team_id: id }],
    queryFn: async () => {
      const response = await fetch(`${API.football.teams}?team_id=${id}`);
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      return response.json();
    },
    enabled: !!id,
  });
  
  // Get team if available
  const team = teamData?.[0];
  
  // Fetch team fixtures
  const { data: fixtures, isLoading: fixturesLoading } = useQuery<Match[]>({
    queryKey: [API.football.events, { 
      team_id: id, 
      from: today,
      to: formatDateForAPI(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)), // 30 days ahead
      timezone
    }],
    queryFn: async () => {
      const toDate = formatDateForAPI(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000));
      const response = await fetch(`${API.football.events}?team_id=${id}&from=${today}&to=${toDate}&timezone=${timezone}`);
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      return response.json();
    },
    enabled: !!id,
  });
  
  // Fetch past results
  const fromDate = formatDateForAPI(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)); // 30 days back
  const toDate = formatDateForAPI(new Date(Date.now() - 24 * 60 * 60 * 1000)); // yesterday
  
  const { data: results, isLoading: resultsLoading } = useQuery<Match[]>({
    queryKey: [API.football.events, { 
      team_id: id, 
      from: fromDate,
      to: toDate,
      timezone
    }],
    queryFn: async () => {
      const response = await fetch(`${API.football.events}?team_id=${id}&from=${fromDate}&to=${toDate}&timezone=${timezone}`);
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      return response.json();
    },
    enabled: !!id,
  });
  
  if (!id) {
    return (
      <PageContainer showBack title="Team Details">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Invalid Team</p>
          <p className="text-muted-foreground">No team ID was provided.</p>
        </div>
      </PageContainer>
    );
  }
  
  if (teamLoading) {
    return (
      <PageContainer showBack title="Team Details">
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading team details..." />
        </div>
      </PageContainer>
    );
  }
  
  if (!team) {
    return (
      <PageContainer showBack title="Team Details">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Team not found</p>
          <p className="text-muted-foreground">The team you're looking for doesn't exist or has been removed.</p>
        </div>
      </PageContainer>
    );
  }
  
  // Group players by position
  const playersByPosition: Record<string, typeof team.players[0][]> = {};
  
  team.players.forEach(player => {
    if (!playersByPosition[player.player_type]) {
      playersByPosition[player.player_type] = [];
    }
    playersByPosition[player.player_type].push(player);
  });
  
  // Sort positions in logical order
  const sortedPositions = Object.keys(playersByPosition).sort((a, b) => {
    const order = ["Goalkeepers", "Defenders", "Midfielders", "Forwards"];
    return order.indexOf(a) - order.indexOf(b);
  });
  
  return (
    <PageContainer showBack title={team.team_name} noPadding>
      {/* Team Header */}
      <div className="bg-card p-6 shadow-md mb-4">
        <div className="flex flex-col items-center mb-4">
          <div className="w-24 h-24 flex items-center justify-center">
            <img 
              src={team.team_badge}
              alt={team.team_name}
              className="max-w-full max-h-full object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/96/121F3D/FFFFFF?text=Team' }}
            />
          </div>
          <h1 className="text-2xl font-bold mt-2">{team.team_name}</h1>
          <p className="text-muted-foreground">{team.team_country}</p>
          
          <div className="mt-4">
            <TeamFollowButton 
              teamId={team.team_key}
              teamName={team.team_name}
              teamLogo={team.team_badge}
            />
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-between text-sm">
          <div className="flex items-center mb-2 sm:mb-0">
            <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>{team.venue.venue_name}, {team.venue.venue_city}</span>
          </div>
          <div className="flex items-center mb-2 sm:mb-0">
            <Users className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>Capacity: {parseInt(team.venue.venue_capacity).toLocaleString()}</span>
          </div>
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>Founded: {team.team_founded}</span>
          </div>
        </div>
      </div>
      
      {/* Team Content Tabs */}
      <div className="px-4">
        <Tabs defaultValue="squad" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="squad">Squad</TabsTrigger>
            <TabsTrigger value="fixtures">Fixtures</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
          </TabsList>
          
          {/* Squad Tab */}
          <TabsContent value="squad">
            {/* Coach */}
            {team.coaches && team.coaches.length > 0 && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Coach</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mr-4">
                      <span className="text-lg font-bold">
                        {team.coaches[0].coach_name.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="font-semibold">{team.coaches[0].coach_name}</p>
                      {team.coaches[0].coach_country && (
                        <p className="text-sm text-muted-foreground">{team.coaches[0].coach_country}</p>
                      )}
                      {team.coaches[0].coach_age && (
                        <p className="text-sm text-muted-foreground">Age: {team.coaches[0].coach_age}</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Players by position */}
            {sortedPositions.map(position => (
              <Card key={position} className="mb-6">
                <CardHeader>
                  <CardTitle>{position}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {playersByPosition[position].map(player => {
                      return (
                        <Link 
                          key={player.player_key}
                          href={`/player/${player.player_key}`}
                          className="flex items-center p-2 hover:bg-secondary/50 rounded-md cursor-pointer"
                        >
                          <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mr-3">
                            {player.player_image ? (
                              <img 
                                src={player.player_image} 
                                alt={player.player_name} 
                                className="w-10 h-10 rounded-full object-cover"
                                onError={(e) => { 
                                  (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40/121F3D/FFFFFF?text=Player'; 
                                }}
                              />
                            ) : (
                              <span className="text-lg font-bold">{player.player_number || '?'}</span>
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center">
                              <span className="font-medium">{player.player_name}</span>
                              {player.player_is_captain === "1" && (
                                <span className="ml-2 text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded">
                                  C
                                </span>
                              )}
                            </div>
                            <div className="flex items-center text-xs text-muted-foreground">
                              <span className="mr-2">#{player.player_number || '?'}</span>
                              {player.player_age && <span className="mr-2">{player.player_age} years</span>}
                              {player.player_country && <span>{player.player_country}</span>}
                            </div>
                          </div>
                          {player.player_rating && (
                            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                              <span className="text-xs font-bold text-primary-foreground">
                                {parseFloat(player.player_rating).toFixed(1)}
                              </span>
                            </div>
                          )}
                        </Link>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          {/* Fixtures Tab */}
          <TabsContent value="fixtures">
            {fixturesLoading ? (
              <div className="h-40 flex items-center justify-center">
                <LoadingSpinner text="Loading fixtures..." />
              </div>
            ) : fixtures && fixtures.length > 0 ? (
              <div className="space-y-3">
                {fixtures.map((match) => (
                  <MatchCard key={match.match_id} match={match} compact />
                ))}
              </div>
            ) : (
              <div className="bg-card rounded-lg p-6 text-center">
                <p className="text-muted-foreground">No upcoming fixtures available for this team.</p>
              </div>
            )}
          </TabsContent>
          
          {/* Results Tab */}
          <TabsContent value="results">
            {resultsLoading ? (
              <div className="h-40 flex items-center justify-center">
                <LoadingSpinner text="Loading results..." />
              </div>
            ) : results && results.length > 0 ? (
              <div className="space-y-3">
                {results.map((match) => (
                  <MatchCard key={match.match_id} match={match} compact />
                ))}
              </div>
            ) : (
              <div className="bg-card rounded-lg p-6 text-center">
                <p className="text-muted-foreground">No recent results available for this team.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </PageContainer>
  );
}
