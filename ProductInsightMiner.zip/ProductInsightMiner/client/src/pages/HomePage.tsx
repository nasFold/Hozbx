import React, { useState, useEffect, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format, addDays, subDays } from 'date-fns';
import { useWebSocket } from '@/contexts/WebSocketContext';
import { API, formatDateForAPI, getUserTimezone, sortMatches } from '@/lib/api';
import { Match, News } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import Carousel from '@/components/Carousel';
import MatchCard from '@/components/MatchCard';
import NewsCard from '@/components/NewsCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import TopLeagueNavigation from '@/components/TopLeagueNavigation';
import { useLocation } from 'wouter';

export default function HomePage() {
  const [, setLocation] = useLocation();
  const { liveMatches } = useWebSocket();
  const timezone = getUserTimezone();
  const today = formatDateForAPI(new Date());

  // Fetch today's matches as fallback if no live matches
  const { data: todayMatches, isLoading: todayMatchesLoading } = useQuery<Match[]>({
    queryKey: [API.football.events, { from: today, to: today, timezone }],
    enabled: liveMatches.length === 0,
  });

  // Fetch news
  const { data: newsData, isLoading: newsLoading } = useQuery<News[]>({
    queryKey: [API.news.list, { limit: 5 }],
  });

  // Determine which matches to display
  const displayMatches = liveMatches.length > 0 ? liveMatches : todayMatches || [];

  return (
    <PageContainer>
      {/* Top Leagues Quick Access */}
      <TopLeagueNavigation className="mb-4" />

      {/* Live Matches Carousel */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-semibold flex items-center">
            <span className="inline-block w-2 h-2 bg-destructive rounded-full animate-pulse mr-2"></span>
            {liveMatches.length > 0 ? 'Live Matches' : 'Today\'s Matches'}
          </h2>
          <button 
            className="text-primary text-sm"
            onClick={() => setLocation('/matches')}
          >
            View All
          </button>
        </div>

        {(todayMatchesLoading && !displayMatches.length) ? (
          <div className="h-40 flex items-center justify-center">
            <LoadingSpinner text="Loading matches..." />
          </div>
        ) : displayMatches.length > 0 ? (
          <Carousel>
            {sortMatches(displayMatches).map((match) => (
              <div key={match.match_id} className="px-1 py-1">
                <MatchCard match={match} />
              </div>
            ))}
          </Carousel>
        ) : (
          <div className="bg-card rounded-lg p-6 text-center">
            <p className="text-muted-foreground">No matches scheduled for today.</p>
            <button 
              className="mt-3 text-primary"
              onClick={() => setLocation('/matches')}
            >
              View upcoming matches
            </button>
          </div>
        )}
      </div>

      {/* News Preview */}
      <div className="mb-4">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-semibold">Latest News</h2>
          <button 
            className="text-primary text-sm"
            onClick={() => setLocation('/news')}
          >
            View All
          </button>
        </div>

        {newsLoading ? (
          <div className="h-40 flex items-center justify-center">
            <LoadingSpinner text="Loading news..." />
          </div>
        ) : newsData && newsData.length > 0 ? (
          <div className="space-y-4">
            {newsData.slice(0, 2).map((news) => (
              <NewsCard key={news.id} news={news} />
            ))}
          </div>
        ) : (
          <div className="bg-card rounded-lg p-6 text-center">
            <p className="text-muted-foreground">No news available at the moment.</p>
          </div>
        )}
      </div>
    </PageContainer>
  );
}