
import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format, addDays, parseISO } from 'date-fns';
import { API, formatDateForAPI, getUserTimezone, sortMatches } from '@/lib/api';
import { Match, League } from '@/lib/types';
import { useWebSocket } from '@/contexts/WebSocketContext';
import PageContainer from '@/components/PageContainer';
import MatchCard from '@/components/MatchCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import useUserTeams from '@/hooks/useUserTeams';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

export default function MatchesPage() {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const { liveMatches } = useWebSocket();
  const { followedTeams } = useUserTeams();
  const timezone = getUserTimezone();
  
  // Use today's date for matches
  const today = new Date();
  const formattedDate = formatDateForAPI(today);
  
  // Fetch matches for the selected date
  const { data: dateMatches, isLoading: dateMatchesLoading, refetch: refetchDateMatches } = useQuery<Match[]>({
    queryKey: [API.football.events, { from: formattedDate, to: formattedDate, timezone }],
    enabled: !!formattedDate,
  });
  
  // Refetch matches when date changes
  useEffect(() => {
    if (formattedDate) {
      refetchDateMatches();
    }
  }, [formattedDate, refetchDateMatches]);
  
  // Group matches by league
  const groupMatchesByLeague = (matches: Match[]) => {
    const grouped: Record<string, { league: League, matches: Match[] }> = {};
    
    matches.forEach(match => {
      const leagueId = match.league_id;
      
      if (!grouped[leagueId]) {
        grouped[leagueId] = {
          league: {
            league_id: match.league_id,
            league_name: match.league_name,
            league_logo: match.league_logo,
            country_id: match.country_id,
            country_name: match.country_name,
            country_logo: match.country_logo,
            league_season: '',
          },
          matches: []
        };
      }
      
      grouped[leagueId].matches.push(match);
    });
    
    return Object.values(grouped);
  };
  
  // Combine live matches with date matches
  const allMatches = [...liveMatches];
  
  if (dateMatches) {
    // Add date matches that aren't already in live matches
    dateMatches.forEach(match => {
      if (!allMatches.some(m => m.match_id === match.match_id)) {
        allMatches.push(match);
      }
    });
  }
  
  // Sort the allMatches array using our sort function to ensure proper ordering
  // (live first, then upcoming, then finished matches)
  const sortedAllMatches = sortMatches(allMatches);
  
  // Filter followed team matches
  const followedTeamMatches = sortedAllMatches.filter(match => 
    followedTeams.some(team => 
      team.id === match.match_hometeam_id || team.id === match.match_awayteam_id
    )
  );
  
  // Group matches for display
  const groupedLiveMatches = groupMatchesByLeague(liveMatches);
  const groupedFollowedMatches = groupMatchesByLeague(followedTeamMatches);
  const groupedDateMatches = groupMatchesByLeague(
    sortedAllMatches.filter(match => 
      // Filter out matches that are already in live or followed sections
      !liveMatches.some(m => m.match_id === match.match_id) &&
      !followedTeamMatches.some(m => m.match_id === match.match_id)
    )
  );
  
  // Filter matches based on search query
  const filterMatchesBySearch = (matches: Match[]) => {
    if (!searchQuery.trim()) return matches;
    
    const query = searchQuery.toLowerCase().trim();
    return matches.filter(match => 
      match.match_hometeam_name.toLowerCase().includes(query) ||
      match.match_awayteam_name.toLowerCase().includes(query) ||
      match.league_name.toLowerCase().includes(query) ||
      match.country_name.toLowerCase().includes(query)
    );
  };
  
  // Filter all matches collections with search
  const filteredLiveMatches = filterMatchesBySearch(liveMatches);
  const filteredFollowedMatches = filterMatchesBySearch(followedTeamMatches);
  const filteredDateMatches = sortedAllMatches.filter(match => {
    // Only include matches that pass the search filter
    const passesSearchFilter = !searchQuery.trim() || (
      (match.match_hometeam_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.match_awayteam_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.league_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.country_name.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    
    // And aren't already in live or followed sections
    const notInOtherSections = 
      !filteredLiveMatches.some(m => m.match_id === match.match_id) &&
      !filteredFollowedMatches.some(m => m.match_id === match.match_id);
    
    return passesSearchFilter && notInOtherSections;
  });
  
  // Group filtered matches
  const groupedFilteredLiveMatches = groupMatchesByLeague(filteredLiveMatches);
  const groupedFilteredFollowedMatches = groupMatchesByLeague(filteredFollowedMatches);
  const groupedFilteredDateMatches = groupMatchesByLeague(filteredDateMatches);
  
  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  return (
    <PageContainer title="Matches">
      {/* Search Bar */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search teams, leagues, or countries..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="pl-9 bg-background"
        />
        {searchQuery && (
          <button 
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
            onClick={() => setSearchQuery('')}
          >
            Clear
          </button>
        )}
      </div>
      
      {/* Show search results count if searching */}
      {searchQuery.trim() && (
        <div className="mb-4 py-1 px-3 bg-muted rounded-md">
          <p className="text-sm text-muted-foreground">
            {filteredLiveMatches.length + filteredFollowedMatches.length + filteredDateMatches.length} 
            {' '}matches found for "{searchQuery}"
          </p>
        </div>
      )}

      {/* Live Matches Section */}
      {filteredLiveMatches.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-3">
            <span className="inline-block w-2 h-2 bg-destructive rounded-full animate-pulse"></span>
            <h2 className="text-lg font-semibold">Live Matches</h2>
          </div>
          
          <div className="space-y-3">
            {groupedFilteredLiveMatches.map(({ league, matches }) => (
              <div key={league.league_id}>
                <div className="flex items-center space-x-2 py-2">
                  <img 
                    src={league.league_logo} 
                    alt={league.league_name} 
                    className="w-5 h-5 object-contain"
                    onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/20/121F3D/FFFFFF?text=L' }}
                  />
                  <span className="text-sm font-medium">{league.league_name}</span>
                </div>
                
                {matches.map(match => (
                  <MatchCard key={match.match_id} match={match} compact />
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Followed Teams Matches */}
      {filteredFollowedMatches.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-3">
            <h2 className="text-lg font-semibold">Your Teams</h2>
          </div>
          
          <div className="space-y-3">
            {groupedFilteredFollowedMatches.map(({ league, matches }) => (
              <div key={league.league_id}>
                <div className="flex items-center space-x-2 py-2">
                  <img 
                    src={league.league_logo} 
                    alt={league.league_name} 
                    className="w-5 h-5 object-contain"
                    onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/20/121F3D/FFFFFF?text=L' }}
                  />
                  <span className="text-sm font-medium">{league.league_name}</span>
                </div>
                
                {matches.map(match => (
                  <MatchCard key={match.match_id} match={match} compact />
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Date Matches */}
      <div>
        <div className="flex items-center space-x-2 mb-3">
          <h2 className="text-lg font-semibold">
            Today's Matches
          </h2>
        </div>
        
        {dateMatchesLoading ? (
          <div className="h-40 flex items-center justify-center">
            <LoadingSpinner text="Loading matches..." />
          </div>
        ) : groupedFilteredDateMatches.length > 0 ? (
          <div className="space-y-3">
            {groupedFilteredDateMatches.map(({ league, matches }) => (
              <div key={league.league_id}>
                <div className="flex items-center space-x-2 py-2">
                  <img 
                    src={league.league_logo} 
                    alt={league.league_name} 
                    className="w-5 h-5 object-contain"
                    onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/20/121F3D/FFFFFF?text=L' }}
                  />
                  <span className="text-sm font-medium">{league.league_name}</span>
                </div>
                
                {matches.map(match => (
                  <MatchCard key={match.match_id} match={match} compact />
                ))}
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-card rounded-lg p-6 text-center">
            <p className="text-muted-foreground">
              {searchQuery.trim() 
                ? 'No matches found for your search. Try different keywords.' 
                : 'No matches scheduled for this date.'}
            </p>
          </div>
        )}
      </div>
    </PageContainer>
  );
}
