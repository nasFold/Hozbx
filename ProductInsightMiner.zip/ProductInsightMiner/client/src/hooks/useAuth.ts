import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { API, apiRequest } from '@/lib/api';
import { User } from '@/lib/types';

interface LoginData {
  username: string;
  password: string;
}

interface RegisterData {
  username: string;
  email: string;
  password: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: Error | null;
}

export default function useAuth() {
  const queryClient = useQueryClient();

  // Fetch current user
  const { 
    data: user, 
    isLoading, 
    error, 
    refetch 
  } = useQuery<{ user: User }>({
    queryKey: [API.auth.me],
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
    refetchOnWindowFocus: false,
    throwOnError: false
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (data: LoginData) => {
      const res = await apiRequest('POST', API.auth.login, data);
      return await res.json();
    },
    onSuccess: (data) => {
      console.log('Login response:', data);
      queryClient.setQueryData([API.auth.me], { user: data.user });
      queryClient.invalidateQueries({ queryKey: [API.auth.me] });
    },
    onError: (error) => {
      console.error('Login error:', error);
    }
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (data: RegisterData) => {
      const res = await apiRequest('POST', API.auth.register, data);
      return await res.json();
    },
    onSuccess: (data) => {
      console.log('Registration successful:', data);

      // Auto-login after registration
      if (registerMutation.variables) {
        const { username, password } = registerMutation.variables;
        console.log('Auto-logging in after registration');
        loginMutation.mutate({ username, password });
      }
    },
    onError: (error) => {
      console.error('Registration error:', error);
    }
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: () => apiRequest('POST', API.auth.logout),
    onSuccess: () => {
      queryClient.setQueryData([API.auth.me], null);
      queryClient.invalidateQueries({ queryKey: [API.auth.me] });
    }
  });

  // Function to check auth status (can be called multiple times)
  const checkAuth = async () => {
    try {
      const user = await apiRequest('GET', API.auth.me);
      console.log("User data from auth check:", user);
      queryClient.setQueryData([API.auth.me], { user: user });
      queryClient.invalidateQueries({ queryKey: [API.auth.me] });
    } catch (error) {
      queryClient.setQueryData([API.auth.me], null);
      queryClient.invalidateQueries({ queryKey: [API.auth.me] });
    }
  };


  const login = (data: LoginData) => {
    return loginMutation.mutate(data);
  };

  const register = (data: RegisterData) => {
    return registerMutation.mutate(data);
  };

  const logout = () => {
    return logoutMutation.mutate();
  };

  return {
    user: user?.user || null,
    isAuthenticated: !!user?.user,
    isLoading,
    error: error as Error | null,
    login,
    register,
    logout,
    loginLoading: loginMutation.isPending,
    registerLoading: registerMutation.isPending,
    logoutLoading: logoutMutation.isPending,
    loginError: loginMutation.error,
    registerError: registerMutation.error,
    checkAuth // Expose checkAuth for manual refresh
  };
}