import React from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { API } from '@/lib/api';
import { League } from '@/lib/types';
import { cn } from '@/lib/utils';
import ScrollableContainer from './ScrollableContainer';

interface TopLeagueNavigationProps {
  className?: string;
}

export default function TopLeagueNavigation({ className }: TopLeagueNavigationProps) {
  const [, setLocation] = useLocation();
  
  // Top leagues IDs
  const topLeaguesIds = {
    'Premier League': '152',
    'La Liga': '302',
    'Serie A': '207',
    'Bundesliga': '175',
    'Ligue 1': '168',
    'Champions League': '244'
  };
  
  // Fetch leagues data
  const { data: leagues, isLoading } = useQuery<League[]>({
    queryKey: [API.football.leagues],
    staleTime: 1000 * 60 * 30 // 30 minutes
  });
  
  // Filter top leagues
  const topLeagues = leagues?.filter(league => 
    Object.values(topLeaguesIds).includes(league.league_id)
  ) || [];
  
  const handleLeagueClick = (leagueId: string) => {
    setLocation(`/league/${leagueId}`);
  };
  
  return (
    <div className={cn("", className)}>
      <ScrollableContainer>
        {topLeagues.map(league => (
          <div 
            key={league.league_id}
            className="flex flex-col items-center cursor-pointer"
            onClick={() => handleLeagueClick(league.league_id)}
          >
            <div className="w-12 h-12 bg-card rounded-full flex items-center justify-center border-2 border-transparent hover:border-primary">
              <img 
                src={league.league_logo} 
                alt={league.league_name} 
                className="w-8 h-8 object-contain"
                onError={(e) => { (e.target as HTMLImageElement).src = `https://via.placeholder.com/32/121F3D/FFFFFF?text=${league.league_name.charAt(0)}` }}
              />
            </div>
            <span className="text-xs mt-1 text-muted-foreground">
              {league.league_name.length > 4 ? league.league_name.split(' ')[0] : league.league_name}
            </span>
          </div>
        ))}
        
        <div 
          className="flex flex-col items-center cursor-pointer"
          onClick={() => setLocation('/leagues')}
        >
          <div className="w-12 h-12 bg-card rounded-full flex items-center justify-center opacity-60">
            <span className="text-xl">•••</span>
          </div>
          <span className="text-xs mt-1 text-muted-foreground">More</span>
        </div>
      </ScrollableContainer>
    </div>
  );
}
