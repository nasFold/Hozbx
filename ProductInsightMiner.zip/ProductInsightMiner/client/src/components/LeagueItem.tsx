import React from 'react';
import { useLocation } from 'wouter';
import { League, Country } from '@/lib/types';
import { cn } from '@/lib/utils';

interface LeagueItemProps {
  item: League | Country;
  type: 'league' | 'country';
  className?: string;
}

export default function LeagueItem({ item, type, className }: LeagueItemProps) {
  const [, setLocation] = useLocation();
  
  const handleClick = () => {
    if (type === 'league') {
      setLocation(`/league/${(item as League).league_id}`);
    } else {
      // Navigate to leagues filtered by country
      setLocation(`/leagues?country=${(item as Country).country_id}`);
    }
  };
  
  const getLogoUrl = () => {
    if (type === 'league') {
      return (item as League).league_logo;
    } else {
      return (item as Country).country_logo;
    }
  };
  
  const getName = () => {
    if (type === 'league') {
      return (item as League).league_name;
    } else {
      return (item as Country).country_name;
    }
  };
  
  const getSeason = () => {
    if (type === 'league') {
      return (item as League).league_season;
    }
    return null;
  };
  
  return (
    <div
      className={cn(
        "flex items-center p-3 rounded-lg bg-card shadow cursor-pointer hover:bg-accent",
        className
      )}
      onClick={handleClick}
    >
      <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center mr-3">
        <img
          src={getLogoUrl()}
          alt={getName()}
          className="w-7 h-7 object-contain"
          onError={(e) => { (e.target as HTMLImageElement).src = `https://via.placeholder.com/28/121F3D/FFFFFF?text=${type === 'league' ? 'L' : 'C'}` }}
        />
      </div>
      <div className="flex-1">
        <h3 className="font-medium text-sm line-clamp-1">{getName()}</h3>
        {type === 'league' && getSeason() && (
          <p className="text-xs text-muted-foreground">{getSeason()}</p>
        )}
      </div>
    </div>
  );
}
