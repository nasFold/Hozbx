import React, { useState } from 'react';
import { Match, LineupPlayer } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';

interface LineupProps {
  match: Match;
  className?: string;
}

export default function Lineup({ match, className }: LineupProps) {
  const [activeTeam, setActiveTeam] = useState<'home' | 'away'>('home');
  
  // Simplified version without field visualization
  return (
    <div className={cn("bg-card p-4 rounded-lg shadow", className)}>
      <div className="flex justify-between items-center bg-card p-2 rounded-lg mb-4 shadow">
        <Button
          variant={activeTeam === 'home' ? 'default' : 'outline'}
          onClick={() => setActiveTeam('home')}
          className="flex-1 h-9"
        >
          {match.match_hometeam_name} {match.match_hometeam_system && `(${match.match_hometeam_system})`}
        </Button>
        <Button
          variant={activeTeam === 'away' ? 'default' : 'outline'}
          onClick={() => setActiveTeam('away')}
          className="flex-1 h-9"
        >
          {match.match_awayteam_name} {match.match_awayteam_system && `(${match.match_awayteam_system})`}
        </Button>
      </div>
      
      {/* Check if lineup data exists */}
      {!match.lineup || (!match.lineup.home && !match.lineup.away) ? (
        <p className="text-muted-foreground text-center py-8">Lineup information is not available yet.</p>
      ) : (
        <>
          {/* Players lists */}
          <div className="mb-4">
            <h3 className="text-md font-semibold mb-2">Starting Lineup</h3>
            <div className="grid grid-cols-2 gap-3">
              {activeTeam === 'home' && match.lineup.home?.starting_lineups?.map((player, index) => (
                <PlayerItem key={`home-starting-${player.player_id || index}`} player={player} />
              ))}
              
              {activeTeam === 'away' && match.lineup.away?.starting_lineups?.map((player, index) => (
                <PlayerItem key={`away-starting-${player.player_id || index}`} player={player} />
              ))}
              
              {activeTeam === 'home' && (!match.lineup.home?.starting_lineups || match.lineup.home.starting_lineups.length === 0) && (
                <p className="text-muted-foreground col-span-2 text-center">No starting lineup available.</p>
              )}
              
              {activeTeam === 'away' && (!match.lineup.away?.starting_lineups || match.lineup.away.starting_lineups.length === 0) && (
                <p className="text-muted-foreground col-span-2 text-center">No starting lineup available.</p>
              )}
            </div>
          </div>
          
          {/* Substitutes, Coach, and Missing Players Tabs */}
          <Tabs defaultValue="substitutes" className="mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="substitutes">Substitutes</TabsTrigger>
              <TabsTrigger value="coach">Coach</TabsTrigger>
              <TabsTrigger value="missing">Missing</TabsTrigger>
            </TabsList>
            
            <TabsContent value="substitutes" className="mt-3">
              <div className="grid grid-cols-2 gap-3">
                {activeTeam === 'home' && match.lineup.home?.substitutes?.map((player, index) => (
                  <PlayerItem key={`home-sub-${player.player_id || index}`} player={player} isSubstitute />
                ))}
                
                {activeTeam === 'away' && match.lineup.away?.substitutes?.map((player, index) => (
                  <PlayerItem key={`away-sub-${player.player_id || index}`} player={player} isSubstitute />
                ))}
                
                {activeTeam === 'home' && (!match.lineup.home?.substitutes || match.lineup.home.substitutes.length === 0) && (
                  <p className="text-muted-foreground col-span-2 text-center">No substitutes available.</p>
                )}
                
                {activeTeam === 'away' && (!match.lineup.away?.substitutes || match.lineup.away.substitutes.length === 0) && (
                  <p className="text-muted-foreground col-span-2 text-center">No substitutes available.</p>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="coach" className="mt-3">
              {activeTeam === 'home' && match.lineup.home?.coach?.map((coach, index) => (
                <CoachItem key={`home-coach-${index}`} coach={coach} />
              ))}
              
              {activeTeam === 'away' && match.lineup.away?.coach?.map((coach, index) => (
                <CoachItem key={`away-coach-${index}`} coach={coach} />
              ))}
              
              {activeTeam === 'home' && (!match.lineup.home?.coach || match.lineup.home.coach.length === 0) && (
                <p className="text-muted-foreground text-center">No coach information available.</p>
              )}
              
              {activeTeam === 'away' && (!match.lineup.away?.coach || match.lineup.away.coach.length === 0) && (
                <p className="text-muted-foreground text-center">No coach information available.</p>
              )}
            </TabsContent>
            
            <TabsContent value="missing" className="mt-3">
              {activeTeam === 'home' && match.lineup.home?.missing_players?.map((player, index) => (
                <MissingPlayerItem key={`home-missing-${player.player_id || index}`} player={player} />
              ))}
              
              {activeTeam === 'away' && match.lineup.away?.missing_players?.map((player, index) => (
                <MissingPlayerItem key={`away-missing-${player.player_id || index}`} player={player} />
              ))}
              
              {activeTeam === 'home' && (!match.lineup.home?.missing_players || match.lineup.home.missing_players.length === 0) && (
                <p className="text-muted-foreground text-center">No missing players information.</p>
              )}
              
              {activeTeam === 'away' && (!match.lineup.away?.missing_players || match.lineup.away.missing_players.length === 0) && (
                <p className="text-muted-foreground text-center">No missing players information.</p>
              )}
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}

// Helper Components for Player Display
const PlayerItem = ({ player, isSubstitute = false }: { player: LineupPlayer; isSubstitute?: boolean }) => {
  // Handle display of empty or "unknown" player data by providing default values
  const playerName = player.player && player.player !== "unknown" ? player.player : "No Name";
  const playerNumber = player.player_number || '?';
  const playerPosition = player.player_position || '';
  
  return (
    <div className="flex items-center">
      <div className={`w-8 h-8 rounded-full overflow-hidden border-2 border-secondary mr-2 ${isSubstitute ? 'opacity-80' : ''}`}>
        <div className="w-full h-full bg-card flex items-center justify-center text-xs font-bold">
          {playerNumber}
        </div>
      </div>
      <div>
        <span className="text-xs font-semibold bg-secondary px-1.5 py-0.5 rounded text-secondary-foreground">
          {playerNumber}
        </span>
        <span className="text-sm ml-2">{playerName}</span>
        {playerPosition && (
          <span className="text-xs text-muted-foreground ml-1">({playerPosition})</span>
        )}
      </div>
    </div>
  );
};

const CoachItem = ({ coach }: { coach: any }) => {
  // Handle display of empty or "unknown" coach data
  const coachName = coach.coach && coach.coach !== "unknown" ? coach.coach : "No Coach Info";
  const coachCountry = coach.coach_country && coach.coach_country !== "unknown" ? coach.coach_country : "";
  
  return (
    <div className="flex items-center">
      <div className="w-10 h-10 rounded-full overflow-hidden mr-3 bg-secondary flex items-center justify-center">
        <span className="text-xs">Coach</span>
      </div>
      <div>
        <span className="text-sm font-medium">{coachName}</span>
        {coachCountry && (
          <div className="flex items-center text-xs text-muted-foreground">
            {coachCountry}
          </div>
        )}
      </div>
    </div>
  );
};

const MissingPlayerItem = ({ player }: { player: any }) => {
  // Handle empty or "unknown" missing player data
  const playerName = player.player && player.player !== "unknown" ? player.player : "No Player Info";
  const playerReason = player.player_reason && player.player_reason !== "unknown" ? player.player_reason : "";
  
  return (
    <div className="flex items-center mb-2">
      <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-secondary mr-2 opacity-50">
        <div className="w-full h-full bg-card flex items-center justify-center text-xs font-bold">
          ?
        </div>
      </div>
      <div>
        <span className="text-sm opacity-70">{playerName}</span>
        {playerReason && (
          <span className="text-xs text-muted-foreground ml-2">({playerReason})</span>
        )}
      </div>
    </div>
  );
};

function Football({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 512 512" 
      className={className}
      fill="currentColor"
    >
      <path d="M417.3 360.1l-71.6-4.8c-5.2-.3-10.3 1.1-14.5 4.2s-7.2 7.4-8.4 12.5l-17.6 69.6C289.5 445.8 273 448 256 448s-33.5-2.2-49.2-6.4L189.2 372c-1.3-5-4.3-9.4-8.4-12.5s-9.3-4.5-14.5-4.2l-71.6 4.8c-17.6-27.2-28.5-59.2-30.4-93.6L125 218.6c4.4-2.8 7.6-7 9.2-11.9s1.4-10.2-.5-15l-26.7-66.6C128 109.2 151.7 96 178.3 96h14.6c6.4 0 12.3-3.2 15.8-8.5s4.2-12 1.6-17.7l-14.6-32.7C205.9 34.5 216 33 226.3 32h0 0 59.4 0 0c10.3 1 20.4 2.5 30.1 5.1L301.2 69.8c-2.6 5.7-1.9 12.4 1.6 17.7s9.4 8.5 15.8 8.5h14.6c26.7 0 50.3 13.2 65.1 33.6l-26.7 66.6c-1.9 4.8-2 10.1-.5 15s4.8 9.1 9.2 11.9l60.8 39c-1.9 34.4-12.8 66.4-30.4 93.6zM256 512c141.4 0 256-114.6 256-256S397.4 0 256 0S0 114.6 0 256S114.6 512 256 512zm14.1-325.7c-8.4-6.1-19.8-6.1-28.2 0L194 221c-8.4 6.1-11.9 16.9-8.7 26.8l18.3 56.3c3.2 9.9 12.4 16.6 22.8 16.6h59.2c10.4 0 19.6-6.7 22.8-16.6l18.3-56.3c3.2-9.9-.3-20.7-8.7-26.8l-47.9-34.8z"/>
    </svg>
  );
}