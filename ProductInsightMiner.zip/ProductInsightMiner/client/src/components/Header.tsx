import React from 'react';
import { useLocation } from 'wouter';
import { Bell, ArrowLeft } from 'lucide-react';
import { cn } from '@/lib/utils';
import SearchBar from './SearchBar';

interface HeaderProps {
  title?: string;
  showBack?: boolean;
  onSearch?: () => void;
  className?: string;
}

export default function Header({ title = 'Sibola', showBack = false, onSearch, className }: HeaderProps) {
  const [, setLocation] = useLocation();
  
  const handleBackClick = () => {
    window.history.back();
  };
  
  return (
    <header className={cn("bg-card z-10 shadow-md", className)}>
      <div className="flex justify-between items-center p-4">
        <div className="flex items-center">
          {showBack ? (
            <button 
              onClick={handleBackClick}
              className="p-1 mr-3 rounded-full hover:bg-secondary"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
          ) : (
            <div onClick={() => setLocation('/')} className="flex items-center cursor-pointer">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-bold mr-2">
                  S
                </div>
                <h1 className="text-xl font-bold">{title}</h1>
            </div>
          )}
          
          {showBack && <h1 className="text-lg font-semibold">{title}</h1>}
        </div>
        
        <div className="flex space-x-3 items-center">
          <SearchBar className="w-auto" />
          
          <button className="text-muted-foreground hover:text-foreground transition-colors">
            <Bell className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
}
