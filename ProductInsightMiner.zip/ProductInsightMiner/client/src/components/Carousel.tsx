import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CarouselProps {
  children: React.ReactNode[];
  autoSlide?: boolean;
  autoSlideInterval?: number;
  className?: string;
  showControls?: boolean;
}

export default function Carousel({ 
  children, 
  autoSlide = false, 
  autoSlideInterval = 5000,
  className,
  showControls = true
}: CarouselProps) {
  const [curr, setCurr] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const prev = () => setCurr((curr) => (curr === 0 ? children.length - 1 : curr - 1));
  const next = () => setCurr((curr) => (curr === children.length - 1 ? 0 : curr + 1));

  useEffect(() => {
    if (!autoSlide) return;
    
    const slideInterval = setInterval(next, autoSlideInterval);
    return () => clearInterval(slideInterval);
  }, [autoSlide, autoSlideInterval]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setStartX(e.pageX - (containerRef.current?.offsetLeft || 0));
    setScrollLeft(containerRef.current?.scrollLeft || 0);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const x = e.pageX - (containerRef.current?.offsetLeft || 0);
    const walk = (x - startX) * 2; // Scroll speed multiplier
    
    if (containerRef.current) {
      containerRef.current.scrollLeft = scrollLeft - walk;
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    
    if (!containerRef.current) return;
    
    // Calculate which slide we're closest to
    const slideWidth = containerRef.current.clientWidth;
    const currentIndex = Math.round(containerRef.current.scrollLeft / slideWidth);
    setCurr(currentIndex);
  };

  // Scroll to the active slide
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTo({
        left: curr * containerRef.current.clientWidth,
        behavior: 'smooth'
      });
    }
  }, [curr]);

  return (
    <div className={cn("relative overflow-hidden", className)}>
      <div 
        ref={containerRef}
        className="flex transition-transform ease-out duration-500 overflow-x-auto scrollbar-hide snap-x snap-mandatory no-scrollbar"
        style={{ scrollSnapType: 'x mandatory' }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {children.map((child, index) => (
          <div 
            key={index} 
            className="min-w-full flex-shrink-0 flex-grow-0 snap-center"
          >
            {child}
          </div>
        ))}
      </div>
      
      {showControls && children.length > 1 && (
        <>
          <button
            onClick={prev}
            className="absolute left-2 top-1/2 -translate-y-1/2 p-1 rounded-full bg-black/30 text-white hover:bg-black/50 z-10"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={next}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full bg-black/30 text-white hover:bg-black/50 z-10"
          >
            <ChevronRight size={20} />
          </button>
        </>
      )}
      
      <div className="absolute bottom-2 left-0 right-0 flex items-center justify-center gap-1">
        {children.length > 1 && children.map((_, i) => (
          <div
            key={i}
            className={cn(
              "w-1.5 h-1.5 rounded-full transition-all",
              curr === i ? "bg-white" : "bg-white/50"
            )}
            onClick={() => setCurr(i)}
          />
        ))}
      </div>
    </div>
  );
}
