import React, { useState, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';
import { useLocation } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface SearchBarProps {
  placeholder?: string;
  className?: string;
  onSearch?: (query: string) => void;
}

export default function SearchBar({ 
  placeholder = 'Search matches, teams or players...', 
  className,
  onSearch 
}: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [, setLocation] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    if (isExpanded && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isExpanded]);
  
  const handleClear = () => {
    setQuery('');
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      if (onSearch) {
        onSearch(query);
      } else {
        // Default: redirect to search page
        setLocation(`/search?q=${encodeURIComponent(query)}`);
      }
    }
  };
  
  return (
    <div className={cn("relative", className)}>
      {isExpanded ? (
        <form 
          onSubmit={handleSubmit} 
          className="flex items-center w-full animate-in fade-in duration-200"
        >
          <Input
            ref={inputRef}
            type="text"
            placeholder={placeholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pr-12"
          />
          
          {query && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-8"
              onClick={handleClear}
            >
              <X size={18} />
              <span className="sr-only">Clear</span>
            </Button>
          )}
          
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="absolute right-0"
            onClick={() => setIsExpanded(false)}
          >
            <X size={18} />
            <span className="sr-only">Close</span>
          </Button>
        </form>
      ) : (
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsExpanded(true)}
          className="ml-auto"
        >
          <Search size={18} />
          <span className="sr-only">Search</span>
        </Button>
      )}
    </div>
  );
}