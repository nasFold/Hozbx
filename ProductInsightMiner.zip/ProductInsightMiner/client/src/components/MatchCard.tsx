import React from 'react';
import { useLocation } from 'wouter';
import { Match } from '@/lib/types';
import LiveIndicator from './LiveIndicator';
import MatchPinButton from './MatchPinButton';
import { formatTime } from '@/lib/api';
import { cn } from '@/lib/utils';

interface MatchCardProps {
  match: Match;
  compact?: boolean;
  className?: string;
}

export default function MatchCard({ match, compact = false, className }: MatchCardProps) {
  const [, setLocation] = useLocation();

  const isLive = match.match_live === '1';
  const hasStarted = match.match_status !== '' && match.match_status !== 'NS';
  const isFinished = match.match_status === 'FT' || match.match_status === 'AP';

  const homeScore = match.match_hometeam_score || '0';
  const awayScore = match.match_awayteam_score || '0';

  const getScorers = () => {
    if (!match.goalscorer || match.goalscorer.length === 0) return null;

    const homeScorers = match.goalscorer
      .filter(goal => goal.home_scorer)
      .map(goal => `${goal.home_scorer} ${goal.time}'`);

    const awayScorers = match.goalscorer
      .filter(goal => goal.away_scorer)
      .map(goal => `${goal.away_scorer} ${goal.time}'`);

    return { homeScorers, awayScorers };
  };

  const scorers = getScorers();

  const getStatusText = () => {
    if (isLive) return match.match_status;
    if (isFinished) return 'FT';
    if (!hasStarted) {
      try {
        // Untuk match yang belum dimulai, tunjukkan tanggalnya, bukan waktu
        if (match.match_date) {
          const date = new Date(match.match_date);
          if (!isNaN(date.getTime())) {
            return date.toLocaleDateString(undefined, { 
              day: 'numeric',
              month: 'short'
            });
          }
        }
        // Fallback jika tanggal tidak valid
        return 'TBD';
      } catch (e) {
        // Fallback to raw time if formatting fails
        console.warn(`Error formatting date for match ${match.match_id}:`, e);
        return 'TBD';
      }
    }
    return match.match_status;
  };

  const handleClick = (e: React.MouseEvent) => {
    // Don't navigate if clicking on the pin button
    if ((e.target as Element).closest('.pin-button')) {
      e.stopPropagation();
      return;
    }
    setLocation(`/match/${match.match_id}`);
  };

  const getUserTimezone = () => {
    try {
      // Get timezone from browser
      const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Makassar';
      console.log(`User timezone: ${timezone}`);
      return timezone;
    } catch (error) {
      console.error('Error getting timezone:', error);
      // Default to Asia/Makassar for Indonesian users
      return 'Asia/Makassar';
    }
  };


  if (compact) {
    return (
      <div 
        className={cn("match-card bg-card rounded-lg shadow p-3 flex items-center justify-between cursor-pointer", className)}
        onClick={handleClick}
      >
        <div className="flex items-center space-x-3 w-[42%]">
          <img 
            src={match.team_home_badge} 
            alt={match.match_hometeam_name} 
            className="w-8 h-8 object-contain"
            onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/32/121F3D/FFFFFF?text=Team' }}
          />
          <span className="text-sm font-medium truncate">{match.match_hometeam_name}</span>
        </div>

        <div className="flex flex-col items-center min-w-[16%]">
          {hasStarted ? (
            <div className="flex space-x-2 text-sm font-bold">
              <span>{homeScore}</span>
              <span>-</span>
              <span>{awayScore}</span>
            </div>
          ) : (
            <div className="flex space-x-2 text-sm font-medium text-muted-foreground">
              <span>
                  {match.match_time ? 
                    (() => {
                      try {
                        const userTimezone = getUserTimezone();
                        const formattedTime = formatTime(match.match_time, match.match_date, userTimezone);
                        // Debug timezone info
                        console.log(`Match: ${match.match_hometeam_name} vs ${match.match_awayteam_name}`);
                        console.log(`Original time: ${match.match_time} on ${match.match_date}`);
                        console.log(`Formatted time: ${formattedTime}`);
                        console.log(`User timezone: ${userTimezone}`);
                        return formattedTime;
                      } catch (e) {
                        return match.match_time;
                      }
                    })() 
                  : 'TBD'}
              </span>
            </div>
          )}
          <span className="text-xs text-muted-foreground">
            {hasStarted ? getStatusText() : ''}
          </span>
        </div>

        <div className="flex items-center justify-end space-x-3 w-[42%]">
          <span className="text-sm font-medium truncate text-right">{match.match_awayteam_name}</span>
          <img 
            src={match.team_away_badge} 
            alt={match.match_awayteam_name} 
            className="w-8 h-8 object-contain"
            onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/32/121F3D/FFFFFF?text=Team' }}
          />
        </div>
      </div>
    );
  }

  return (
    <div 
      className={cn("match-card flex-shrink-0 w-80 bg-card p-4 rounded-xl shadow-lg shadow-muted/20 cursor-pointer", className)}
      onClick={handleClick}
    >
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center">
          {isLive ? (
            <LiveIndicator size="sm" />
          ) : (
            <span className="text-xs bg-secondary px-2 py-0.5 rounded-full text-muted-foreground font-medium">
              {match.league_name}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <div className="text-xs text-muted-foreground">{getStatusText()}</div>
          <MatchPinButton match={match} size="sm" iconOnly variant="ghost" />
        </div>
      </div>

      <div className="flex items-center justify-between">
        {/* Home Team */}
        <div className="flex flex-col items-center text-center w-[40%]">
          <div className="w-12 h-12 flex items-center justify-center">
            <img 
              src={match.team_home_badge} 
              alt={match.match_hometeam_name} 
              className="w-10 h-10 object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40/121F3D/FFFFFF?text=Team' }}
            />
          </div>
          <p className="mt-1 text-sm font-medium line-clamp-1">{match.match_hometeam_name}</p>
        </div>

        {/* Score */}
        <div className="flex flex-col items-center min-w-[20%]">
          {hasStarted ? (
            <>
              <div className="flex items-center text-xl font-bold">
                <span>{homeScore}</span>
                <span className="mx-1">-</span>
                <span>{awayScore}</span>
              </div>
              {match.match_hometeam_halftime_score && (
                <div className="text-xs text-muted-foreground mt-1">
                  HT: {match.match_hometeam_halftime_score}-{match.match_awayteam_halftime_score}
                </div>
              )}
            </>
          ) : (
            <div className="flex items-center text-base font-medium text-muted-foreground">
              vs
            </div>
          )}
        </div>

        {/* Away Team */}
        <div className="flex flex-col items-center text-center w-[40%]">
          <div className="w-12 h-12 flex items-center justify-center">
            <img 
              src={match.team_away_badge} 
              alt={match.match_awayteam_name} 
              className="w-10 h-10 object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40/121F3D/FFFFFF?text=Team' }}
            />
          </div>
          <p className="mt-1 text-sm font-medium line-clamp-1">{match.match_awayteam_name}</p>
        </div>
      </div>

      {/* Goals or Stadium Info */}
      {scorers && (scorers.homeScorers.length > 0 || scorers.awayScorers.length > 0) ? (
        <div className="mt-3 pt-3 border-t border-border text-xs">
          <div className="flex justify-between">
            <div className="text-muted-foreground">
              {scorers.homeScorers.map((scorer, index) => (
                <div key={`home-${index}`}>
                  {scorer} <i className="fas fa-futbol text-primary ml-1"></i>
                </div>
              ))}
            </div>
            <div className="text-muted-foreground text-right">
              {scorers.awayScorers.map((scorer, index) => (
                <div key={`away-${index}`}>
                  {scorer} <i className="fas fa-futbol text-primary ml-1"></i>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : !hasStarted && match.match_stadium ? (
        <div className="mt-3 pt-3 border-t border-border text-xs">
          <div className="text-center text-muted-foreground">
            <div>{match.match_stadium}</div>
          </div>
        </div>
      ) : null}
    </div>
  );
}