import React from 'react';
import { cn } from '@/lib/utils';
import Header from './Header';
import BottomNavigation from './BottomNavigation';

interface PageContainerProps {
  children: React.ReactNode;
  className?: string;
  showHeader?: boolean;
  showBottomNav?: boolean;
  showBack?: boolean;
  title?: string;
  onSearch?: () => void;
  noPadding?: boolean;
}

export default function PageContainer({
  children,
  className,
  showHeader = true,
  showBottomNav = true,
  showBack = false,
  title,
  onSearch,
  noPadding = false
}: PageContainerProps) {
  return (
    <div className="max-w-md mx-auto bg-background h-screen flex flex-col overflow-hidden">
      {showHeader && (
        <div className="flex-shrink-0">
          <Header 
            title={title} 
            showBack={showBack} 
            onSearch={onSearch} 
          />
        </div>
      )}
      
      <main className={cn(
        "animate-fade-in overflow-y-auto flex-1 pb-16", // add bottom padding for navigation
        !noPadding && "px-4 py-2",
        className
      )}>
        {children}
      </main>
      
      {showBottomNav && (
        <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40">
          <BottomNavigation />
        </div>
      )}
    </div>
  );
}
