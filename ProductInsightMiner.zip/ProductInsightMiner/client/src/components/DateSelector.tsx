import React, { useEffect, useState, useRef } from 'react';
import { format, addDays, isSameDay, startOfDay } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DateSelectorProps {
  onChange: (date: Date) => void;
  selectedDate: Date;
  className?: string;
  daysToShow?: number;
}

export default function DateSelector({ 
  onChange, 
  selectedDate, 
  className,
  daysToShow = 7 
}: DateSelectorProps) {
  const [dates, setDates] = useState<Date[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Generate dates array with range 7 days back and 7 days forward
  useEffect(() => {
    const today = startOfDay(new Date());
    const dateArray = [];
    
    // Add 7 days backwards and 7 days forward from today
    for (let i = -7; i <= 7; i++) {
      dateArray.push(addDays(today, i));
    }
    
    setDates(dateArray);
  }, []);
  
  // Scroll to selected date
  useEffect(() => {
    if (containerRef.current && dates.length > 0) {
      const index = dates.findIndex(date => isSameDay(date, selectedDate));
      if (index !== -1) {
        const scrollAmount = index * 64; // Approximate width of date item
        containerRef.current.scrollLeft = scrollAmount - 120; // Center it
      }
    }
  }, [selectedDate, dates]);

  // Handle scroll navigation
  const scroll = (direction: 'left' | 'right') => {
    if (containerRef.current) {
      const scrollAmount = direction === 'left' ? -200 : 200;
      containerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const handleDateClick = (date: Date) => {
    onChange(date);
  };

  const isToday = (date: Date) => {
    return isSameDay(date, new Date());
  };

  const isSelected = (date: Date) => {
    return isSameDay(date, selectedDate);
  };

  return (
    <div className={cn("relative", className)}>
      <button 
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-card/80 rounded-r-lg p-1"
        onClick={() => scroll('left')}
      >
        <ChevronLeft size={16} />
      </button>

      <div 
        ref={containerRef}
        className="flex overflow-x-auto space-x-3 py-2 px-8 no-scrollbar"
      >
        {dates.map((date, index) => (
          <div 
            key={index}
            className={cn(
              "flex flex-col items-center px-3 py-2 rounded-lg cursor-pointer min-w-[64px] transition-colors",
              isSelected(date) ? "bg-primary text-primary-foreground" : "bg-secondary",
              isToday(date) && !isSelected(date) && "border border-primary"
            )}
            onClick={() => handleDateClick(date)}
          >
            <span className="text-xs text-muted-foreground uppercase">
              {format(date, 'EEE')}
            </span>
            <span className="text-base font-medium">
              {format(date, 'dd')}
            </span>
          </div>
        ))}
      </div>

      <button 
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-card/80 rounded-l-lg p-1"
        onClick={() => scroll('right')}
      >
        <ChevronRight size={16} />
      </button>
    </div>
  );
}
