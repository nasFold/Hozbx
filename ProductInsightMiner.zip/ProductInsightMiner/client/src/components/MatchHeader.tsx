import React from 'react';
import { Match } from '@/lib/types';
import { cn } from '@/lib/utils';
import LiveIndicator from './LiveIndicator';
import { formatTime } from '@/lib/api';
import { Link } from 'wouter';

interface MatchHeaderProps {
  match: Match;
  className?: string;
  compact?: boolean;
}

export default function MatchHeader({ match, className, compact = false }: MatchHeaderProps) {
  const isLive = match.match_live === '1';
  const hasStarted = match.match_status !== '' && match.match_status !== 'NS';
  const isFinished = match.match_status === 'FT' || match.match_status === 'AP';

  const homeScore = match.match_hometeam_score || '0';
  const awayScore = match.match_awayteam_score || '0';

  const formattedDate = (() => {
    if (!match.match_date) return 'TBD';

    try {
      // Check if the date is in YYYY-MM-DD format
      if (/^\d{4}-\d{2}-\d{2}$/.test(match.match_date)) {
        const [year, month, day] = match.match_date.split('-').map(Number);
        const date = new Date(year, month - 1, day); // month is 0-indexed in JS

        if (isNaN(date.getTime())) {
          return match.match_date; // Return original if date is invalid
        }

        return date.toLocaleDateString(undefined, {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        });
      }

      // Try standard date parsing as fallback
      const date = new Date(match.match_date);
      if (isNaN(date.getTime())) {
        return match.match_date; // Return original if parsing fails
      }

      return date.toLocaleDateString(undefined, {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    } catch (error) {
      console.warn(`Error formatting match date: ${match.match_date}`, error);
      return match.match_date;
    }
  })();


  if (compact) {
    return (
      <div className={cn("bg-card px-4 py-3 shadow-md", className)}>
        <div className="flex items-center justify-between mb-1">
          <Link href={`/league/${match.league_id}`} className="flex items-center space-x-2 hover:underline">
            <img 
              src={match.league_logo} 
              alt={match.league_name} 
              className="w-5 h-5 object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/20/121F3D/FFFFFF?text=L' }}
            />
            <span className="text-sm text-muted-foreground">
              {match.league_name} • {match.match_round ? `Matchday ${match.match_round}` : 'Match'}
            </span>
          </Link>

          {isLive && <LiveIndicator size="sm" />}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 flex-1 justify-end text-right">
            <p className="text-base font-medium">{match.match_hometeam_name}</p>
            <img 
              src={match.team_home_badge} 
              alt={match.match_hometeam_name} 
              className="w-8 h-8 object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/32/121F3D/FFFFFF?text=Team' }}
            />
          </div>

          <div className="flex flex-col items-center mx-4 min-w-[60px]">
            {hasStarted ? (
              <div className="flex items-center text-xl font-bold">
                <span>{homeScore}</span>
                <span className="mx-1">-</span>
                <span>{awayScore}</span>
              </div>
            ) : (
              <div className="text-base font-medium text-muted-foreground">
                {formatTime(match.match_time, match.match_date)}
              </div>
            )}
            <span className="text-xs text-muted-foreground">
              {isLive ? match.match_status : isFinished ? 'FT' : formattedDate}
            </span>
          </div>

          <div className="flex items-center space-x-3 flex-1">
            <img 
              src={match.team_away_badge} 
              alt={match.match_awayteam_name} 
              className="w-8 h-8 object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/32/121F3D/FFFFFF?text=Team' }}
            />
            <p className="text-base font-medium">{match.match_awayteam_name}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("bg-card px-4 py-3 shadow-lg shadow-neutral-dark/20", className)}>
      <div className="flex items-center justify-between mb-3">
        <Link href={`/league/${match.league_id}`} className="flex items-center space-x-2 hover:underline">
          <img 
            src={match.league_logo} 
            alt={match.league_name} 
            className="w-5 h-5 object-contain"
            onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/20/121F3D/FFFFFF?text=L' }}
          />
          <span className="text-sm text-muted-foreground">
            {match.league_name} • {match.match_round ? `Matchday ${match.match_round}` : 'Match'}
          </span>
        </Link>

        {isLive && <LiveIndicator />}
      </div>

      <div className="flex items-center justify-between">
        {/* Home Team */}
        <div className="flex flex-col items-center text-center w-[40%]">
          <div className="w-16 h-16 flex items-center justify-center">
            <img 
              src={match.team_home_badge} 
              alt={match.match_hometeam_name} 
              className="w-14 h-14 object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/56/121F3D/FFFFFF?text=Team' }}
            />
          </div>
          <p className="mt-1 text-base font-medium">{match.match_hometeam_name}</p>
        </div>

        {/* Score */}
        <div className="flex flex-col items-center min-w-[20%]">
          {hasStarted ? (
            <>
              <div className="flex items-center text-2xl font-bold">
                <span>{homeScore}</span>
                <span className="mx-1">-</span>
                <span>{awayScore}</span>
              </div>
              <div className={cn(
                "text-xs mt-1",
                isLive ? "text-primary font-medium animate-pulse" : "text-muted-foreground"
              )}>
                {isLive ? match.match_status : 'FT'}
              </div>
              {match.match_hometeam_halftime_score && (
                <div className="text-xs text-muted-foreground">
                  HT: {match.match_hometeam_halftime_score}-{match.match_awayteam_halftime_score}
                </div>
              )}
            </>
          ) : (
            <>
              <div className="text-lg font-medium text-muted-foreground">
                {formatTime(match.match_time, match.match_date)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {formattedDate}
              </div>
            </>
          )}
        </div>

        {/* Away Team */}
        <div className="flex flex-col items-center text-center w-[40%]">
          <div className="w-16 h-16 flex items-center justify-center">
            <img 
              src={match.team_away_badge} 
              alt={match.match_awayteam_name} 
              className="w-14 h-14 object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/56/121F3D/FFFFFF?text=Team' }}
            />
          </div>
          <p className="mt-1 text-base font-medium">{match.match_awayteam_name}</p>
        </div>
      </div>

      {/* Match Info */}
      <div className="mt-3 text-xs text-muted-foreground text-center">
        {match.match_stadium && <p>{match.match_stadium}, {match.country_name}</p>}
        {match.match_referee && <p>Referee: {match.match_referee}</p>}
      </div>
    </div>
  );
}