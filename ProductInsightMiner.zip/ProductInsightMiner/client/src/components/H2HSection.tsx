import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Match } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatRelativeDate } from '@/lib/api';

interface H2HSectionProps {
  match: Match;
  className?: string;
}

export default function H2HSection({ match, className }: H2HSectionProps) {
  const { data: h2hData, isLoading, error } = useQuery({
    queryKey: ['/api/football/h2h', { firstTeam_id: match.match_hometeam_id, secondTeam_id: match.match_awayteam_id }],
    queryFn: async () => {
      if (!match.match_hometeam_id || !match.match_awayteam_id) {
        throw new Error("Both team IDs are required");
      }
      // Pastikan parameter sesuai dengan yang diharapkan API
      const response = await fetch(`/api/football/h2h?firstTeam_id=${match.match_hometeam_id}&secondTeam_id=${match.match_awayteam_id}`);
      console.log("H2H request sent with params:", match.match_hometeam_id, match.match_awayteam_id);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error("H2H API error:", errorText);
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      return response.json();
    },
    enabled: !!match.match_hometeam_id && !!match.match_awayteam_id,
    retry: 1,
  });
  
  const [stats, setStats] = useState({
    total: 0,
    homeWins: 0,
    draws: 0,
    awayWins: 0,
  });
  
  useEffect(() => {
    if (h2hData && h2hData.firstTeam_VS_secondTeam && Array.isArray(h2hData.firstTeam_VS_secondTeam)) {
      const matches = h2hData.firstTeam_VS_secondTeam;
      let homeWins = 0;
      let draws = 0;
      let awayWins = 0;
      
      matches.forEach((m: any) => {
        const homeScore = parseInt(m.match_hometeam_score);
        const awayScore = parseInt(m.match_awayteam_score);
        
        if (homeScore > awayScore) {
          if (m.match_hometeam_id === match.match_hometeam_id) {
            homeWins++;
          } else {
            awayWins++;
          }
        } else if (homeScore < awayScore) {
          if (m.match_awayteam_id === match.match_hometeam_id) {
            homeWins++;
          } else {
            awayWins++;
          }
        } else {
          draws++;
        }
      });
      
      setStats({
        total: matches.length,
        homeWins,
        draws,
        awayWins,
      });
    }
  }, [h2hData, match]);
  
  if (isLoading) {
    return (
      <Card className={cn("bg-card shadow", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Head-to-Head</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Skeleton className="w-full h-6" />
            <Skeleton className="w-full h-24" />
            <Skeleton className="w-full h-6" />
            <Skeleton className="w-full h-24" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (error || !h2hData) {
    return (
      <Card className={cn("bg-card shadow", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Head-to-Head</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-4">
            Head-to-head information is not available.
          </p>
        </CardContent>
      </Card>
    );
  }
  
  const hasH2H = h2hData && h2hData.firstTeam_VS_secondTeam && Array.isArray(h2hData.firstTeam_VS_secondTeam) && h2hData.firstTeam_VS_secondTeam.length > 0;
  
  return (
    <Card className={cn("bg-card shadow", className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Head-to-Head</CardTitle>
      </CardHeader>
      <CardContent>
        {hasH2H ? (
          <>
            <div className="flex justify-between items-center mb-4">
              <div className="text-center">
                <div className="text-lg font-bold text-primary">{stats.homeWins}</div>
                <div className="text-xs text-muted-foreground">{match.match_hometeam_name}</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold">{stats.draws}</div>
                <div className="text-xs text-muted-foreground">Draws</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-destructive">{stats.awayWins}</div>
                <div className="text-xs text-muted-foreground">{match.match_awayteam_name}</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold">{stats.total}</div>
                <div className="text-xs text-muted-foreground">Total</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Previous Matches</h3>
              {hasH2H && h2hData.firstTeam_VS_secondTeam.slice(0, 5).map((h2hMatch: any, index: number) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-border">
                  <div className="flex items-center space-x-3">
                    <div className="text-xs text-muted-foreground">
                      {formatRelativeDate(h2hMatch.match_date)}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-sm font-medium">
                      {h2hMatch.match_hometeam_name}
                    </span>
                    <div className="px-2 text-sm font-bold">
                      {h2hMatch.match_hometeam_score} - {h2hMatch.match_awayteam_score}
                    </div>
                    <span className="text-sm font-medium">
                      {h2hMatch.match_awayteam_name}
                    </span>
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    {h2hMatch.league_name}
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-muted-foreground text-center py-4">
            No previous matches found between these teams.
          </p>
        )}
      </CardContent>
    </Card>
  );
}