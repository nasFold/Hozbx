import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

interface StatDoughnutProps {
  homeStat: number | string;
  awayStat: number | string;
  label: string;
  className?: string;
}

export default function StatDoughnut({ 
  homeStat, 
  awayStat, 
  label, 
  className 
}: StatDoughnutProps) {
  // Convert stats to numbers if they're strings
  const homeValue = typeof homeStat === 'string' ? parseFloat(homeStat) || 0 : homeStat;
  const awayValue = typeof awayStat === 'string' ? parseFloat(awayStat) || 0 : awayStat;
  
  // Create data for the pie chart
  const data = [
    { name: 'Home', value: homeValue },
    { name: 'Away', value: awayValue }
  ];
  
  // Calculate total
  const total = homeValue + awayValue;
  const homePercent = total > 0 ? Math.round((homeValue / total) * 100) : 0;
  const awayPercent = total > 0 ? Math.round((awayValue / total) * 100) : 0;
  
  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div className="relative w-32 h-32">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={30}
              outerRadius={40}
              paddingAngle={0}
              dataKey="value"
              startAngle={90}
              endAngle={-270}
            >
              <Cell fill="hsl(var(--primary))" />
              <Cell fill="hsl(var(--destructive))" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-lg font-bold">
            {homePercent}%
          </span>
          <span className="text-xs text-muted-foreground">
            {label}
          </span>
        </div>
      </div>
      
      <div className="flex justify-between w-full mt-2">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-primary rounded-sm mr-1"></div>
          <span className="text-sm">{homeStat}</span>
        </div>
        <div className="flex items-center">
          <span className="text-sm">{awayStat}</span>
          <div className="w-3 h-3 bg-destructive rounded-sm ml-1"></div>
        </div>
      </div>
    </div>
  );
}
