import React, { useState } from 'react';
import { Pin, PinOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/api';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { cn } from '@/lib/utils';

interface MatchPinButtonProps {
  match: any; // Match data
  className?: string;
  size?: 'sm' | 'default' | 'lg';
  variant?: 'default' | 'outline' | 'ghost';
  iconOnly?: boolean;
}

export default function MatchPinButton({ 
  match, 
  className,
  size = 'default',
  variant = 'outline',
  iconOnly = false
}: MatchPinButtonProps) {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if user is authenticated
  const { data: user } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/auth/me');
        const data = await res.json();
        return data;
      } catch (error) {
        return null;
      }
    }
  });

  // Get pinned matches
  const { data: pinnedMatchesData } = useQuery({
    queryKey: ['/api/user/pinned-matches'],
    queryFn: async () => {
      if (!user) return { pinnedMatches: [] };
      try {
        const res = await apiRequest('GET', '/api/user/pinned-matches');
        const data = await res.json();
        return data as { pinnedMatches: any[] };
      } catch (error) {
        return { pinnedMatches: [] };
      }
    },
    enabled: !!user
  });

  const pinnedMatches = pinnedMatchesData?.pinnedMatches || [];
  const isPinned = pinnedMatches.some((m: any) => m.match_id === match.match_id);

  // Pin match mutation
  const pinMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/user/pinned-matches', match);
      const data = await res.json();
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['/api/user/pinned-matches']});
      toast({
        title: 'Match pinned',
        description: 'Match has been added to your pinned matches',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to pin match',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    }
  });

  // Unpin match mutation
  const unpinMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('DELETE', `/api/user/pinned-matches/${match.match_id}`);
      const data = await res.json();
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ['/api/user/pinned-matches']});
      toast({
        title: 'Match unpinned',
        description: 'Match has been removed from your pinned matches',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to unpin match',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    }
  });

  const handleTogglePin = () => {
    if (!user) {
      setIsAuthModalOpen(true);
      toast({
        title: 'Authentication required',
        description: 'Please log in to pin matches',
        variant: 'destructive',
      });
      return;
    }

    if (isPinned) {
      unpinMutation.mutate();
    } else {
      pinMutation.mutate();
    }
  };

  return (
    <>
      <Button
        variant={variant}
        size={size}
        className={cn(
          "transition-all hover:scale-105 pin-button",
          isPinned ? "text-primary" : "text-muted-foreground",
          className
        )}
        onClick={handleTogglePin}
        disabled={pinMutation.isPending || unpinMutation.isPending}
      >
        {isPinned ? (
          <>
            <Pin className="h-4 w-4" />
            {!iconOnly && <span className="ml-2">Pinned</span>}
          </>
        ) : (
          <>
            <PinOff className="h-4 w-4" />
            {!iconOnly && <span className="ml-2">Pin Match</span>}
          </>
        )}
      </Button>
    </>
  );
}