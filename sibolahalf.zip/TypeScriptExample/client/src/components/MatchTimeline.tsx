import React from 'react';
import { Match, GoalScorer, Card } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Volleyball, Clock, PlayCircle, Hourglass, X, AlertTriangle } from 'lucide-react';

interface MatchTimelineProps {
  match: Match;
  className?: string;
}

export default function MatchTimeline({ match, className }: MatchTimelineProps) {
  // Combine goals, cards, and substitutions into a single timeline
  type TimelineEvent = {
    time: string;
    type: 'goal' | 'card' | 'substitution' | 'period';
    team: 'home' | 'away' | 'neutral';
    detail: string;
    subDetail?: string;
    color?: string;
  };

  const events: TimelineEvent[] = [];

  // Add match periods
  events.push({
    time: '0\'',
    type: 'period',
    team: 'neutral',
    detail: 'Kick Off'
  });

  // Add halftime
  if (match.match_status !== 'NS' && match.match_status !== '') {
    events.push({
      time: '45\'',
      type: 'period',
      team: 'neutral',
      detail: 'Half Time',
      subDetail: `${match.match_hometeam_name} ${match.match_hometeam_halftime_score || 0}-${match.match_awayteam_halftime_score || 0} ${match.match_awayteam_name}`
    });
  }

  // Add full time if match is finished
  if (match.match_status === 'FT' || match.match_status === 'AP') {
    events.push({
      time: '90\'',
      type: 'period',
      team: 'neutral',
      detail: 'Full Time',
      subDetail: `${match.match_hometeam_name} ${match.match_hometeam_ft_score || match.match_hometeam_score}-${match.match_awayteam_ft_score || match.match_awayteam_score} ${match.match_awayteam_name}`
    });
  }

  // Add goals
  if (match.goalscorer) {
    match.goalscorer.forEach((goal: GoalScorer) => {
      if (goal.home_scorer) {
        events.push({
          time: goal.time,
          type: 'goal',
          team: 'home',
          detail: goal.home_scorer,
          subDetail: goal.home_assist ? `Assist: ${goal.home_assist}` : undefined
        });
      }
      
      if (goal.away_scorer) {
        events.push({
          time: goal.time,
          type: 'goal',
          team: 'away',
          detail: goal.away_scorer,
          subDetail: goal.away_assist ? `Assist: ${goal.away_assist}` : undefined
        });
      }
    });
  }

  // Add cards
  if (match.cards) {
    match.cards.forEach((card: Card) => {
      if (card.home_fault) {
        events.push({
          time: card.time,
          type: 'card',
          team: 'home',
          detail: card.home_fault,
          color: card.card.toLowerCase().includes('yellow') ? 'bg-yellow-500' : 'bg-red-500'
        });
      }
      
      if (card.away_fault) {
        events.push({
          time: card.time,
          type: 'card',
          team: 'away',
          detail: card.away_fault,
          color: card.card.toLowerCase().includes('yellow') ? 'bg-yellow-500' : 'bg-red-500'
        });
      }
    });
  }

  // Add substitutions
  if (match.substitutions) {
    if (match.substitutions.home) {
      match.substitutions.home.forEach(sub => {
        events.push({
          time: sub.time,
          type: 'substitution',
          team: 'home',
          detail: sub.substitution
        });
      });
    }
    
    if (match.substitutions.away) {
      match.substitutions.away.forEach(sub => {
        events.push({
          time: sub.time,
          type: 'substitution',
          team: 'away',
          detail: sub.substitution
        });
      });
    }
  }

  // Sort events by time
  const sortedEvents = events.sort((a, b) => {
    const timeA = parseInt(a.time.replace(/\D/g, '')) || 0;
    const timeB = parseInt(b.time.replace(/\D/g, '')) || 0;
    return timeA - timeB;
  });

  // Get icon for event type
  const getEventIcon = (event: TimelineEvent) => {
    switch (event.type) {
      case 'goal':
        return <Volleyball className="text-primary" />;
      case 'card':
        return <div className={cn("w-3 h-4 rounded", event.color)} />;
      case 'substitution':
        return <X className="text-muted-foreground" />;
      case 'period':
        if (event.time === '0\'') return <PlayCircle className="text-muted-foreground" />;
        if (event.time === '45\'') return <Hourglass className="text-muted-foreground" />;
        return <Clock className="text-muted-foreground" />;
      default:
        return <AlertTriangle className="text-muted-foreground" />;
    }
  };

  return (
    <div className={cn("space-y-3", className)}>
      {sortedEvents.map((event, index) => (
        <div key={index} className="flex items-start">
          <div className="text-xs text-muted-foreground w-8 pt-0.5">{event.time}</div>
          <div className="w-6 flex justify-center">
            {getEventIcon(event)}
          </div>
          <div className="flex-grow">
            <div className="text-sm">{event.type === 'goal' ? 'Goal' : event.type === 'card' ? 'Card' : event.detail}</div>
            <div className="text-xs text-muted-foreground">
              {event.type === 'goal' || event.type === 'card' ? 
                `${event.detail} (${event.team === 'home' ? match.match_hometeam_name : match.match_awayteam_name})` : 
                event.subDetail}
            </div>
          </div>
        </div>
      ))}

      {sortedEvents.length === 0 && (
        <div className="text-center py-4 text-muted-foreground">
          No timeline events available for this match.
        </div>
      )}
    </div>
  );
}
