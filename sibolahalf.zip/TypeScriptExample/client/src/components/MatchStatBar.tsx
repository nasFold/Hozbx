import React from 'react';
import { cn } from '@/lib/utils';

interface MatchStatBarProps {
  homeStat: number | string;
  awayStat: number | string;
  label: string;
  className?: string;
  invert?: boolean;
}

export default function MatchStatBar({ 
  homeStat, 
  awayStat, 
  label, 
  className,
  invert = false
}: MatchStatBarProps) {
  // Convert stats to numbers if they're strings
  const homeValue = typeof homeStat === 'string' ? parseFloat(homeStat) || 0 : homeStat;
  const awayValue = typeof awayStat === 'string' ? parseFloat(awayStat) || 0 : awayStat;
  
  // Calculate percentages for the bar widths
  const total = homeValue + awayValue;
  const homePercent = total > 0 ? (homeValue / total) * 100 : 50;
  const awayPercent = total > 0 ? (awayValue / total) * 100 : 50;
  
  return (
    <div className={cn("mb-4", className)}>
      <div className="flex justify-between text-xs mb-1">
        <span>{homeStat}</span>
        <span className="text-muted-foreground">{label}</span>
        <span>{awayStat}</span>
      </div>
      <div className="flex h-2 bg-secondary rounded-full overflow-hidden">
        <div 
          className={cn(
            "h-full rounded-l-full", 
            invert ? "bg-destructive" : "bg-primary"
          )} 
          style={{ width: `${homePercent}%` }}
        ></div>
        <div 
          className={cn(
            "h-full rounded-r-full", 
            invert ? "bg-primary" : "bg-destructive"
          )} 
          style={{ width: `${awayPercent}%` }}
        ></div>
      </div>
    </div>
  );
}
