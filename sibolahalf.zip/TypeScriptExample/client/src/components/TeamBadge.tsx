import React from 'react';
import { Link } from 'wouter';

interface TeamBadgeProps {
  teamId: string;
  teamName: string;
  teamLogo?: string;
  size?: 'sm' | 'md' | 'lg';
  showName?: boolean;
  className?: string;
}

export default function TeamBadge({
  teamId,
  teamName,
  teamLogo,
  size = 'md',
  showName = true,
  className = '',
}: TeamBadgeProps) {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  const badge = (
    <div className={`flex items-center ${className}`}>
      <div className={`${sizeClasses[size]} flex-shrink-0 relative`}>
        {teamLogo ? (
          <img
            src={teamLogo}
            alt={teamName}
            className="w-full h-full object-contain"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40/121F3D/FFFFFF?text=Team';
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-secondary rounded-full text-secondary-foreground font-bold text-xs">
            {teamName.charAt(0)}
          </div>
        )}
      </div>

      {showName && (
        <span className="ml-2 text-sm font-medium truncate">
          {teamName}
        </span>
      )}
    </div>
  );

  // If teamId is provided, make it a link
  if (teamId) {
    return (
      <Link href={`/team/${teamId}`} className="hover:opacity-80">
        {badge}
      </Link>
    );
  }

  // Otherwise just return the badge
  return badge;
}