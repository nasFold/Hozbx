import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ScrollableContainerProps {
  children: React.ReactNode;
  className?: string;
  childClassName?: string;
  showControls?: boolean;
}

export default function ScrollableContainer({
  children,
  className,
  childClassName,
  showControls = true
}: ScrollableContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const scroll = (direction: 'left' | 'right') => {
    if (containerRef.current) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      containerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };
  
  return (
    <div className="relative">
      {showControls && (
        <>
          <button 
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-card/80 rounded-r-lg p-1 shadow-md hidden md:block"
            onClick={() => scroll('left')}
          >
            <ChevronLeft size={20} />
          </button>
          
          <button 
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-card/80 rounded-l-lg p-1 shadow-md hidden md:block"
            onClick={() => scroll('right')}
          >
            <ChevronRight size={20} />
          </button>
        </>
      )}
      
      <div 
        ref={containerRef}
        className={cn(
          "flex overflow-x-auto space-x-3 py-2 -mx-1 px-1 no-scrollbar",
          className
        )}
      >
        {React.Children.map(children, child => (
          <div className={cn("flex-shrink-0", childClassName)}>
            {child}
          </div>
        ))}
      </div>
    </div>
  );
}
