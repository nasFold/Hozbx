import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

interface StatBarAdvancedProps {
  homeStat: number | string;
  awayStat: number | string;
  homeTeam: string;
  awayTeam: string;
  label: string;
  className?: string;
  invert?: boolean;
}

export default function StatBarAdvanced({ 
  homeStat, 
  awayStat, 
  homeTeam,
  awayTeam,
  label, 
  className,
  invert = false
}: StatBarAdvancedProps) {
  // Convert stats to numbers if they're strings
  const homeValue = typeof homeStat === 'string' ? parseFloat(homeStat) || 0 : homeStat;
  const awayValue = typeof awayStat === 'string' ? parseFloat(awayStat) || 0 : awayStat;
  
  // Format data for the chart
  const data = [
    {
      name: label,
      home: homeValue,
      away: awayValue
    }
  ];
  
  return (
    <div className={cn("w-full h-20 mb-4", className)}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          layout="vertical"
          data={data}
          margin={{ top: 0, right: 0, left: 0, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="2 2" horizontal={false} opacity={0.1} />
          <XAxis type="number" domain={[0, 'auto']} tick={{ fontSize: 10 }} tickCount={3} />
          <YAxis type="category" dataKey="name" hide />
          <Tooltip
            formatter={(value) => [value, '']}
            contentStyle={{ fontSize: '11px', padding: '2px 4px' }}
            cursor={{ fill: 'rgba(0, 0, 0, 0.02)' }}
          />
          <Bar 
            dataKey="home" 
            fill="hsl(var(--primary))" 
            name="home"
            stackId="stack"
            radius={[6, 0, 0, 6]}
            animationDuration={300}
            animationEasing="linear"
            isAnimationActive={homeValue > 0 || awayValue > 0}
          />
          <Bar 
            dataKey="away" 
            fill="hsl(var(--destructive))" 
            name="away"
            stackId="stack"
            radius={[0, 6, 6, 0]}
            animationDuration={300}
            animationEasing="linear" 
            isAnimationActive={homeValue > 0 || awayValue > 0}
          />
        </BarChart>
      </ResponsiveContainer>
      
      <div className="flex justify-between text-xs mt-1">
        <div className="flex items-center">
          <div className={cn(
            "w-3 h-3 rounded-full mr-1",
            invert ? "bg-destructive" : "bg-primary"
          )}></div>
          <span className="mr-1">{homeValue}</span>
          <span className="text-muted-foreground">{homeTeam}</span>
        </div>
        
        <span className="text-muted-foreground font-medium">{label}</span>
        
        <div className="flex items-center">
          <span className="text-muted-foreground">{awayTeam}</span>
          <span className="mx-1">{awayValue}</span>
          <div className={cn(
            "w-3 h-3 rounded-full ml-1",
            invert ? "bg-primary" : "bg-destructive"
          )}></div>
        </div>
      </div>
    </div>
  );
}
