import React from 'react';
import { cn } from '@/lib/utils';

interface MatchNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  className?: string;
}

export default function MatchNavigation({ activeTab, onTabChange, className }: MatchNavigationProps) {
  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'timeline', label: 'Timeline' },
    { id: 'lineup', label: 'Lineup' },
    { id: 'stats', label: 'Stats' },
    { id: 'standings', label: 'Standings' },
    { id: 'h2h', label: 'H2H' }
  ];
  
  return (
    <div className={cn("bg-card sticky top-[60px] z-20 px-4 py-2 shadow-md shadow-neutral-dark/10", className)}>
      <div className="flex overflow-x-auto space-x-4 -mx-1 px-1 no-scrollbar">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={cn(
              "py-2 font-medium text-sm whitespace-nowrap transition-colors",
              activeTab === tab.id 
                ? "text-primary border-b-2 border-primary" 
                : "text-muted-foreground"
            )}
            onClick={() => onTabChange(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
}
