
import React from 'react';
import { Match } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface LineupProps {
  match: Match;
  className?: string;
}

export default function Lineup({ match, className }: LineupProps) {
  // Debug lineup data
  console.log('Lineup data:', match.lineup);

  // Check if lineup data exists
  if (!match.lineup || !match.lineup.home || !match.lineup.away) {
    return (
      <div className={cn("bg-card p-4 rounded-lg shadow", className)}>
        <p className="text-muted-foreground text-center py-8">Lineup information is not available yet.</p>
      </div>
    );
  }

  const homeTeam = match.lineup.home;
  const awayTeam = match.lineup.away;
  const homeFormation = match.match_hometeam_system || '4-4-2';
  const awayFormation = match.match_awayteam_system || '4-4-2';
  
  // Use team badge as fallback for player images
  const homeBadge = match.team_home_badge;
  const awayBadge = match.team_away_badge;

  // Function to get player position classes for home team (bottom to top)
  const getHomePositionClass = (position) => {
    // Convert position to number
    const pos = parseInt(position);
    if (isNaN(pos) || pos === 0) return 'col-start-4 row-start-8'; // Default position if not specified
    
    // Parse formation (e.g., "4-3-3" => [4, 3, 3])
    const formationParts = homeFormation.split('-').map(Number);
    
    // Position 1 is always goalkeeper
    if (pos === 1) return 'col-start-4 row-start-10';
    
    let currentPos = 2; // Start with position 2 (first defender)
    let rowIndex = 8; // Start with defenders row
    
    // Map each player position in formation
    for (let i = 0; i < formationParts.length; i++) {
      const playersInLine = formationParts[i];
      
      // Calculate horizontal spacing
      for (let j = 0; j < playersInLine; j++) {
        if (pos === currentPos) {
          // Calculate column to place player (distribute evenly)
          const colStart = Math.floor(1 + (j * 6) / playersInLine);
          return `col-start-${colStart} row-start-${rowIndex}`;
        }
        currentPos++;
      }
      
      // Move to next row (move up)
      rowIndex -= 2;
    }
    
    return 'col-start-4 row-start-8'; // Default fallback
  };

  // Function to get player position classes for away team (top to bottom)
  const getAwayPositionClass = (position) => {
    // Convert position to number
    const pos = parseInt(position);
    if (isNaN(pos) || pos === 0) return 'col-start-4 row-start-2'; // Default position if not specified
    
    // Parse formation (e.g., "4-3-3" => [4, 3, 3])
    const formationParts = awayFormation.split('-').map(Number);
    
    // Position 1 is always goalkeeper
    if (pos === 1) return 'col-start-4 row-start-1';
    
    let currentPos = 2; // Start with position 2 (first defender)
    let rowIndex = 3; // Start with defenders row
    
    // Map each player position in formation
    for (let i = 0; i < formationParts.length; i++) {
      const playersInLine = formationParts[i];
      
      // Calculate horizontal spacing
      for (let j = 0; j < playersInLine; j++) {
        if (pos === currentPos) {
          // Calculate column to place player (distribute evenly)
          const colStart = Math.floor(1 + (j * 6) / playersInLine);
          return `col-start-${colStart} row-start-${rowIndex}`;
        }
        currentPos++;
      }
      
      // Move to next row (move down)
      rowIndex += 2;
    }
    
    return 'col-start-4 row-start-2'; // Default fallback
  };
  
  return (
    <div className={cn("bg-card p-4 rounded-lg shadow", className)}>
      <h3 className="text-md font-semibold mb-2">Match Lineup</h3>
      
      {/* Field Visualization with both teams */}
      <div className="relative w-full aspect-[2/3] bg-gradient-to-b from-green-700 to-green-600 rounded-lg mb-5 overflow-hidden">
        {/* Field markings */}
        <div className="absolute inset-0 flex flex-col items-center">
          {/* Center circle */}
          <div className="w-20 h-20 rounded-full border-2 border-white/50 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
          
          {/* Center line */}
          <div className="w-full h-[2px] bg-white/50 absolute top-1/2 transform -translate-y-1/2"></div>
          
          {/* Penalty areas */}
          <div className="w-3/4 h-1/5 border-2 border-white/50 absolute top-0 left-1/2 transform -translate-x-1/2"></div>
          <div className="w-3/4 h-1/5 border-2 border-white/50 absolute bottom-0 left-1/2 transform -translate-x-1/2"></div>
          
          {/* Goal areas */}
          <div className="w-1/3 h-[10%] border-2 border-white/50 absolute top-0 left-1/2 transform -translate-x-1/2"></div>
          <div className="w-1/3 h-[10%] border-2 border-white/50 absolute bottom-0 left-1/2 transform -translate-x-1/2"></div>
        </div>

        {/* Team labels */}
        <div className="absolute top-0 left-0 right-0 bg-black/60 py-1 px-2 text-center text-white text-sm font-semibold">
          {match.match_awayteam_name} {awayFormation && `(${awayFormation})`}
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-black/60 py-1 px-2 text-center text-white text-sm font-semibold">
          {match.match_hometeam_name} {homeFormation && `(${homeFormation})`}
        </div>

        {/* Home team players (bottom) */}
        <div className="grid grid-cols-7 grid-rows-10 absolute inset-0">
          {Array.isArray(homeTeam.starting_lineups) && homeTeam.starting_lineups.length > 0 ? (
            homeTeam.starting_lineups.map((player, index) => (
              <div 
                key={`home-player-${player?.player_key || index}`}
                className={cn(
                  "flex flex-col items-center justify-center scale-75 transform",
                  getHomePositionClass(player.lineup_position)
                )}
              >
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold mb-1 overflow-hidden border-2 border-white shadow-md">
                  {player.player_image ? (
                    <img 
                      src={player.player_image} 
                      alt={player.lineup_player}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).onerror = null; 
                        (e.target as HTMLImageElement).src = homeBadge || 'https://via.placeholder.com/40';
                      }}
                    />
                  ) : (
                    <span>{player.lineup_number || '?'}</span>
                  )}
                </div>
                <div className="flex flex-col items-center">
                  <span className="bg-black/80 px-1 py-0.5 rounded text-white text-[10px] font-medium">
                    {player.lineup_number}
                  </span>
                  <span className="bg-black/80 mt-0.5 px-1 py-0.5 rounded text-white text-[10px] max-w-24 truncate text-center">
                    {player.lineup_player}
                  </span>
                </div>
              </div>
            ))
          ) : null}
          
          {/* Away team players (top) */}
          {Array.isArray(awayTeam.starting_lineups) && awayTeam.starting_lineups.length > 0 ? (
            awayTeam.starting_lineups.map((player, index) => (
              <div 
                key={`away-player-${player?.player_key || index}`}
                className={cn(
                  "flex flex-col items-center justify-center scale-75 transform",
                  getAwayPositionClass(player.lineup_position)
                )}
              >
                <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-white text-xs font-bold mb-1 overflow-hidden border-2 border-white shadow-md">
                  {player.player_image ? (
                    <img 
                      src={player.player_image} 
                      alt={player.lineup_player}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).onerror = null; 
                        (e.target as HTMLImageElement).src = awayBadge || 'https://via.placeholder.com/40';
                      }}
                    />
                  ) : (
                    <span>{player.lineup_number || '?'}</span>
                  )}
                </div>
                <div className="flex flex-col items-center">
                  <span className="bg-black/80 px-1 py-0.5 rounded text-white text-[10px] font-medium">
                    {player.lineup_number}
                  </span>
                  <span className="bg-black/80 mt-0.5 px-1 py-0.5 rounded text-white text-[10px] max-w-24 truncate text-center">
                    {player.lineup_player}
                  </span>
                </div>
              </div>
            ))
          ) : null}
        </div>
      </div>
      
      {/* Substitutes, Coach, and Missing Players */}
      <Tabs defaultValue="homeTeam" className="mt-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="homeTeam">{match.match_hometeam_name}</TabsTrigger>
          <TabsTrigger value="awayTeam">{match.match_awayteam_name}</TabsTrigger>
        </TabsList>
        
        {/* Home Team Tab */}
        <TabsContent value="homeTeam" className="space-y-4 mt-3">
          <div>
            <h4 className="text-sm font-semibold mb-2">Substitutes</h4>
            {Array.isArray(homeTeam?.substitutes) && homeTeam.substitutes.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {homeTeam.substitutes.map((player, index) => (
                  <PlayerItem 
                    key={`home-sub-${player?.player_key || index}`} 
                    player={player} 
                    teamBadge={homeBadge}
                    teamColor="bg-blue-600"
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No substitutes available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Coach</h4>
            {Array.isArray(homeTeam?.coach) && homeTeam.coach.length > 0 ? (
              <div className="space-y-2">
                {homeTeam.coach.map((coach, index) => (
                  <CoachItem 
                    key={`home-coach-${index}`} 
                    coach={coach} 
                    teamBadge={homeBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No coach information available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Missing Players</h4>
            {Array.isArray(homeTeam?.missing_players) && homeTeam.missing_players.length > 0 ? (
              <div className="space-y-2">
                {homeTeam.missing_players.map((player, index) => (
                  <MissingPlayerItem 
                    key={`home-missing-${player?.player_key || index}`} 
                    player={player}
                    teamBadge={homeBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No missing players</p>
            )}
          </div>
        </TabsContent>
        
        {/* Away Team Tab */}
        <TabsContent value="awayTeam" className="space-y-4 mt-3">
          <div>
            <h4 className="text-sm font-semibold mb-2">Substitutes</h4>
            {Array.isArray(awayTeam?.substitutes) && awayTeam.substitutes.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {awayTeam.substitutes.map((player, index) => (
                  <PlayerItem 
                    key={`away-sub-${player?.player_key || index}`} 
                    player={player} 
                    teamBadge={awayBadge}
                    teamColor="bg-red-600"
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No substitutes available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Coach</h4>
            {Array.isArray(awayTeam?.coach) && awayTeam.coach.length > 0 ? (
              <div className="space-y-2">
                {awayTeam.coach.map((coach, index) => (
                  <CoachItem 
                    key={`away-coach-${index}`} 
                    coach={coach} 
                    teamBadge={awayBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No coach information available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Missing Players</h4>
            {Array.isArray(awayTeam?.missing_players) && awayTeam.missing_players.length > 0 ? (
              <div className="space-y-2">
                {awayTeam.missing_players.map((player, index) => (
                  <MissingPlayerItem 
                    key={`away-missing-${player?.player_key || index}`} 
                    player={player}
                    teamBadge={awayBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No missing players</p>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Helper Components
const PlayerItem = ({ player, teamBadge, teamColor = "bg-secondary" }) => {
  if (!player) return null;
  
  const playerName = player.lineup_player || "Unknown";
  const playerNumber = player.lineup_number || '?';
  
  return (
    <div className="flex items-center p-2 rounded-lg hover:bg-muted">
      <div className={`w-8 h-8 rounded-full overflow-hidden mr-2 border-2 border-white ${teamColor}`}>
        {player.player_image ? (
          <img 
            src={player.player_image} 
            alt={playerName}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).onerror = null; 
              (e.target as HTMLImageElement).src = teamBadge || 'https://via.placeholder.com/32';
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-white text-xs font-bold">
            {playerNumber}
          </div>
        )}
      </div>
      <div>
        <div className="flex items-center">
          <span className={`text-xs font-semibold px-1 py-0.5 rounded mr-1 ${teamColor} text-white`}>
            {playerNumber}
          </span>
          <span className="text-sm font-medium">{playerName}</span>
        </div>
      </div>
    </div>
  );
};

const CoachItem = ({ coach, teamBadge }) => {
  if (!coach) return null;
  
  const coachName = coach.lineup_player || "Unknown Coach";
  
  return (
    <div className="flex items-center p-2 rounded-lg hover:bg-muted">
      <div className="w-8 h-8 rounded-full overflow-hidden mr-2 border-2 border-amber-500">
        {coach.player_image ? (
          <img 
            src={coach.player_image} 
            alt={coachName}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).onerror = null; 
              (e.target as HTMLImageElement).src = teamBadge || 'https://via.placeholder.com/32';
            }}
          />
        ) : (
          <div className="w-full h-full bg-amber-500/20 flex items-center justify-center text-amber-600 text-xs">
            C
          </div>
        )}
      </div>
      <div>
        <span className="text-sm font-medium block">{coachName}</span>
        <span className="text-xs px-1 py-0.5 bg-amber-500/20 text-amber-700 rounded">Head Coach</span>
      </div>
    </div>
  );
};

const MissingPlayerItem = ({ player, teamBadge }) => {
  if (!player) return null;
  
  const playerName = player.lineup_player || "Unknown";
  const playerReason = player.player_reason || "Unknown reason";
  
  return (
    <div className="flex items-center p-2 rounded-lg hover:bg-muted">
      <div className="w-8 h-8 rounded-full overflow-hidden mr-2 border-2 border-red-300 opacity-60">
        {player.player_image ? (
          <img 
            src={player.player_image} 
            alt={playerName}
            className="w-full h-full object-cover grayscale"
            onError={(e) => {
              (e.target as HTMLImageElement).onerror = null; 
              (e.target as HTMLImageElement).src = teamBadge || 'https://via.placeholder.com/32';
            }}
          />
        ) : (
          <div className="w-full h-full bg-muted flex items-center justify-center text-xs font-medium">
            ?
          </div>
        )}
      </div>
      <div>
        <span className="text-sm font-medium text-muted-foreground">{playerName}</span>
        <span className="text-xs block text-red-500">{playerReason}</span>
      </div>
    </div>
  );
};
