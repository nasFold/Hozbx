import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, useSearch } from 'wouter';
import { API } from '@/lib/api';
import { League, Country } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import LeagueItem from '@/components/LeagueItem';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search } from 'lucide-react';

export default function LeaguesPage() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const search = useSearch();
  const countryId = new URLSearchParams(search).get('country');
  
  // Fetch countries
  const { data: countries, isLoading: countriesLoading } = useQuery<Country[]>({
    queryKey: [API.football.countries],
    staleTime: 1000 * 60 * 30, // 30 minutes
  });
  
  // Fetch leagues
  const { data: leagues, isLoading: leaguesLoading } = useQuery<League[]>({
    queryKey: [API.football.leagues, { country_id: countryId }],
    enabled: !countryId || !!countryId,
    staleTime: 1000 * 60 * 30, // 30 minutes
  });
  
  // Define top leagues IDs
  const topLeaguesIds = [
    '152', // Premier League
    '302', // La Liga
    '207', // Serie A
    '175', // Bundesliga
    '168', // Ligue 1
    '244', // Champions League
  ];
  
  // Filter leagues by search query
  const filteredLeagues = leagues?.filter(league =>
    league.league_name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Filter top 5 leagues
  const topLeagues = leagues?.filter(league =>
    topLeaguesIds.includes(league.league_id)
  );
  
  // Filter countries by search query
  const filteredCountries = countries?.filter(country =>
    country.country_name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  return (
    <PageContainer title="Leagues">
      {/* Search Box */}
      <div className="relative mb-6">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          <Search size={18} />
        </div>
        <Input
          type="text"
          placeholder="Search leagues or countries..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="pl-10"
        />
      </div>
      
      {/* Tabs */}
      <Tabs defaultValue={countryId ? "leagues" : "all"} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="all">All Leagues</TabsTrigger>
          <TabsTrigger value="top">Top Leagues</TabsTrigger>
          <TabsTrigger value="countries">Countries</TabsTrigger>
        </TabsList>
        
        {/* All Leagues */}
        <TabsContent value="all">
          {leaguesLoading ? (
            <div className="h-60 flex items-center justify-center">
              <LoadingSpinner text="Loading leagues..." />
            </div>
          ) : filteredLeagues && filteredLeagues.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredLeagues.map(league => (
                <LeagueItem 
                  key={league.league_id} 
                  item={league} 
                  type="league" 
                />
              ))}
            </div>
          ) : (
            <div className="bg-card rounded-lg p-6 text-center">
              <p className="text-muted-foreground">
                {searchQuery 
                  ? "No leagues found matching your search query." 
                  : "No leagues available."
                }
              </p>
            </div>
          )}
        </TabsContent>
        
        {/* Top Leagues */}
        <TabsContent value="top">
          {leaguesLoading ? (
            <div className="h-60 flex items-center justify-center">
              <LoadingSpinner text="Loading top leagues..." />
            </div>
          ) : topLeagues && topLeagues.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {topLeagues.map(league => (
                <LeagueItem 
                  key={league.league_id} 
                  item={league} 
                  type="league" 
                />
              ))}
            </div>
          ) : (
            <div className="bg-card rounded-lg p-6 text-center">
              <p className="text-muted-foreground">No top leagues available.</p>
            </div>
          )}
        </TabsContent>
        
        {/* Countries */}
        <TabsContent value="countries">
          {countriesLoading ? (
            <div className="h-60 flex items-center justify-center">
              <LoadingSpinner text="Loading countries..." />
            </div>
          ) : filteredCountries && filteredCountries.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredCountries.map(country => (
                <LeagueItem 
                  key={country.country_id} 
                  item={country} 
                  type="country" 
                />
              ))}
            </div>
          ) : (
            <div className="bg-card rounded-lg p-6 text-center">
              <p className="text-muted-foreground">
                {searchQuery 
                  ? "No countries found matching your search query." 
                  : "No countries available."
                }
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}
