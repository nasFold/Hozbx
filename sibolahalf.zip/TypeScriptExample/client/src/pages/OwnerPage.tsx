import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { API, apiRequest } from '@/lib/api';
import { DailyAnalytics, AdminLog } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import useAuth from '@/hooks/useAuth';
import LoadingSpinner from '@/components/LoadingSpinner';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';
import { format } from 'date-fns';
import { AlertTriangle, Key, RefreshCw, Settings, Shield, User } from 'lucide-react';

// Define the config form schema
const configSchema = z.object({
  apiKey: z.string().min(5, "API key is required"),
  cloudName: z.string().min(1, "Cloud name is required"),
  cloudApiKey: z.string().min(1, "Cloud API key is required"),
  cloudPreset: z.string().min(1, "Cloud preset is required"),
});

type ConfigFormValues = z.infer<typeof configSchema>;

export default function OwnerPage() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [refreshingAnalytics, setRefreshingAnalytics] = useState(false);
  
  // Check if user is owner
  const isAuthorized = user?.role === 'owner';
  
  // Fetch config
  const { data: config, isLoading: configLoading } = useQuery({
    queryKey: [API.owner.config],
    enabled: isAuthenticated && isAuthorized,
  });
  
  // Fetch analytics
  const { data: analytics, isLoading: analyticsLoading, refetch: refetchAnalytics } = useQuery<DailyAnalytics>({
    queryKey: [API.owner.analytics.daily],
    enabled: isAuthenticated && isAuthorized,
  });
  
  // Fetch admin logs
  const { data: logs, isLoading: logsLoading } = useQuery<AdminLog[]>({
    queryKey: [API.owner.logs],
    enabled: isAuthenticated && isAuthorized,
  });
  
  // Initialize form
  const form = useForm<ConfigFormValues>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      apiKey: "",
      cloudName: "",
      cloudApiKey: "",
      cloudPreset: ""
    }
  });
  
  // Update form values when config is loaded
  React.useEffect(() => {
    if (config) {
      form.reset({
        apiKey: config.apiKey,
        cloudName: config.cloudName,
        cloudApiKey: config.cloudApiKey,
        cloudPreset: config.cloudPreset
      });
    }
  }, [config, form]);
  
  // Update config mutation
  const updateConfig = useMutation({
    mutationFn: (data: ConfigFormValues) => 
      apiRequest('PUT', API.owner.config, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [API.owner.config] });
      toast({
        title: "Configuration updated",
        description: "Your configuration has been updated successfully"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update configuration",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // If not authenticated or authorized, redirect to login
  React.useEffect(() => {
    if (!isLoading && (!isAuthenticated || !isAuthorized)) {
      toast({
        title: "Access denied",
        description: "You don't have permission to access the owner panel",
        variant: "destructive"
      });
      setLocation('/login');
    }
  }, [isLoading, isAuthenticated, isAuthorized, setLocation, toast]);
  
  // Handle form submission
  const onSubmit = async (values: ConfigFormValues) => {
    updateConfig.mutate(values);
  };
  
  // Handle refresh analytics
  const handleRefreshAnalytics = async () => {
    setRefreshingAnalytics(true);
    try {
      await refetchAnalytics();
      toast({
        title: "Analytics refreshed",
        description: "The analytics data has been refreshed"
      });
    } catch (error) {
      toast({
        title: "Failed to refresh analytics",
        description: "An error occurred while refreshing analytics",
        variant: "destructive"
      });
    } finally {
      setRefreshingAnalytics(false);
    }
  };
  
  // Format analytics data for chart
  const getAnalyticsData = () => {
    if (!analytics) return [];
    
    // For demo, create a week of analytics data
    const demoData = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      demoData.push({
        date: format(date, 'MMM dd'),
        visits: Math.floor(Math.random() * 50) + 20,
      });
    }
    
    // Add today's real data
    demoData[6] = {
      date: format(today, 'MMM dd'),
      visits: analytics.visits
    };
    
    return demoData;
  };
  
  // Get action color for admin logs
  const getActionColor = (action: string) => {
    switch (action) {
      case 'create':
        return 'text-green-500';
      case 'edit':
        return 'text-blue-500';
      case 'delete':
        return 'text-red-500';
      default:
        return 'text-muted-foreground';
    }
  };
  
  if (isLoading) {
    return (
      <PageContainer showBack title="Owner Panel">
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading..." />
        </div>
      </PageContainer>
    );
  }
  
  return (
    <PageContainer showBack title="Owner Panel">
      <Tabs defaultValue="analytics" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="analytics">Analytics & Logs</TabsTrigger>
          <TabsTrigger value="settings">API Settings</TabsTrigger>
        </TabsList>
        
        {/* Analytics Tab */}
        <TabsContent value="analytics">
          <Card className="mb-6">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Site Analytics</CardTitle>
                <CardDescription>View site visitor statistics</CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleRefreshAnalytics}
                disabled={refreshingAnalytics}
              >
                {refreshingAnalytics ? (
                  <LoadingSpinner size="sm" />
                ) : (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </>
                )}
              </Button>
            </CardHeader>
            <CardContent>
              {analyticsLoading ? (
                <div className="h-60 flex items-center justify-center">
                  <LoadingSpinner text="Loading analytics..." />
                </div>
              ) : (
                <div>
                  <div className="h-60">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={getAnalyticsData()}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                        <XAxis 
                          dataKey="date" 
                          tick={{ fill: 'hsl(var(--muted-foreground))' }}
                          axisLine={{ stroke: 'hsl(var(--border))' }}
                        />
                        <YAxis 
                          tick={{ fill: 'hsl(var(--muted-foreground))' }}
                          axisLine={{ stroke: 'hsl(var(--border))' }}
                        />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))', 
                            borderColor: 'hsl(var(--border))',
                            color: 'hsl(var(--card-foreground))'
                          }}
                        />
                        <Bar dataKey="visits" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  
                  <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <div className="text-sm text-muted-foreground">Today's Visitors</div>
                      <div className="text-2xl font-bold">{analytics?.visits || 0}</div>
                    </div>
                    
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <div className="text-sm text-muted-foreground">This Week</div>
                      <div className="text-2xl font-bold">
                        {getAnalyticsData().reduce((sum, item) => sum + item.visits, 0)}
                      </div>
                    </div>
                    
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <div className="text-sm text-muted-foreground">Most Visited Page</div>
                      <div className="text-xl font-bold truncate">/matches</div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Admin Activity Logs</CardTitle>
              <CardDescription>Recent actions performed by admins</CardDescription>
            </CardHeader>
            <CardContent>
              {logsLoading ? (
                <div className="h-40 flex items-center justify-center">
                  <LoadingSpinner text="Loading logs..." />
                </div>
              ) : logs && logs.length > 0 ? (
                <div className="space-y-4">
                  {logs.map(log => (
                    <div key={log.id} className="p-3 bg-secondary/50 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center">
                          <Shield className="h-4 w-4 mr-2 text-primary" />
                          <span className="font-medium">Admin #{log.adminId}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {new Date(log.createdAt).toLocaleString()}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center">
                        <span className={`text-sm capitalize ${getActionColor(log.action)}`}>
                          {log.action}
                        </span>
                        <span className="text-sm mx-1">-</span>
                        <span className="text-sm">{log.entityType}</span>
                        {log.entityId && <span className="text-sm ml-1">#{log.entityId}</span>}
                      </div>
                      {log.details && (
                        <div className="mt-1 text-xs text-muted-foreground">
                          {typeof log.details === 'object' 
                            ? JSON.stringify(log.details) 
                            : log.details
                          }
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-muted mb-4">
                    <AlertTriangle className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No admin logs</h3>
                  <p className="text-muted-foreground">
                    Admin actions will be recorded and displayed here
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Settings Tab */}
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>API Configuration</CardTitle>
              <CardDescription>Manage API keys and external service settings</CardDescription>
            </CardHeader>
            <CardContent>
              {configLoading ? (
                <div className="h-40 flex items-center justify-center">
                  <LoadingSpinner text="Loading configuration..." />
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="bg-secondary/30 p-4 rounded-lg mb-4 flex items-start space-x-3">
                      <Key className="h-5 w-5 text-yellow-500 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-medium">API Keys Security Warning</p>
                        <p className="text-muted-foreground">
                          These API keys are sensitive. Make sure you don't share them and keep them secure.
                        </p>
                      </div>
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="apiKey"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>API Football API Key</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter API Football key" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="bg-primary/10 p-4 rounded-lg space-y-4">
                      <h3 className="font-medium flex items-center">
                        <Settings className="h-4 w-4 mr-2" />
                        Cloudinary Configuration
                      </h3>
                      
                      <FormField
                        control={form.control}
                        name="cloudName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cloud Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter Cloudinary cloud name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="cloudApiKey"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cloud API Key</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter Cloudinary API key" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="cloudPreset"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cloud Upload Preset</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter Cloudinary upload preset" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={updateConfig.isPending}
                    >
                      {updateConfig.isPending ? (
                        <LoadingSpinner size="sm" />
                      ) : "Save Configuration"}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}
