import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, useSearch } from 'wouter';
import { API, getRelativeTime } from '@/lib/api';
import { News } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import NewsCard from '@/components/NewsCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Input } from '@/components/ui/input';
import { Search, Tag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function NewsPage() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const search = useSearch();
  const tagParam = new URLSearchParams(search).get('tag');
  
  // Fetch news
  const { data: news, isLoading } = useQuery<News[]>({
    queryKey: [API.news.list, { tag: tagParam, limit: 20 }],
  });
  
  // Get unique tags from all news
  const allTags = React.useMemo(() => {
    if (!news) return [];
    
    const tags = new Set<string>();
    news.forEach(item => {
      item.tags.forEach(tag => tags.add(tag));
    });
    
    return Array.from(tags);
  }, [news]);
  
  // Filter news by search query
  const filteredNews = React.useMemo(() => {
    if (!news) return [];
    
    if (!searchQuery) return news;
    
    return news.filter(item => 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [news, searchQuery]);
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  const handleTagClick = (tag: string) => {
    setLocation(`/news?tag=${tag}`);
  };
  
  const clearTagFilter = () => {
    setLocation('/news');
  };
  
  return (
    <PageContainer title="Football News">
      {/* Search Box */}
      <div className="relative mb-4">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          <Search size={18} />
        </div>
        <Input
          type="text"
          placeholder="Search news..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="pl-10"
        />
      </div>
      
      {/* Tags */}
      {allTags.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <Tag className="w-4 h-4 mr-2 text-muted-foreground" />
            <h3 className="text-sm font-medium">Tags</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {tagParam && (
              <Badge variant="outline" className="cursor-pointer" onClick={clearTagFilter}>
                Clear Filter <span className="ml-1">×</span>
              </Badge>
            )}
            {allTags.map(tag => (
              <Badge 
                key={tag}
                variant={tagParam === tag ? "default" : "secondary"}
                className="cursor-pointer"
                onClick={() => handleTagClick(tag)}
              >
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      )}
      
      {/* News List */}
      {isLoading ? (
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner text="Loading news articles..." />
        </div>
      ) : filteredNews.length > 0 ? (
        <div className="space-y-4">
          {tagParam && (
            <h2 className="text-lg font-semibold">
              News tagged with "{tagParam}"
            </h2>
          )}
          
          {filteredNews.map((item) => (
            <NewsCard key={item.id} news={item} compact />
          ))}
        </div>
      ) : (
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">No news found</p>
          <p className="text-muted-foreground">
            {searchQuery 
              ? "No news articles match your search query."
              : tagParam
                ? `No news articles with the tag "${tagParam}".`
                : "No news articles are available at the moment."
            }
          </p>
        </div>
      )}
    </PageContainer>
  );
}
