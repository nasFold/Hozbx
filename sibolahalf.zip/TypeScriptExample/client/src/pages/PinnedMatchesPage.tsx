import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import MatchCard from '@/components/MatchCard';
import PageContainer from '@/components/PageContainer';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Match } from '@/lib/types';
import useAuth from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { API, sortMatches } from '@/lib/api';


export default function PinnedMatchesPage() {
  const [_, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  React.useEffect(() => {
    if (!isAuthenticated && !user) {
      toast({
        title: 'Authentication required',
        description: 'You need to log in to view pinned matches',
        variant: 'destructive',
      });
      navigate('/login');
    }
  }, [isAuthenticated, user, navigate, toast]);

  // Fetch pinned matches
  const { data: pinnedMatches, isLoading, error } = useQuery<Match[]>({
    queryKey: [API.user.pinnedMatches],
    enabled: !!user,
  });

  // Sort the pinned matches
  const sortedPinnedMatches = React.useMemo(() => {
    return pinnedMatches ? sortMatches(pinnedMatches) : [];
  }, [pinnedMatches]);

  return (
    <PageContainer
      title="Pinned Matches"
      showHeader
      showBottomNav
      showBack
    >
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Your Pinned Matches</h1>

        {isLoading && (
          <div className="flex justify-center py-10">
            <LoadingSpinner text="Loading your pinned matches..." />
          </div>
        )}

        {error && (
          <div className="p-4 text-center bg-red-50 text-red-600 rounded-md">
            Error loading pinned matches: {error instanceof Error ? error.message : 'Unknown error'}
          </div>
        )}

        {!isLoading && sortedPinnedMatches && sortedPinnedMatches.length === 0 && (
          <div className="p-8 text-center bg-gray-50 rounded-md">
            <p className="text-gray-600 mb-4">You haven't pinned any matches yet</p>
            <button
              className="px-4 py-2 bg-primary text-white rounded-md"
              onClick={() => navigate('/')}
            >
              Explore Matches
            </button>
          </div>
        )}

        {sortedPinnedMatches && sortedPinnedMatches.length > 0 && (
          <div className="space-y-3">
            {sortedPinnedMatches.map((match) => (
              <MatchCard 
                key={match.match_id} 
                match={match} 
                className="border border-border"
              />
            ))}
          </div>
        )}
      </div>
    </PageContainer>
  );
}