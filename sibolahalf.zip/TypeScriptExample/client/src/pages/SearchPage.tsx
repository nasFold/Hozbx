import React, { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import PageContainer from '@/components/PageContainer';
import MatchCard from '@/components/MatchCard';
import LoadingSpinner from '@/components/LoadingSpinner';

export default function SearchPage() {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  // Extract query from URL
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const q = params.get('q');
    if (q) {
      setSearchQuery(q);
      setIsSearching(true);
    }
  }, [location]);

  const { data: searchResults, isLoading } = useQuery({
    queryKey: ['/api/football/events', searchQuery],
    queryFn: async () => {
      if (!searchQuery || !isSearching) return { matches: [] };
      
      try {
        const response = await apiRequest('GET', `/api/football/events?search=${encodeURIComponent(searchQuery)}`);
        const data = await response.json();
        return { matches: data };
      } catch (error) {
        console.error('Search error:', error);
        return { matches: [] };
      }
    },
    enabled: isSearching && searchQuery.length > 2,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim().length > 2) {
      setIsSearching(true);
    }
  };

  return (
    <PageContainer title="Search" showBack>
      <div className="mt-2 mb-4">
        <form onSubmit={handleSearch} className="flex space-x-2">
          <Input
            type="text"
            placeholder="Search matches, teams, leagues..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" className="shrink-0">
            <Search size={18} className="mr-2" />
            Search
          </Button>
        </form>
      </div>

      <div className="mt-4">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner text="Searching..." />
          </div>
        ) : searchResults?.matches && searchResults.matches.length > 0 ? (
          <div className="space-y-3">
            <h2 className="text-lg font-medium">Results ({searchResults.matches.length})</h2>
            {searchResults.matches.map((match: any) => (
              <MatchCard 
                key={match.match_id} 
                match={match} 
              />
            ))}
          </div>
        ) : isSearching ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No matches found for "{searchQuery}"</p>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">Enter search terms to find matches</p>
          </div>
        )}
      </div>
    </PageContainer>
  );
}