import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model with role-based permissions
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("user"), // 'user', 'admin', 'owner'
  joinedAt: timestamp("joined_at").defaultNow(),
  followedTeams: jsonb("followed_teams").default([]),
  pinnedMatches: jsonb("pinned_matches").default([]),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
  followedTeams: true,
  pinnedMatches: true,
});

// News article model
export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  image: text("image").notNull(),
  tags: jsonb("tags").default([]),
  authorId: integer("author_id").notNull(),
  publishedAt: timestamp("published_at").defaultNow(),
});

export const insertNewsSchema = createInsertSchema(news).pick({
  title: true,
  slug: true,
  content: true,
  image: true,
  tags: true,
  authorId: true,
});

// Settings and configuration
export const configs = pgTable("configs", {
  id: serial("id").primaryKey(),
  apiKey: text("api_key").notNull(),
  cloudName: text("cloud_name").notNull(),
  cloudApiKey: text("cloud_api_key").notNull(),
  cloudPreset: text("cloud_preset").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertConfigSchema = createInsertSchema(configs).pick({
  apiKey: true,
  cloudName: true,
  cloudApiKey: true,
  cloudPreset: true,
});

// User analytics
export const analytics = pgTable("analytics", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull(),
  userAgent: text("user_agent").notNull(),
  path: text("path").notNull(),
  visitDate: timestamp("visit_date").defaultNow(),
  duration: integer("duration"),
});

export const insertAnalyticsSchema = createInsertSchema(analytics).pick({
  ipAddress: true,
  userAgent: true,
  path: true,
  duration: true,
});

// Admin log
export const adminLogs = pgTable("admin_logs", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").notNull(),
  action: text("action").notNull(), // 'create', 'edit', 'delete'
  entityType: text("entity_type").notNull(), // 'news', 'config', etc.
  entityId: integer("entity_id"),
  details: jsonb("details"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAdminLogSchema = createInsertSchema(adminLogs).pick({
  adminId: true,
  action: true,
  entityType: true,
  entityId: true,
  details: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type News = typeof news.$inferSelect;
export type InsertNews = z.infer<typeof insertNewsSchema>;

export type Config = typeof configs.$inferSelect;
export type InsertConfig = z.infer<typeof insertConfigSchema>;

export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;

export type AdminLog = typeof adminLogs.$inferSelect;
export type InsertAdminLog = z.infer<typeof insertAdminLogSchema>;
