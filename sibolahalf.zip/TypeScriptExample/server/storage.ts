import { 
  users, type User, type InsertUser,
  news, type News, type InsertNews,
  configs, type Config, type InsertConfig,
  analytics, type Analytics, type InsertAnalytics,
  adminLogs, type AdminLog, type InsertAdminLog
} from "@shared/schema";
import fs from 'fs/promises';
import path from 'path';

// Define interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Pinned matches operations
  getPinnedMatches(userId: number): Promise<any[]>;
  addPinnedMatch(userId: number, matchData: any): Promise<boolean>;
  removePinnedMatch(userId: number, matchId: string): Promise<boolean>;
  
  // News operations
  getNews(id: number): Promise<News | undefined>;
  getNewsBySlug(slug: string): Promise<News | undefined>;
  getNewsList(limit?: number, offset?: number): Promise<News[]>;
  getNewsByTag(tag: string, limit?: number, offset?: number): Promise<News[]>;
  createNews(news: InsertNews): Promise<News>;
  updateNews(id: number, data: Partial<News>): Promise<News | undefined>;
  deleteNews(id: number): Promise<boolean>;
  
  // Config operations
  getConfig(): Promise<Config | undefined>;
  updateConfig(data: Partial<Config>): Promise<Config>;
  
  // Analytics operations
  recordVisit(analytics: InsertAnalytics): Promise<Analytics>;
  getDailyVisits(date: Date): Promise<number>;
  getPathAnalytics(path: string): Promise<Analytics[]>;
  
  // Admin logs
  createAdminLog(log: InsertAdminLog): Promise<AdminLog>;
  getAdminLogs(adminId?: number, limit?: number): Promise<AdminLog[]>;
}

// In-memory implementation of storage
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private newsList: Map<number, News>;
  private configData: Config | undefined;
  private analyticsData: Map<number, Analytics>;
  private adminLogsData: Map<number, AdminLog>;
  
  private userIdCounter: number;
  private newsIdCounter: number;
  private analyticsIdCounter: number;
  private adminLogIdCounter: number;
  private configIdCounter: number;
  
  private dataDir: string;
  
  constructor() {
    this.users = new Map();
    this.newsList = new Map();
    this.analyticsData = new Map();
    this.adminLogsData = new Map();
    
    this.userIdCounter = 1;
    this.newsIdCounter = 1;
    this.analyticsIdCounter = 1;
    this.adminLogIdCounter = 1;
    this.configIdCounter = 1;
    
    this.dataDir = path.join(process.cwd(), 'data');
    this.initializeStorage();
  }
  
  private async initializeStorage() {
    try {
      // Create the data directory if it doesn't exist
      await fs.mkdir(this.dataDir, { recursive: true });
      
      // Try to load existing data
      await this.loadData();
      
      // Add default config if not exists
      if (!this.configData) {
        this.configData = {
          id: this.configIdCounter++,
          apiKey: process.env.API_FOOTBALL_KEY || 'f7345fdeec0d6f6bdd8224ecf5643ec047e051e055c1ba7721618cc3d2d98e12',
          cloudName: process.env.CLOUDINARY_NAME || 'dmovxvd5z',
          cloudApiKey: process.env.CLOUDINARY_KEY || '784666187868638',
          cloudPreset: process.env.CLOUDINARY_PRESET || 'Sibola',
          lastUpdated: new Date()
        };
        await this.saveConfig();
      }
      
      // Add owner account if not exists
      const owner = await this.getUserByUsername('owner');
      if (!owner) {
        await this.createUser({
          username: 'owner',
          password: 'owner123',
          email: 'owner@sibola.com',
          role: 'owner',
          followedTeams: []
        });
      }
      
      // Add admin account if not exists
      const admin = await this.getUserByUsername('admin');
      if (!admin) {
        await this.createUser({
          username: 'admin',
          password: 'admin123',
          email: 'admin@sibola.com',
          role: 'admin',
          followedTeams: []
        });
      }
    } catch (error) {
      console.error('Error initializing storage:', error);
    }
  }
  
  private async loadData() {
    try {
      // Load users
      const usersPath = path.join(this.dataDir, 'users.json');
      if (await fileExists(usersPath)) {
        const userData = JSON.parse(await fs.readFile(usersPath, 'utf-8'));
        this.users = new Map(userData.map((user: User) => [user.id, user]));
        this.userIdCounter = Math.max(...Array.from(this.users.keys()), 0) + 1;
      }
      
      // Load news
      const newsPath = path.join(this.dataDir, 'news.json');
      if (await fileExists(newsPath)) {
        const newsData = JSON.parse(await fs.readFile(newsPath, 'utf-8'));
        this.newsList = new Map(newsData.map((news: News) => [news.id, news]));
        this.newsIdCounter = Math.max(...Array.from(this.newsList.keys()), 0) + 1;
      }
      
      // Load config
      const configPath = path.join(this.dataDir, 'config.json');
      if (await fileExists(configPath)) {
        this.configData = JSON.parse(await fs.readFile(configPath, 'utf-8'));
        this.configIdCounter = this.configData.id + 1;
      }
      
      // Load analytics
      const analyticsPath = path.join(this.dataDir, 'analytics.json');
      if (await fileExists(analyticsPath)) {
        const analyticsData = JSON.parse(await fs.readFile(analyticsPath, 'utf-8'));
        this.analyticsData = new Map(analyticsData.map((item: Analytics) => [item.id, item]));
        this.analyticsIdCounter = Math.max(...Array.from(this.analyticsData.keys()), 0) + 1;
      }
      
      // Load admin logs
      const logsPath = path.join(this.dataDir, 'admin_logs.json');
      if (await fileExists(logsPath)) {
        const logsData = JSON.parse(await fs.readFile(logsPath, 'utf-8'));
        this.adminLogsData = new Map(logsData.map((log: AdminLog) => [log.id, log]));
        this.adminLogIdCounter = Math.max(...Array.from(this.adminLogsData.keys()), 0) + 1;
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  }
  
  private async saveUsers() {
    try {
      const usersPath = path.join(this.dataDir, 'users.json');
      await fs.writeFile(usersPath, JSON.stringify(Array.from(this.users.values())), 'utf-8');
    } catch (error) {
      console.error('Error saving users:', error);
    }
  }
  
  private async saveNews() {
    try {
      const newsPath = path.join(this.dataDir, 'news.json');
      await fs.writeFile(newsPath, JSON.stringify(Array.from(this.newsList.values())), 'utf-8');
    } catch (error) {
      console.error('Error saving news:', error);
    }
  }
  
  private async saveConfig() {
    try {
      const configPath = path.join(this.dataDir, 'config.json');
      await fs.writeFile(configPath, JSON.stringify(this.configData), 'utf-8');
    } catch (error) {
      console.error('Error saving config:', error);
    }
  }
  
  private async saveAnalytics() {
    try {
      const analyticsPath = path.join(this.dataDir, 'analytics.json');
      await fs.writeFile(analyticsPath, JSON.stringify(Array.from(this.analyticsData.values())), 'utf-8');
    } catch (error) {
      console.error('Error saving analytics:', error);
    }
  }
  
  private async saveAdminLogs() {
    try {
      const logsPath = path.join(this.dataDir, 'admin_logs.json');
      await fs.writeFile(logsPath, JSON.stringify(Array.from(this.adminLogsData.values())), 'utf-8');
    } catch (error) {
      console.error('Error saving admin logs:', error);
    }
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { 
      ...user, 
      id,
      joinedAt: new Date(),
      role: user.role || 'user',
      followedTeams: user.followedTeams || [],
      pinnedMatches: user.pinnedMatches || []
    };
    this.users.set(id, newUser);
    await this.saveUsers();
    return newUser;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    await this.saveUsers();
    return updatedUser;
  }
  
  // Pinned Matches operations
  async getPinnedMatches(userId: number): Promise<any[]> {
    const user = await this.getUser(userId);
    if (!user) return [];
    
    return (user.pinnedMatches as any[]) || [];
  }
  
  async addPinnedMatch(userId: number, matchData: any): Promise<boolean> {
    const user = await this.getUser(userId);
    if (!user) return false;
    
    // Initialize pinnedMatches array if it doesn't exist
    if (!user.pinnedMatches) {
      user.pinnedMatches = [] as any[];
    }
    
    // Ensure pinnedMatches is treated as an array
    const pinnedMatches = user.pinnedMatches as any[];
    
    // Check if match is already pinned
    const existingMatch = pinnedMatches.find(match => match.match_id === matchData.match_id);
    if (existingMatch) {
      // If match already exists, just update it with new data
      Object.assign(existingMatch, matchData);
    } else {
      // Add new match to pinnedMatches
      pinnedMatches.push(matchData);
    }
    
    // Update user in storage
    await this.updateUser(userId, { pinnedMatches });
    return true;
  }
  
  async removePinnedMatch(userId: number, matchId: string): Promise<boolean> {
    const user = await this.getUser(userId);
    if (!user || !user.pinnedMatches) return false;
    
    // Ensure pinnedMatches is treated as an array
    const pinnedMatches = user.pinnedMatches as any[];
    
    // Filter out the match to remove
    const initialLength = pinnedMatches.length;
    const updatedPinnedMatches = pinnedMatches.filter(match => match.match_id !== matchId);
    
    // If no match was removed, return false
    if (initialLength === updatedPinnedMatches.length) return false;
    
    // Update user in storage
    await this.updateUser(userId, { pinnedMatches: updatedPinnedMatches });
    return true;
  }
  
  // News operations
  async getNews(id: number): Promise<News | undefined> {
    return this.newsList.get(id);
  }
  
  async getNewsBySlug(slug: string): Promise<News | undefined> {
    return Array.from(this.newsList.values()).find(
      (news) => news.slug === slug,
    );
  }
  
  async getNewsList(limit = 10, offset = 0): Promise<News[]> {
    const sortedNews = Array.from(this.newsList.values())
      .sort((a, b) => {
        const dateA = new Date(a.publishedAt).getTime();
        const dateB = new Date(b.publishedAt).getTime();
        return dateB - dateA; // Newest first
      });
    
    return sortedNews.slice(offset, offset + limit);
  }
  
  async getNewsByTag(tag: string, limit = 10, offset = 0): Promise<News[]> {
    const filteredNews = Array.from(this.newsList.values())
      .filter(news => {
        const tags = news.tags as string[];
        return tags.includes(tag);
      })
      .sort((a, b) => {
        const dateA = new Date(a.publishedAt).getTime();
        const dateB = new Date(b.publishedAt).getTime();
        return dateB - dateA; // Newest first
      });
    
    return filteredNews.slice(offset, offset + limit);
  }
  
  async createNews(newsItem: InsertNews): Promise<News> {
    const id = this.newsIdCounter++;
    const newNews: News = { 
      ...newsItem, 
      id,
      publishedAt: new Date()
    };
    this.newsList.set(id, newNews);
    await this.saveNews();
    return newNews;
  }
  
  async updateNews(id: number, data: Partial<News>): Promise<News | undefined> {
    const newsItem = this.newsList.get(id);
    if (!newsItem) return undefined;
    
    const updatedNews = { ...newsItem, ...data };
    this.newsList.set(id, updatedNews);
    await this.saveNews();
    return updatedNews;
  }
  
  async deleteNews(id: number): Promise<boolean> {
    const deleted = this.newsList.delete(id);
    if (deleted) {
      await this.saveNews();
    }
    return deleted;
  }
  
  // Config operations
  async getConfig(): Promise<Config | undefined> {
    return this.configData;
  }
  
  async updateConfig(data: Partial<Config>): Promise<Config> {
    if (!this.configData) {
      this.configData = {
        id: this.configIdCounter++,
        apiKey: data.apiKey || '',
        cloudName: data.cloudName || '',
        cloudApiKey: data.cloudApiKey || '',
        cloudPreset: data.cloudPreset || '',
        lastUpdated: new Date()
      };
    } else {
      this.configData = { 
        ...this.configData, 
        ...data, 
        lastUpdated: new Date() 
      };
    }
    
    await this.saveConfig();
    return this.configData;
  }
  
  // Analytics operations
  async recordVisit(analyticsData: InsertAnalytics): Promise<Analytics> {
    const id = this.analyticsIdCounter++;
    const newAnalytics: Analytics = { 
      ...analyticsData, 
      id,
      visitDate: new Date()
    };
    this.analyticsData.set(id, newAnalytics);
    await this.saveAnalytics();
    return newAnalytics;
  }
  
  async getDailyVisits(date: Date): Promise<number> {
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    const nextDay = new Date(targetDate);
    nextDay.setDate(nextDay.getDate() + 1);
    
    // Count unique IPs on the given date
    const uniqueIps = new Set();
    
    Array.from(this.analyticsData.values()).forEach(analytics => {
      const visitDate = new Date(analytics.visitDate);
      if (visitDate >= targetDate && visitDate < nextDay) {
        uniqueIps.add(analytics.ipAddress);
      }
    });
    
    return uniqueIps.size;
  }
  
  async getPathAnalytics(path: string): Promise<Analytics[]> {
    return Array.from(this.analyticsData.values())
      .filter(analytics => analytics.path === path)
      .sort((a, b) => {
        const dateA = new Date(a.visitDate).getTime();
        const dateB = new Date(b.visitDate).getTime();
        return dateB - dateA; // Newest first
      });
  }
  
  // Admin logs
  async createAdminLog(log: InsertAdminLog): Promise<AdminLog> {
    const id = this.adminLogIdCounter++;
    const newLog: AdminLog = { 
      ...log, 
      id,
      createdAt: new Date()
    };
    this.adminLogsData.set(id, newLog);
    await this.saveAdminLogs();
    return newLog;
  }
  
  async getAdminLogs(adminId?: number, limit = 100): Promise<AdminLog[]> {
    let logs = Array.from(this.adminLogsData.values());
    
    if (adminId) {
      logs = logs.filter(log => log.adminId === adminId);
    }
    
    return logs
      .sort((a, b) => {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return dateB - dateA; // Newest first
      })
      .slice(0, limit);
  }
}

// Helper function to check if a file exists
async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

// Export a singleton instance
export const storage = new MemStorage();
