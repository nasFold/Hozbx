import { Link } from "wouter";

const Header = () => {
  return (
    <header className="bg-[#3178c6] text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/">
          <div className="flex items-center space-x-2 cursor-pointer">
            <svg className="h-8 w-8" viewBox="0 0 27 26" xmlns="http://www.w3.org/2000/svg">
              <path fill="#fff" d="M1.125 0C.502 0 0 .502 0 1.125v23.75C0 25.498.502 26 1.125 26h24.75C26.498 26 27 25.498 27 24.875V1.125C27 .502 26.498 0 25.875 0H1.125z"/>
              <path fill="#3178c6" d="M14.28 12.364v2.013c.323.237.703.416 1.139.537.436.12.9.18 1.392.18.492 0 .954-.058 1.388-.173.433-.115.812-.3 1.137-.554.325-.253.582-.58.77-.98.189-.4.283-.88.283-1.439 0-.418-.058-.777-.173-1.078-.115-.3-.28-.562-.493-.785a3.833 3.833 0 00-.77-.625 7.965 7.965 0 00-.98-.537 19.383 19.383 0 01-.875-.451 4.138 4.138 0 01-.7-.5 2.327 2.327 0 01-.467-.625 1.67 1.67 0 01-.173-.785c0-.246.058-.464.173-.654.115-.19.265-.35.45-.484.185-.131.4-.232.642-.3.243-.07.494-.105.756-.105.2 0 .41.023.628.07.22.045.435.112.642.198.207.087.397.193.572.32.174.126.32.273.435.442v-1.858a3.705 3.705 0 00-1.027-.341 5.368 5.368 0 00-1.139-.129c-.492 0-.95.062-1.373.185-.423.124-.797.31-1.122.562a2.675 2.675 0 00-.75.97c-.185.392-.278.85-.278 1.378 0 .681.166 1.255.5 1.723.333.468.845.879 1.536 1.233.32.161.618.31.892.45.273.138.515.283.724.433.208.15.374.318.5.502.124.184.187.396.187.637 0 .232-.05.437-.152.617-.101.18-.235.333-.401.459a1.7 1.7 0 01-.587.284 2.32 2.32 0 01-.688.097 3.09 3.09 0 01-.824-.113 3.05 3.05 0 01-.752-.32 3.339 3.339 0 01-.654-.5 3.345 3.345 0 01-.5-.642zm-4.053-4.895h3.164v-1.652H5.813v1.652h3.14v9.34h1.274v-9.34z"/>
            </svg>
            <h1 className="text-xl font-semibold">TypeScript Learning Platform</h1>
          </div>
        </Link>
        <nav>
          <ul className="flex space-x-6">
            <li><Link href="/basic-types"><a className="hover:text-gray-200 font-medium">Basics</a></Link></li>
            <li><Link href="/advanced-types"><a className="hover:text-gray-200 font-medium">Advanced</a></Link></li>
            <li><Link href="/classes"><a className="hover:text-gray-200 font-medium">Examples</a></Link></li>
            <li><a href="https://www.typescriptlang.org/docs/" target="_blank" rel="noopener noreferrer" className="hover:text-gray-200 font-medium">Documentation</a></li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
