import { useState } from "react";
import { Link, useLocation } from "wouter";

interface Tab {
  id: string;
  label: string;
  path: string;
}

const tabs: Tab[] = [
  { id: "basic-types", label: "Basic Types", path: "/basic-types" },
  { id: "interfaces", label: "Interfaces", path: "/interfaces" },
  { id: "classes", label: "Classes", path: "/classes" },
  { id: "functions", label: "Functions", path: "/functions" },
  { id: "advanced-types", label: "Advanced Types", path: "/advanced-types" },
  { id: "error-handling", label: "Error Handling", path: "/error-handling" },
];

const TabNavigation = () => {
  const [location] = useLocation();
  
  return (
    <div className="mb-8">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <Link key={tab.id} href={tab.path}>
              <a
                className={`${
                  location === tab.path
                    ? "border-[#3178c6] text-[#3178c6]"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                } border-b-2 py-4 px-1 font-medium`}
                aria-current={location === tab.path ? "page" : undefined}
              >
                {tab.label}
              </a>
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default TabNavigation;
