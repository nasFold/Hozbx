interface TokenMap {
  [key: string]: RegExp[];
}

// Define pattern matchers for each token type
const tokenPatterns: TokenMap = {
  keyword: [
    /\b(let|const|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|class|interface|enum|import|export|from|extends|implements|type|namespace|public|private|protected|readonly|static|async|await|try|catch|throw|finally|as|instanceof|typeof|keyof|in|of|get|set|constructor|declare)\b/g,
  ],
  type: [
    /\b(string|number|boolean|any|void|never|unknown|null|undefined|object|symbol|bigint)\b/g,
    /\b([A-Z][A-Za-z0-9_]*)\b/g, // Capitalized types
  ],
  string: [
    /"(?:[^"\\]|\\.)*"/g, // Double quoted strings
    /'(?:[^'\\]|\\.)*'/g, // Single quoted strings
    /`(?:[^`\\]|\\.)*`/g, // Template strings
  ],
  number: [
    /\b\d+\b/g,
    /\b0x[a-f0-9]+\b/g, // Hex
    /\b0b[01]+\b/g, // Binary
  ],
  comment: [
    /\/\/.*$/gm, // Single line comments
    /\/\*[\s\S]*?\*\//g, // Multi-line comments
  ],
  interface: [
    /\b(interface)\s+([A-Za-z0-9_]+)/g,
  ],
  function: [
    /\b([a-zA-Z0-9_]+)(?=\s*\()/g,
  ],
  variable: [
    /\b([a-z][a-zA-Z0-9_]*)\b/g,
  ],
};

// Helper to escape HTML
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Add line numbers to code
function addLineNumbers(code: string): string {
  const lines = code.split("\n");
  return lines
    .map((line, index) => {
      return `<div class="code-line"><span class="line-number">${
        index + 1
      }</span>${line}</div>`;
    })
    .join("\n");
}

// Highlight code based on language
export function highlightCode(code: string, language: string): string {
  if (!code) return "";
  
  // Start with escaped HTML
  let highlightedCode = escapeHtml(code);
  
  // Apply syntax highlighting based on token types
  Object.entries(tokenPatterns).forEach(([tokenType, patterns]) => {
    patterns.forEach((pattern) => {
      highlightedCode = highlightedCode.replace(
        pattern,
        (match) => `<span class="syntax-${tokenType}">${match}</span>`
      );
    });
  });
  
  // Add line numbers
  return addLineNumbers(highlightedCode);
}
