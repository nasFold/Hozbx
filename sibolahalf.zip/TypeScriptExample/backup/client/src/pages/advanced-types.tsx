import TabNavigation from "@/components/TabNavigation";
import CodeEditor from "@/components/CodeEditor";
import CodeConsole from "@/components/CodeConsole";

const genericsCode = `// Generics

// Generic type with a single type parameter
interface Box<T> {
  value: T;
}

// Using a generic interface
const numberBox: Box<number> = { value: 42 };
const stringBox: Box<string> = { value: "hello" };

// Generic with multiple type parameters
interface Pair<K, V> {
  key: K;
  value: V;
}

const pair: Pair<string, number> = { key: "age", value: 30 };

// Generic with constraints
interface WithLength {
  length: number;
}

// T must have a length property
function longest<T extends WithLength>(a: T, b: T): T {
  return a.length >= b.length ? a : b;
}

// Valid examples
console.log(longest([1, 2], [1, 2, 3]));        // [1, 2, 3]
console.log(longest("abc", "defg"));            // "defg"

// Generic with type parameters using other type parameters
function getProperty<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

const person = { name: "Alice", age: 30 };
console.log(getProperty(person, "name"));  // "Alice"
// console.log(getProperty(person, "job")); // Error: 'job' is not assignable to 'name' | 'age'

// Generic class
class DataContainer<T> {
  private data: T[];
  
  constructor(initialData: T[] = []) {
    this.data = initialData;
  }
  
  add(item: T): void {
    this.data.push(item);
  }
  
  getAll(): T[] {
    return [...this.data];
  }
  
  getFirst(): T | undefined {
    return this.data[0];
  }
}

// Using the generic class with a specific type
const numbers = new DataContainer<number>([1, 2, 3]);
numbers.add(4);
console.log(numbers.getAll());  // [1, 2, 3, 4]
console.log(numbers.getFirst()); // 1`;

const mappedTypesCode = `// Mapped Types

// Basic mapped type - creates a type with all properties of T set to boolean
type Flags<T> = {
  [Property in keyof T]: boolean;
};

type UserProperties = {
  name: string;
  age: number;
  email: string;
};

// Mapped to create a type with all properties as boolean flags
type UserFlags = Flags<UserProperties>;
/* Result:
{
  name: boolean;
  age: boolean;
  email: boolean;
}
*/

const userFlags: UserFlags = {
  name: true,  // User has provided a name
  age: false,  // User has not provided age
  email: true  // User has provided email
};

// Mapped type with modifiers - make all properties optional
type Partial<T> = {
  [P in keyof T]?: T[P];
};

// Creating a partial user object
const partialUser: Partial<UserProperties> = {
  name: "John",
  // age and email can be omitted
};

// Mapped type with 'readonly' modifier
type Readonly<T> = {
  readonly [P in keyof T]: T[P];
};

// Creating a readonly user
const readonlyUser: Readonly<UserProperties> = {
  name: "Alice",
  age: 30,
  email: "alice@example.com"
};

// readonlyUser.name = "Bob"; // Error: Cannot assign to 'name' because it is a read-only property

// Mapped type that removes 'readonly' modifier
type Mutable<T> = {
  -readonly [P in keyof T]: T[P];
};

// Mapped type that picks specific properties from a type
type Pick<T, K extends keyof T> = {
  [P in K]: T[P];
};

// Creating a type with only name and email
type NameAndEmail = Pick<UserProperties, "name" | "email">;

const contact: NameAndEmail = {
  name: "John",
  email: "john@example.com"
  // age would be an error
};

// Mapped type that changes the type of each property
type Stringify<T> = {
  [P in keyof T]: string;
};

// All properties converted to string
const stringifiedUser: Stringify<UserProperties> = {
  name: "Bob",
  age: "42",  // Must be string now
  email: "bob@example.com"
};

// Mapped type with conditional types
type NullableProperties<T> = {
  [P in keyof T]: T[P] | null;
};

const nullableUser: NullableProperties<UserProperties> = {
  name: "Charlie",
  age: null,  // Can be null now
  email: "charlie@example.com"
};`;

const conditionalTypesCode = `// Conditional Types

// Basic conditional type
type TypeName<T> = 
  T extends string ? "string" :
  T extends number ? "number" :
  T extends boolean ? "boolean" :
  T extends undefined ? "undefined" :
  T extends Function ? "function" :
  "object";

// Using the conditional type
type T0 = TypeName<string>;  // "string"
type T1 = TypeName<"hello">; // "string"
type T2 = TypeName<42>;      // "number"
type T3 = TypeName<true>;    // "boolean"
type T4 = TypeName<() => void>; // "function"
type T5 = TypeName<{}>; // "object"

// Conditional type with infer
type UnpackArray<T> = T extends Array<infer U> ? U : T;

type UA1 = UnpackArray<string[]>;   // string
type UA2 = UnpackArray<number[]>;   // number
type UA3 = UnpackArray<boolean>;    // boolean (not an array, so falls back to T)

// Extracting return type with infer
type ReturnType<T> = T extends (...args: any[]) => infer R ? R : any;

function createUser(name: string, age: number) {
  return { name, age, createdAt: new Date() };
}

type User = ReturnType<typeof createUser>; // { name: string, age: number, createdAt: Date }

// Conditional type with unions - distributes over union types
type ToArray<T> = T extends any ? T[] : never;

type StrNumArr = ToArray<string | number>; // string[] | number[]

// Filtering types with conditional types
type Exclude<T, U> = T extends U ? never : T;

type ExcludeExample = Exclude<"a" | "b" | "c", "a" | "d">; // "b" | "c"

type Extract<T, U> = T extends U ? T : never;

type ExtractExample = Extract<"a" | "b" | "c", "a" | "d">; // "a"

// Removing null and undefined from a type
type NonNullable<T> = T extends null | undefined ? never : T;

type NonNullableExample = NonNullable<string | number | null | undefined>; // string | number

// Complex conditional type
type FunctionPropertyNames<T> = {
  [K in keyof T]: T[K] extends Function ? K : never
}[keyof T];

interface PersonWithMethods {
  name: string;
  age: number;
  greet: () => void;
  toString: () => string;
}

type PersonMethods = FunctionPropertyNames<PersonWithMethods>; // "greet" | "toString"

// Conditional type to filter object types
type ObjectsOnly<T> = {
  [K in keyof T]: T[K] extends object ? K : never
}[keyof T];

interface ComplexData {
  id: number;
  name: string;
  metadata: { [key: string]: any };
  tags: string[];
  user: { id: number; username: string };
}

type ObjectFields = ObjectsOnly<ComplexData>; // "metadata" | "tags" | "user"`;

const utilityTypesCode = `// Utility Types in TypeScript

// Partial<T> - Makes all properties optional
interface User {
  id: number;
  name: string;
  email: string;
  isActive: boolean;
}

// All properties are optional in updates
function updateUser(id: number, updates: Partial<User>): User {
  // Simulate fetching user
  const user: User = {
    id: 1,
    name: "John",
    email: "john@example.com",
    isActive: true
  };
  
  // Apply updates
  return { ...user, ...updates };
}

const updatedUser = updateUser(1, { name: "John Doe", isActive: false });

// Required<T> - Makes all properties required
interface ContactForm {
  name?: string;
  email?: string;
  message?: string;
}

// For form submission, all fields are required
function submitForm(form: Required<ContactForm>): void {
  console.log(\`Sending email to \${form.name} at \${form.email}: \${form.message}\`);
}

// Readonly<T> - Makes all properties readonly
const config: Readonly<{
  apiUrl: string;
  timeout: number;
  retries: number;
}> = {
  apiUrl: "https://api.example.com",
  timeout: 5000,
  retries: 3
};

// config.timeout = 10000; // Error: Cannot assign to 'timeout' because it is a read-only property

// Record<K, T> - Create a type with keys K and values T
type UserRoles = "admin" | "manager" | "employee";

const permissions: Record<UserRoles, string[]> = {
  admin: ["create", "read", "update", "delete"],
  manager: ["create", "read", "update"],
  employee: ["read"]
};

// Pick<T, K> - Create a type with only picked properties
type UserProfile = Pick<User, "name" | "email">;

const profile: UserProfile = {
  name: "Jane",
  email: "jane@example.com"
  // id and isActive would be an error
};

// Omit<T, K> - Create a type without specified properties
type UserWithoutId = Omit<User, "id">;

const newUser: UserWithoutId = {
  name: "Alice",
  email: "alice@example.com",
  isActive: true
  // id is not required or allowed
};

// Exclude<T, U> - Exclude types assignable to U from T
type ButtonTypes = "primary" | "secondary" | "success" | "danger";
type NonAlertButtons = Exclude<ButtonTypes, "success" | "danger">;
// "primary" | "secondary"

// Extract<T, U> - Extract types assignable to U from T
type AlertButtons = Extract<ButtonTypes, "success" | "danger" | "warning">;
// "success" | "danger" (warning is not in ButtonTypes)

// NonNullable<T> - Remove null and undefined from T
type NullableString = string | null | undefined;
type DefinitelyString = NonNullable<NullableString>; // string

// Parameters<T> - Extract parameter types from function type
function fetchData(url: string, options: { method: string, headers?: Record<string, string> }): Promise<any> {
  return Promise.resolve();
}

type FetchParams = Parameters<typeof fetchData>; // [url: string, options: {...}]

// ReturnType<T> - Extract return type from function type
type FetchReturn = ReturnType<typeof fetchData>; // Promise<any>

// InstanceType<T> - Extract instance type from constructor function
class CustomMap<T> {
  private items: T[] = [];
  
  add(item: T): void {
    this.items.push(item);
  }
  
  get(index: number): T | undefined {
    return this.items[index];
  }
}

type StringMap = InstanceType<typeof CustomMap<string>>;

const map: StringMap = new CustomMap<string>();
map.add("hello");`;

const typeGuardsCode = `// Type Guards and Type Narrowing

// Type predicate: parameterName is Type
function isString(value: any): value is string {
  return typeof value === "string";
}

function processValue(value: string | number) {
  if (isString(value)) {
    // Inside this block, value is a string
    console.log(value.toUpperCase());
  } else {
    // Inside this block, value is a number
    console.log(value.toFixed(2));
  }
}

// typeof type guard
function logValue(value: string | number | boolean) {
  if (typeof value === "string") {
    console.log("String: " + value);
  } else if (typeof value === "number") {
    console.log("Number: " + value.toFixed(2));
  } else {
    console.log("Boolean: " + value);
  }
}

// instanceof type guard
class Customer {
  name: string;
  constructor(name: string) {
    this.name = name;
  }
  
  placeOrder(): void {
    console.log(\`\${this.name} placed an order\`);
  }
}

class Employee {
  name: string;
  department: string;
  
  constructor(name: string, department: string) {
    this.name = name;
    this.department = department;
  }
  
  processSale(): void {
    console.log(\`\${this.name} from \${this.department} processed a sale\`);
  }
}

function handlePerson(person: Customer | Employee) {
  console.log(person.name); // Both have name property
  
  if (person instanceof Customer) {
    person.placeOrder(); // Only Customer has placeOrder method
  } else {
    person.processSale(); // Only Employee has processSale method
  }
}

// in operator type guard
interface Bird {
  fly(): void;
  layEggs(): void;
}

interface Fish {
  swim(): void;
  layEggs(): void;
}

function moveAnimal(animal: Bird | Fish) {
  if ("fly" in animal) {
    animal.fly();
  } else {
    animal.swim();
  }
}

// Discriminated union
interface Square {
  kind: "square";
  size: number;
}

interface Rectangle {
  kind: "rectangle";
  width: number;
  height: number;
}

interface Circle {
  kind: "circle";
  radius: number;
}

type Shape = Square | Rectangle | Circle;

function calculateArea(shape: Shape): number {
  switch (shape.kind) {
    case "square":
      return shape.size * shape.size;
    case "rectangle":
      return shape.width * shape.height;
    case "circle":
      return Math.PI * shape.radius ** 2;
    default:
      // Exhaustiveness checking - ensures all cases are covered
      const _exhaustiveCheck: never = shape;
      return _exhaustiveCheck;
  }
}

// Type assertion (use with caution)
function getLength(value: string | string[] | null) {
  if (value === null) {
    return 0;
  }
  
  // Using type assertion when we know more than the type system
  if (Array.isArray(value)) {
    return value.length;
  }
  
  return value.length;
}`;

const AdvancedTypes = () => {
  const consoleOutput = [
    "type Result<T> = { success: true; data: T } | { success: false; error: string };",
    "function fetchUser(id: number): Result<{ name: string, email: string }> {",
    "  if (id === 1) {",
    "    return { success: true, data: { name: 'John', email: 'john@example.com' } };",
    "  } else {",
    "    return { success: false, error: 'User not found' };",
    "  }",
    "}",
    "const result = fetchUser(1);",
    "if (result.success) {",
    "  console.log(result.data.name);",
    "} else {",
    "  console.log(result.error);",
    "}",
    "John"
  ];

  return (
    <main className="container mx-auto px-4 py-8">
      <TabNavigation />

      <section className="mb-12">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Advanced Types in TypeScript</h2>
        <p className="text-gray-600 mb-6">
          TypeScript's advanced type system enables precise type-checking for complex scenarios. These powerful features help create more maintainable and robust applications.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Generics</h3>
            <p className="text-gray-600 mb-4">
              Generics allow you to create reusable components that can work with different types while preserving type information:
            </p>
            
            <CodeEditor
              title="generics.ts"
              code={genericsCode}
              language="typescript"
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Mapped Types</h3>
            <p className="text-gray-600 mb-4">
              Mapped types allow you to create new types based on existing ones by transforming properties:
            </p>
            
            <CodeEditor
              title="mapped-types.ts"
              code={mappedTypesCode}
              language="typescript"
              runnable={false}
            />
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Conditional Types</h3>
            <p className="text-gray-600 mb-4">
              Conditional types enable type relationships that depend on type conditions, similar to conditional expressions:
            </p>
            
            <CodeEditor
              title="conditional-types.ts"
              code={conditionalTypesCode}
              language="typescript"
              runnable={false}
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Try It Yourself</h3>
            <CodeConsole initialOutput={consoleOutput} />
          </div>
        </div>
      </section>

      <section className="mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Utility Types</h3>
            <p className="text-gray-600 mb-4">
              TypeScript provides built-in utility types to facilitate common type transformations:
            </p>
            
            <CodeEditor
              title="utility-types.ts"
              code={utilityTypesCode}
              language="typescript"
              runnable={false}
            />
            
            <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-400 mt-6">
              <h4 className="font-medium text-blue-800">Common Utility Types</h4>
              <ul className="text-sm text-blue-700 list-disc pl-5 mt-2">
                <li><strong>Partial&lt;T&gt;</strong> - Makes all properties optional</li>
                <li><strong>Required&lt;T&gt;</strong> - Makes all properties required</li>
                <li><strong>Readonly&lt;T&gt;</strong> - Makes all properties readonly</li>
                <li><strong>Record&lt;K,T&gt;</strong> - Creates a type with keys K and values T</li>
                <li><strong>Pick&lt;T,K&gt;</strong> - Creates a type with only picked properties</li>
                <li><strong>Omit&lt;T,K&gt;</strong> - Creates a type without specified properties</li>
              </ul>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Type Guards and Type Narrowing</h3>
            <p className="text-gray-600 mb-4">
              Type guards help narrow down types within conditional blocks, enabling more precise type checks:
            </p>
            
            <CodeEditor
              title="type-guards.ts"
              code={typeGuardsCode}
              language="typescript"
              runnable={false}
            />
            
            <div className="bg-yellow-50 rounded-lg p-4 border-l-4 border-yellow-400 mt-6">
              <h4 className="font-medium text-yellow-800">Type Narrowing Techniques</h4>
              <ul className="text-sm text-yellow-700 list-disc pl-5 mt-2">
                <li>Use <strong>typeof</strong> for primitive types: string, number, boolean</li>
                <li>Use <strong>instanceof</strong> for class instances</li>
                <li>Use <strong>in</strong> operator to check for property existence</li>
                <li>Use <strong>discriminated unions</strong> with a "kind" or "type" property</li>
                <li>Create <strong>custom type predicates</strong> with <code>value is Type</code> for complex cases</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Next Concepts to Explore</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Error Handling</h3>
            <p className="text-gray-600 text-sm mb-4">Apply advanced types to create robust error handling patterns.</p>
            <a href="/error-handling" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Error Handling →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Decorators</h3>
            <p className="text-gray-600 text-sm mb-4">Learn how decorators can be used to annotate and modify classes and properties.</p>
            <a href="https://www.typescriptlang.org/docs/handbook/decorators.html" target="_blank" rel="noopener noreferrer" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">TypeScript Docs: Decorators →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Declaration Merging</h3>
            <p className="text-gray-600 text-sm mb-4">Understand how TypeScript merges declarations with the same name.</p>
            <a href="https://www.typescriptlang.org/docs/handbook/declaration-merging.html" target="_blank" rel="noopener noreferrer" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">TypeScript Docs: Declaration Merging →</a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default AdvancedTypes;
