import fetch from 'node-fetch';
import { storage } from '../storage';

interface APIResponse {
  [key: string]: any;
}

export class FootballAPI {
  private baseUrl: string;
  private apiKey: string;

  constructor() {
    this.baseUrl = 'https://apiv3.apifootball.com/';
    this.apiKey = process.env.API_FOOTBALL_KEY || '';
    this.initializeAPIKey();
  }

  private async initializeAPIKey() {
    if (!this.apiKey) {
      const config = await storage.getConfig();
      if (config) {
        this.apiKey = config.apiKey;
      } else {
        this.apiKey = 'f7345fdeec0d6f6bdd8224ecf5643ec047e051e055c1ba7721618cc3d2d98e12';
      }
    }
  }

  private async createUrl(action: string, params: Record<string, string> = {}): Promise<string> {
    // Ensure API key is initialized
    if (!this.apiKey) {
      await this.initializeAPIKey();
    }

    // Always use Asia/Makassar timezone as per requirements
    const timezone = 'Asia/Makassar';
    console.log(`Using timezone for API request: ${timezone}`);
    
    // Add timezone parameter to all requests
    const urlParams = new URLSearchParams({
      ...params,
      action,
      APIkey: this.apiKey,
      timezone
    });

    return `${this.baseUrl}?${urlParams.toString()}`;
  }

  private async makeRequest<T>(action: string, params: Record<string, string> = {}): Promise<T> {
    const url = await this.createUrl(action, params);

    try {
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}: ${response.statusText}`);
      }

      const data = await response.json() as APIResponse;

      // Check if the API returned an error
      if (data.error) {
        throw new Error(`API Error: ${data.message || JSON.stringify(data)}`);
      }

      return data as T;
    } catch (error) {
      console.error(`Error making API request to ${action}:`, error);
      throw error;
    }
  }

  // Get countries
  async getCountries() {
    return this.makeRequest('get_countries');
  }

  // Get leagues
  async getLeagues(countryId?: string) {
    const params: Record<string, string> = {};
    if (countryId) {
      params.country_id = countryId;
    }
    return this.makeRequest('get_leagues', params);
  }

  // Get teams
  async getTeams(teamId?: string, leagueId?: string) {
    const params: Record<string, string> = {};

    if (teamId) {
      params.team_id = teamId;
    } 

    if (leagueId) {
      params.league_id = leagueId;
    }

    if (!teamId && !leagueId) {
      throw new Error('Either team_id or league_id is required');
    }

    console.log('Getting teams with params:', params);
    return this.makeRequest('get_teams', params);
  }

  // Get players
  async getPlayers(playerId?: string, playerName?: string, withTeam: boolean = false) {
    const params: Record<string, string> = {};

    if (playerId) {
      params.player_id = playerId;
    } else if (playerName) {
      params.player_name = playerName;
    } else {
      throw new Error('Either player_id or player_name is required');
    }

    // Tambahkan parameter untuk mendapatkan data tim klub juga
    if (withTeam) {
      // Parameter ini akan memastikan API mengembalikan data tim klub
      params.player_country = ""; // Parameter kosong akan mengambil semua
    }

    console.log('Getting players with params:', params);
    return this.makeRequest('get_players', params);
  }

  // Get standings
  async getStandings(leagueId: string) {
    try {
      console.log(`API Request - get_standings with league_id: ${leagueId}`);
      const data = await this.makeRequest('get_standings', { league_id: leagueId });
      
      // Jika API mengembalikan pesan error, tangani dengan tepat
      if (data && typeof data === 'object' && 'error' in data) {
        console.error(`API Error in getStandings: ${JSON.stringify(data)}`);
        return [];
      }
      
      // Validasi data untuk memastikan format array
      if (!Array.isArray(data)) {
        console.warn(`Unexpected standings data format for league ${leagueId}: ${typeof data}`);
        return Array.isArray(data.standings) ? data.standings : [];
      }
      
      return data;
    } catch (error) {
      console.error(`Exception in getStandings for league ${leagueId}:`, error);
      return []; // Return empty array instead of throwing
    }
  }

  // Get events (matches)
  async getEvents(params: {
    match_id?: string;
    from?: string;
    to?: string;
    league_id?: string;
    team_id?: string;
    match_live?: string;
    withPlayerStats?: string;
    timezone?: string;
    search?: string;
  }) {
    const apiParams: Record<string, string> = {};

    // Add only defined parameters
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && key !== 'search') {
        apiParams[key] = value;
      }
    });

    // Handle search parameter specially
    if (params.search) {
      // Search can be by team name - direct match against teams in competitions
      apiParams.team_name = params.search;
    }

    // API requires at least one of these parameters
    if (!apiParams.match_id && !apiParams.from && !apiParams.league_id && !apiParams.team_id && 
        !apiParams.match_live && !apiParams.team_name) {
      // Set default to fetch today's matches
      const today = new Date();
      const formattedDate = today.toISOString().split('T')[0];
      apiParams.from = formattedDate;
      apiParams.to = formattedDate;
    }

    // Always use Asia/Makassar timezone as per requirements, regardless of client provided timezone
    apiParams.timezone = 'Asia/Makassar';
    
    // Get current date in this timezone for logging purposes
    const nowInTimezone = new Date().toLocaleString('en-US', { timeZone: 'Asia/Makassar' });
    console.log(`Server time (${apiParams.timezone}): ${new Date(nowInTimezone).toLocaleDateString()}`);
    console.log(`Using timezone for API request: ${apiParams.timezone}`);

    return this.makeRequest('get_events', apiParams);
  }

  // Get H2H (head to head)
  async getH2H(firstTeam_id: string, secondTeam_id: string) {
    if (!firstTeam_id || !secondTeam_id) {
      throw new Error('Both firstTeam_id and secondTeam_id are required for H2H');
    }

    // Menggunakan format parameter yang benar sesuai dokumentasi API
    const params: Record<string, string> = {
      firstTeamId: firstTeam_id,
      secondTeamId: secondTeam_id
    };

    console.log('Sending H2H request with params:', params);
    
    try {
      // Membuat URL khusus untuk H2H dengan format yang benar
      const url = `https://apiv3.apifootball.com/?action=get_H2H&firstTeamId=${firstTeam_id}&secondTeamId=${secondTeam_id}&APIkey=${this.apiKey}`;
      
      console.log('Using direct H2H API URL:', url.replace(this.apiKey, 'API_KEY_HIDDEN'));
      
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Check if the API returned an error
      if (data.error) {
        throw new Error(`API Error: ${data.message || JSON.stringify(data)}`);
      }
      
      return data;
    } catch (error) {
      console.error(`Error making H2H API request:`, error);
      throw error;
    }
  }

  // Get top scorers
  async getTopScorers(leagueId: string) {
    return this.makeRequest('get_topscorers', { league_id: leagueId });
  }

  // Get odds
  async getOdds(matchId: string) {
    return this.makeRequest('get_odds', { match_id: matchId });
  }

  // Get predictions
  async getPredictions(matchId: string) {
    return this.makeRequest('get_predictions', { match_id: matchId });
  }
}

// Singleton instance
export const footballAPI = new FootballAPI();