import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { footballAPI } from "./api/footballApi";
import { setupWebSocket } from "./websocket";
import session from "express-session";
import { authMiddleware, analyticsMiddleware, requireAuth, requireRole, AuthRequest } from "./middleware/auth";
import { registerUser, loginUser, hashPassword } from "./auth";
import memorystore from 'memorystore';
import { uploadImage, deleteImage } from './utils/cloudinary';

// Setup session store
const MemoryStore = memorystore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);

  // Configure session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'sibola-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 24 // 24 hours
    },
    store: new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    })
  }));

  // Apply middleware
  app.use(authMiddleware);
  app.use(analyticsMiddleware);

  // Setup WebSocket server for real-time updates
  const wsServer = setupWebSocket(httpServer);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // API Routes

  // Authentication Routes
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const { username, email, password } = req.body;

      if (!username || !email || !password) {
        return res.status(400).json({ message: 'All fields are required' });
      }

      await registerUser(username, email, password);
      res.status(201).json({ message: 'User registered successfully' });
    } catch (error: any) {
      res.status(400).json({ message: error.message || 'Registration failed' });
    }
  });

  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;

      console.log(`Login attempt for user: ${username}`);

      if (!username || !password) {
        console.log('Login error: Username or password missing');
        return res.status(400).json({ message: 'Username and password are required' });
      }

      // Debug info
      console.log(`Checking credentials for: ${username}`);

      const userId = await loginUser(username, password);

      if (userId) {
        if (req.session) {
          // Use proper type handling for session
          (req.session as any).userId = userId;
          console.log(`Login successful for userId: ${userId}`);

          // Get user details to return in the response
          const user = await storage.getUser(userId);
          if (user) {
            console.log(`User details retrieved: ${user.username} (${user.id})`);
            return res.json({ 
              user: {
                id: user.id,
                username: user.username,
                role: user.role || 'user'
              },
              message: 'Login successful' 
            });
          } else {
            console.log(`User details could not be retrieved for ID: ${userId}`);
          }
        } else {
          console.log('Session not available');
        }

        // If session couldn't be set or user couldn't be retrieved
        res.json({ message: 'Login successful' });
      } else {
        console.log(`Login failed: Invalid credentials for username: ${username}`);
        res.status(401).json({ message: 'Invalid credentials' });
      }
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Login failed due to server error' });
    }
  });

  app.post('/api/auth/logout', (req: Request, res: Response) => {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ message: 'Logout failed' });
        }
        res.json({ message: 'Logged out successfully' });
      });
    } else {
      res.json({ message: 'Already logged out' });
    }
  });

  app.get('/api/auth/me', (req: AuthRequest, res: Response) => {
    console.log('Auth check request received');
    if (req.user) {
      console.log(`User authenticated: ${req.user.username} (${req.user.id})`);
      res.json({ user: req.user });
    } else {
      console.log('User not authenticated');
      res.status(401).json({ message: 'Not authenticated' });
    }
  });

  // Football Data API Routes

  // Countries
  app.get('/api/football/countries', async (req, res) => {
    try {
      const countries = await footballAPI.getCountries();
      res.json(countries);
    } catch (error) {
      console.error('Error fetching countries:', error);
      res.status(500).json({ message: 'Failed to fetch countries' });
    }
  });

  // Leagues
  app.get('/api/football/leagues', async (req, res) => {
    try {
      const countryId = req.query.country_id as string | undefined;
      const leagues = await footballAPI.getLeagues(countryId);
      res.json(leagues);
    } catch (error) {
      console.error('Error fetching leagues:', error);
      res.status(500).json({ message: 'Failed to fetch leagues' });
    }
  });

  // Teams
  app.get('/api/football/teams', async (req, res) => {
    try {
      const teamId = req.query.team_id as string | undefined;
      const leagueId = req.query.league_id as string | undefined;

      if (!teamId && !leagueId) {
        return res.status(400).json({ message: 'Either team_id or league_id is required' });
      }

      const teams = await footballAPI.getTeams(teamId, leagueId);
      res.json(teams);
    } catch (error) {
      console.error('Error fetching teams:', error);
      res.status(500).json({ message: 'Failed to fetch teams' });
    }
  });

  // Players
  app.get('/api/football/players', async (req, res) => {
    try {
      const playerId = req.query.player_id as string | undefined;
      const playerName = req.query.player_name as string | undefined;
      const withTeam = req.query.withTeam === 'true';

      console.log(`Fetching player data with ID: ${playerId}, Name: ${playerName}, withTeam: ${withTeam}`);
      const players = await footballAPI.getPlayers(playerId, playerName, withTeam);

      // Log response untuk debugging
      console.log(`Player data fetched: ${players ? 'success' : 'failed'}`);

      res.json(players);
    } catch (error) {
      console.error('Error fetching players:', error);
      res.status(500).json({ message: 'Failed to fetch players' });
    }
  });

  // Standings
  app.get('/api/football/standings', async (req, res) => {
    try {
      const leagueId = req.query.league_id as string;

      if (!leagueId) {
        return res.status(400).json({ message: 'league_id is required' });
      }

      console.log(`Fetching standings for league ID: ${leagueId}`);

      // Validasi format league_id
      if (!/^\d+$/.test(leagueId)) {
        console.error(`Invalid league_id format: ${leagueId}`);
        return res.status(400).json({ message: 'Invalid league_id format. Must be a numeric value.' });
      }

      const standings = await footballAPI.getStandings(leagueId);

      // Validasi respons
      if (!standings || (Array.isArray(standings) && standings.length === 0)) {
        console.log(`No standings found for league ID: ${leagueId}`);
        return res.json([]); // Kembalikan array kosong bukan error 500
      }

      console.log(`Successfully fetched standings for league ID: ${leagueId}`);
      res.json(standings);
    } catch (error) {
      console.error(`Error fetching standings for league ID ${req.query.league_id}:`, error);
      // Kembalikan array kosong daripada error 500 agar UI tetap berfungsi
      res.json([]);
    }
  });

  // Events (Matches)
  app.get('/api/football/events', async (req, res) => {
    try {
      // Extract user agent to help detect timezone if needed
      const userAgent = req.headers['user-agent'] || '';

      // Get timezone from request or attempt to determine from headers
      let timezone = req.query.timezone as string;
      if (!timezone || timezone === 'UTC') {
        // Try to use 'Asia/Makassar' timezone as default for Indonesian users
        timezone = 'Asia/Makassar';
        console.log(`Server time (${timezone}): ${new Date().toLocaleDateString('en-US', {timeZone: timezone, month: 'numeric', day: 'numeric', year: 'numeric'})}`);
      }

      const params = {
        match_id: req.query.match_id as string | undefined,
        from: req.query.from as string | undefined,
        to: req.query.to as string | undefined,
        league_id: req.query.league_id as string | undefined,
        team_id: req.query.team_id as string | undefined,
        match_live: req.query.match_live as string | undefined,
        withPlayerStats: req.query.withPlayerStats as string | undefined,
        timezone: timezone,
        search: req.query.search as string | undefined
      };

      const events = await footballAPI.getEvents(params);
      res.json(events);
    } catch (error) {
      console.error('Error fetching events:', error);
      res.status(500).json({ message: 'Failed to fetch events' });
    }
  });

  // H2H (Head to Head)
  app.get('/api/football/h2h', async (req, res) => {
    try {
      const firstTeam_id = req.query.firstTeam_id as string;
      const secondTeam_id = req.query.secondTeam_id as string;
      let timezone = req.query.timezone as string;

      console.log("H2H request with params:", {
        firstTeam_id,
        secondTeam_id,
        timezone
      });

      if (!firstTeam_id || !secondTeam_id) {
        console.error('H2H API Error: Missing required parameters');
        return res.status(400).json({ message: 'Missing required parameters: firstTeam_id and secondTeam_id are required' });
      }

      const h2hData = await footballAPI.getH2H(firstTeam_id, secondTeam_id);

      // Debug respons untuk troubleshooting
      console.log('H2H data type:', typeof h2hData);
      console.log('H2H data structure:', 
                  h2hData ? (h2hData.firstTeam_VS_secondTeam ? 
                           `Has ${h2hData.firstTeam_VS_secondTeam.length} matches` : 
                           'Missing firstTeam_VS_secondTeam property') 
                         : 'No data');

      // Pastikan selalu mengembalikan respons yang konsisten
      if (!h2hData || !h2hData.firstTeam_VS_secondTeam) {
        console.log('H2H API returned invalid format, transforming to expected format');
        return res.json({ firstTeam_VS_secondTeam: [] });
      }

      console.log('H2H data retrieved successfully with', h2hData.firstTeam_VS_secondTeam.length, 'matches');
      res.json(h2hData);
    } catch (error) {
      console.error('Error fetching H2H:', error);
      // Kembalikan format standar daripada error 500
      res.json({ firstTeam_VS_secondTeam: [] });
    }
  });

  // Top Scorers
  app.get('/api/football/topscorers', async (req, res) => {
    try {
      const leagueId = req.query.league_id as string;

      if (!leagueId) {
        return res.status(400).json({ message: 'league_id is required' });
      }

      const topScorers = await footballAPI.getTopScorers(leagueId);
      res.json(topScorers);
    } catch (error) {
      console.error('Error fetching top scorers:', error);
      res.status(500).json({ message: 'Failed to fetch top scorers' });
    }
  });

  // Odds
  app.get('/api/football/odds', async (req, res) => {
    try {
      const matchId = req.query.match_id as string;

      if (!matchId) {
        return res.status(400).json({ message: 'match_id is required' });
      }

      const odds = await footballAPI.getOdds(matchId);
      res.json(odds);
    } catch (error) {
      console.error('Error fetching odds:', error);
      res.status(500).json({ message: 'Failed to fetch odds' });
    }
  });

  // Predictions
  app.get('/api/football/predictions', async (req, res) => {
    try {
      const matchId = req.query.match_id as string;

      if (!matchId) {
        return res.status(400).json({ message: 'match_id is required' });
      }

      const predictions = await footballAPI.getPredictions(matchId);
      res.json(predictions);
    } catch (error) {
      console.error('Error fetching predictions:', error);
      res.status(500).json({ message: 'Failed to fetch predictions' });
    }
  });

  // News API Routes
  app.get('/api/news', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string || '10');
      const offset = parseInt(req.query.offset as string || '0');
      const tag = req.query.tag as string | undefined;

      let news;
      if (tag) {
        news = await storage.getNewsByTag(tag, limit, offset);
      } else {
        news = await storage.getNewsList(limit, offset);
      }

      res.json(news);
    } catch (error) {
      console.error('Error fetching news:', error);
      res.status(500).json({ message: 'Failed to fetch news' });
    }
  });

  app.get('/api/news/:slug', async (req, res) => {
    try {
      const news = await storage.getNewsBySlug(req.params.slug);

      if (!news) {
        return res.status(404).json({ message: 'News article not found' });
      }

      res.json(news);
    } catch (error) {
      console.error('Error fetching news article:', error);
      res.status(500).json({ message: 'Failed to fetch news article' });
    }
  });

  // Admin API Routes
  app.post('/api/admin/news', requireAuth, requireRole(['admin', 'owner']), async (req: AuthRequest, res) => {
    try {
      const { title, content, image, tags } = req.body;

      if (!title || !content) {
        return res.status(400).json({ message: 'Title and content are required' });
      }

      // Generate slug from title
      const slug = title
        .toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/[\s_-]+/g, '-')
        .replace(/^-+|-+$/g, '');

      const existingNews = await storage.getNewsBySlug(slug);
      if (existingNews) {
        return res.status(400).json({ message: 'A news article with this title already exists' });
      }

      // Handle image upload if provided
      let imageUrl = '';
      if (image && image.startsWith('data:image')) {
        console.log('Uploading news image to Cloudinary');
        const uploadResult = await uploadImage(image, 'sibola/news');

        if (uploadResult.success && uploadResult.url) {
          imageUrl = uploadResult.url;
          console.log(`Image uploaded successfully: ${imageUrl}`);
        } else {
          console.error('Image upload failed:', uploadResult.error);
          return res.status(400).json({ message: `Image upload failed: ${uploadResult.error}` });
        }
      } else if (image) {
        // If image is already a URL, use it directly
        imageUrl = image;
      }

      const news = await storage.createNews({
        title,
        slug,
        content,
        image: imageUrl,
        tags: tags || [],
        authorId: req.user!.id
      });

      // Log the admin action
      await storage.createAdminLog({
        adminId: req.user!.id,
        action: 'create',
        entityType: 'news',
        entityId: news.id,
        details: { title }
      });

      res.status(201).json(news);
    } catch (error) {
      console.error('Error creating news:', error);
      res.status(500).json({ message: 'Failed to create news' });
    }
  });

  app.put('/api/admin/news/:id', requireAuth, requireRole(['admin', 'owner']), async (req: AuthRequest, res) => {
    try {
      const newsId = parseInt(req.params.id);
      const { title, content, image, tags } = req.body;

      const existingNews = await storage.getNews(newsId);
      if (!existingNews) {
        return res.status(404).json({ message: 'News article not found' });
      }

      // Generate a new slug if title changed
      let slug = existingNews.slug;
      if (title && title !== existingNews.title) {
        slug = title
          .toLowerCase()
          .replace(/[^\w\s-]/g, '')
          .replace(/[\s_-]+/g, '-')
          .replace(/^-+|-+$/g, '');

        const duplicateSlug = await storage.getNewsBySlug(slug);
        if (duplicateSlug && duplicateSlug.id !== newsId) {
          return res.status(400).json({ message: 'A news article with this title already exists' });
        }
      }

      // Handle image upload if provided
      let imageUrl = existingNews.image;
      if (image && image !== existingNews.image) {
        if (image.startsWith('data:image')) {
          console.log('Uploading updated news image to Cloudinary');
          const uploadResult = await uploadImage(image, 'sibola/news');

          if (uploadResult.success && uploadResult.url) {
            imageUrl = uploadResult.url;
            console.log(`Image updated successfully: ${imageUrl}`);
          } else {
            console.error('Image upload failed:', uploadResult.error);
            return res.status(400).json({ message: `Image upload failed: ${uploadResult.error}` });
          }
        } else {
          // If image is already a URL, use it directly
          imageUrl = image;
        }
      }

      const updatedNews = await storage.updateNews(newsId, {
        title: title || existingNews.title,
        slug,
        content: content || existingNews.content,
        image: imageUrl,
        tags: tags || existingNews.tags
      });

      // Log the admin action
      await storage.createAdminLog({
        adminId: req.user!.id,
        action: 'edit',
        entityType: 'news',
        entityId: newsId,
        details: { title: title || existingNews.title }
      });

      res.json(updatedNews);
    } catch (error) {
      console.error('Error updating news:', error);
      res.status(500).json({ message: 'Failed to update news' });
    }
  });

  app.delete('/api/admin/news/:id', requireAuth, requireRole(['admin', 'owner']), async (req: AuthRequest, res) => {
    try {
      const newsId = parseInt(req.params.id);

      const existingNews = await storage.getNews(newsId);
      if (!existingNews) {
        return res.status(404).json({ message: 'News article not found' });
      }

      // Try to delete the image from Cloudinary if it's a Cloudinary URL
      if (existingNews.image && existingNews.image.includes('cloudinary.com')) {
        try {
          // Extract the public ID from the URL
          const urlParts = existingNews.image.split('/');
          const filenameWithExt = urlParts[urlParts.length - 1];
          const publicId = 'sibola/news/' + filenameWithExt.split('.')[0];

          console.log(`Attempting to delete image from Cloudinary: ${publicId}`);
          await deleteImage(publicId);
        } catch (imageError) {
          console.error('Failed to delete image from Cloudinary:', imageError);
          // Continue with article deletion even if image deletion fails
        }
      }

      const deleted = await storage.deleteNews(newsId);

      if (deleted) {
        // Log the admin action
        await storage.createAdminLog({
          adminId: req.user!.id,
          action: 'delete',
          entityType: 'news',
          entityId: newsId,
          details: { title: existingNews.title }
        });

        res.json({ message: 'News article deleted successfully' });
      } else {
        res.status(500).json({ message: 'Failed to delete news article' });
      }
    } catch (error) {
      console.error('Error deleting news:', error);
      res.status(500).json({ message: 'Failed to delete news' });
    }
  });

  // Owner API Routes
  app.get('/api/owner/config', requireAuth, requireRole(['owner']), async (req, res) => {
    try {
      const config = await storage.getConfig();
      res.json(config);
    } catch (error) {
      console.error('Error fetching config:', error);
      res.status(500).json({ message: 'Failed to fetch config' });
    }
  });

  app.put('/api/owner/config', requireAuth, requireRole(['owner']), async (req: AuthRequest, res) => {
    try {
      const { apiKey, cloudName, cloudApiKey, cloudPreset } = req.body;

      const updatedConfig = await storage.updateConfig({
        apiKey,
        cloudName,
        cloudApiKey,
        cloudPreset
      });

      // Log the admin action
      await storage.createAdminLog({
        adminId: req.user!.id,
        action: 'edit',
        entityType: 'config',
        entityId: updatedConfig.id,
        details: { message: 'Updated configuration settings' }
      });

      res.json(updatedConfig);
    } catch (error) {
      console.error('Error updating config:', error);
      res.status(500).json({ message: 'Failed to update config' });
    }
  });

  app.get('/api/owner/analytics/daily', requireAuth, requireRole(['owner']), async (req, res) => {
    try {
      const dateParam = req.query.date as string;
      const date = dateParam ? new Date(dateParam) : new Date();

      const visits = await storage.getDailyVisits(date);
      res.json({ date: date.toISOString().split('T')[0], visits });
    } catch (error) {
      console.error('Error fetching daily visits:', error);
      res.status(500).json({ message: 'Failed to fetch daily visits' });
    }
  });

  app.get('/api/owner/logs', requireAuth, requireRole(['owner']), async (req, res) => {
    try {
      const adminId = req.query.admin_id ? parseInt(req.query.admin_id as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;

      const logs = await storage.getAdminLogs(adminId, limit);
      res.json(logs);
    } catch (error) {
      console.error('Error fetching admin logs:', error);
      res.status(500).json({ message: 'Failed to fetch admin logs' });
    }
  });

  // User API Routes
  app.get('/api/user/teams', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      res.json({ followedTeams: user?.followedTeams || [] });
    } catch (error) {
      console.error('Error fetching followed teams:', error);
      res.status(500).json({ message: 'Failed to fetch followed teams' });
    }
  });

  app.post('/api/user/teams', requireAuth, async (req: AuthRequest, res) => {
    try {
      const { teamId, teamName, teamLogo } = req.body;

      if (!teamId || !teamName) {
        return res.status(400).json({ message: 'Team ID and name are required' });
      }

      const user = await storage.getUser(req.user!.id);

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Check if team is already followed
      const followedTeams = user.followedTeams as any[] || [];
      const isAlreadyFollowed = followedTeams.some(team => team.id === teamId);

      if (isAlreadyFollowed) {
        return res.status(400).json({ message: 'Team already followed' });
      }

      // Add team to followed teams
      followedTeams.push({
        id: teamId,
        name: teamName,
        logo: teamLogo || ''
      });

      const updatedUser = await storage.updateUser(user.id, {
        followedTeams
      });

      res.json({ followedTeams: updatedUser?.followedTeams || [] });
    } catch (error) {
      console.error('Error adding followed team:', error);
      res.status(500).json({ message: 'Failed to add followed team' });
    }
  });

  app.delete('/api/user/teams/:teamId', requireAuth, async (req: AuthRequest, res) => {
    try {
      const teamId = req.params.teamId;

      const user = await storage.getUser(req.user!.id);

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Remove team from followed teams
      const followedTeams = (user.followedTeams as any[] || [])
        .filter(team => team.id !== teamId);

      const updatedUser = await storage.updateUser(user.id, {
        followedTeams
      });

      res.json({ followedTeams: updatedUser?.followedTeams || [] });
    } catch (error) {
      console.error('Error removing followed team:', error);
      res.status(500).json({ message: 'Failed to remove followed team' });
    }
  });

  // Pinned Matches API Routes
  app.get('/api/user/pinned-matches', requireAuth, async (req: AuthRequest, res) => {
    try {
      const pinnedMatches = await storage.getPinnedMatches(req.user!.id);
      res.json({ pinnedMatches });
    } catch (error) {
      console.error('Error fetching pinned matches:', error);
      res.status(500).json({ message: 'Failed to fetch pinned matches' });
    }
  });

  app.post('/api/user/pinned-matches', requireAuth, async (req: AuthRequest, res) => {
    try {
      const matchData = req.body;

      if (!matchData || !matchData.match_id) {
        return res.status(400).json({ message: 'Valid match data with match_id is required' });
      }

      const success = await storage.addPinnedMatch(req.user!.id, matchData);

      if (success) {
        const pinnedMatches = await storage.getPinnedMatches(req.user!.id);
        res.json({ success: true, pinnedMatches });
      } else {
        res.status(500).json({ message: 'Failed to pin match' });
      }
    } catch (error) {
      console.error('Error pinning match:', error);
      res.status(500).json({ message: 'Failed to pin match' });
    }
  });

  app.delete('/api/user/pinned-matches/:matchId', requireAuth, async (req: AuthRequest, res) => {
    try {
      const matchId = req.params.matchId;

      const success = await storage.removePinnedMatch(req.user!.id, matchId);

      if (success) {
        const pinnedMatches = await storage.getPinnedMatches(req.user!.id);
        res.json({ success: true, pinnedMatches });
      } else {
        res.status(404).json({ message: 'Match not found or already unpinned' });
      }
    } catch (error) {
      console.error('Error unpinning match:', error);
      res.status(500).json({ message: 'Failed to unpin match' });
    }
  });

  return httpServer;
}