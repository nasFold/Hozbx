import cloudinary from 'cloudinary';
import { Request } from 'express';
import { log } from '../vite';

// Configure cloudinary
cloudinary.v2.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME || 'dmovxvd5z',
  api_key: process.env.CLOUDINARY_API_KEY || '784666187868638',
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true
});

interface UploadResult {
  success: boolean;
  url?: string;
  publicId?: string;
  error?: string;
}

/**
 * Upload an image to Cloudinary
 * @param base64Image Base64 encoded image
 * @param folder Folder to upload to
 * @returns Upload result
 */
export async function uploadImage(base64Image: string, folder = 'sibola'): Promise<UploadResult> {
  try {
    log(`Uploading image to Cloudinary folder: ${folder}`, 'cloudinary');
    
    // Format validation
    if (!base64Image || !base64Image.startsWith('data:image')) {
      return {
        success: false,
        error: 'Invalid image format. Must be a base64 encoded image.'
      };
    }
    
    // Upload to Cloudinary
    const result = await cloudinary.v2.uploader.upload(base64Image, {
      folder,
      upload_preset: 'Sibola',
      resource_type: 'image'
    });
    
    log(`Image uploaded successfully. Public ID: ${result.public_id}`, 'cloudinary');
    
    return {
      success: true,
      url: result.secure_url,
      publicId: result.public_id
    };
  } catch (error: any) {
    log(`Cloudinary upload error: ${error.message}`, 'cloudinary');
    return {
      success: false,
      error: error.message || 'Failed to upload image'
    };
  }
}

/**
 * Delete an image from Cloudinary
 * @param publicId Public ID of the image
 * @returns Success or failure
 */
export async function deleteImage(publicId: string): Promise<boolean> {
  try {
    log(`Deleting image from Cloudinary: ${publicId}`, 'cloudinary');
    
    // Delete from Cloudinary
    await cloudinary.v2.uploader.destroy(publicId);
    
    log(`Image deleted successfully: ${publicId}`, 'cloudinary');
    return true;
  } catch (error: any) {
    log(`Cloudinary delete error: ${error.message}`, 'cloudinary');
    return false;
  }
}

/**
 * Handle multipart/form-data file upload
 * @param req Express request
 * @param fieldName Field name for the image
 * @param folder Folder to upload to
 * @returns Upload result
 */
export async function handleFileUpload(req: Request, fieldName: string, folder = 'sibola'): Promise<UploadResult> {
  try {
    // For handling base64 from body
    if (req.body && req.body[fieldName] && req.body[fieldName].startsWith('data:image')) {
      return await uploadImage(req.body[fieldName], folder);
    }
    
    // No image found
    return {
      success: false,
      error: 'No image found in request'
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || 'Failed to process image upload'
    };
  }
}

export default {
  uploadImage,
  deleteImage,
  handleFileUpload
};