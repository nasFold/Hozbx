import { QueryClient, QueryFunction } from "@tanstack/react-query";

// Enhanced error handling with detailed information
async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    try {
      // Try to parse JSON error message if available
      const errorData = await res.json();
      const error = new Error(errorData.message || `${res.status}: ${res.statusText}`);
      (error as any).status = res.status;
      (error as any).data = errorData;
      throw error;
    } catch (parseError) {
      // Fallback to text if JSON parsing fails
      const text = await res.text() || res.statusText;
      const error = new Error(`${res.status}: ${text}`);
      (error as any).status = res.status;
      throw error;
    }
  }
}

// Improved API request function with additional options
export async function apiRequest<T = any>(
  method: string,
  url: string,
  data?: unknown | undefined,
  options?: {
    headers?: Record<string, string>;
    timeout?: number;
    retries?: number;
  }
): Promise<T> {
  const { headers = {}, timeout = 30000, retries = 0 } = options || {};
  
  // Setup AbortController for timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);
  
  try {
    const res = await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...headers,
      },
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
      signal: controller.signal,
    });

    await throwIfResNotOk(res);
    
    // Handle empty responses
    if (res.status === 204) {
      return {} as T;
    }
    
    return await res.json();
  } catch (error) {
    // Handle network errors and retries
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error(`Request timeout after ${timeout}ms`);
    }
    
    if (retries > 0) {
      return apiRequest(method, url, data, { 
        ...options, 
        retries: retries - 1 
      });
    }
    
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

// Enhanced query function with better error handling
type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    try {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });

      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        return null;
      }

      await throwIfResNotOk(res);
      
      // Handle empty responses
      if (res.status === 204) {
        return {} as T;
      }
      
      return await res.json();
    } catch (error) {
      console.error(`Query error for ${queryKey[0]}:`, error);
      throw error;
    }
  };

// Optimized query client for better performance
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: 60 * 1000, // 1 minute for data freshness
      retry: 1,  // Allow one retry
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000), // Exponential backoff
      keepPreviousData: true, // Keep displaying old data while fetching new data
    },
    mutations: {
      retry: 1,
      onError: (error) => {
        console.error('Mutation error:', error);
      },
    },
  },
});
