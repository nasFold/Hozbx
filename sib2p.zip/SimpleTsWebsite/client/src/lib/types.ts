// User types
export interface User {
  id: number;
  username: string;
  role: 'user' | 'admin' | 'owner';
}

export interface FollowedTeam {
  id: string;
  name: string;
  logo?: string;
}

// Football API types
export interface Country {
  country_id: string;
  country_name: string;
  country_logo: string;
}

export interface League {
  country_id: string;
  country_name: string;
  league_id: string;
  league_name: string;
  league_season: string;
  league_logo: string;
  country_logo: string;
}

export interface Venue {
  venue_name: string;
  venue_address: string;
  venue_city: string;
  venue_capacity: string;
  venue_surface: string;
}

export interface Team {
  team_key: string;
  team_id?: string;
  team_name: string;
  team_badge: string;
  team_logo?: string;
  team_country: string;
  team_founded: string;
  venue: Venue;
  coaches: Coach[];
  players: TeamPlayer[];
}

export interface TeamPlayer {
  player_key: string;
  player_id: string;
  player_image: string;
  player_name: string;
  player_number: string;
  player_country: string;
  player_type: string;
  player_age: string;
  player_match_played: string;
  player_goals: string;
  player_yellow_cards: string;
  player_red_cards: string;
  player_injured: string;
  player_is_captain: string;
  player_rating?: string;
}

export interface Player {
  player_key: string | number;
  player_id: string;
  player_image: string;
  player_name: string;
  player_number: string;
  player_country: string;
  player_type: string;
  player_age: string;
  player_match_played: string;
  player_goals: string;
  player_yellow_cards: string;
  player_red_cards: string;
  player_injured: string;
  player_substitute_out: string;
  player_substitutes_on_bench: string;
  player_assists: string;
  player_birthdate: string;
  player_is_captain: string;
  player_rating: string;
  team_name: string;
  // Additional statistics
  player_shots_total?: string;
  player_goals_conceded?: string;
  player_fouls_committed?: string;
  player_tackles?: string;
  player_blocks?: string;
  player_crosses_total?: string;
  player_interceptions?: string;
  player_clearances?: string;
  player_dispossesed?: string;
  player_saves?: string;
  player_inside_box_saves?: string;
  player_duels_total?: string;
  player_duels_won?: string;
  player_dribble_attempts?: string;
  player_dribble_succ?: string;
  player_pen_comm?: string;
  player_pen_won?: string;
  player_pen_scored?: string;
  player_pen_missed?: string;
  player_passes?: string;
  player_passes_accuracy?: string;
  player_key_passes?: string;
  player_woordworks?: string;
}

export interface Coach {
  coach_name: string;
  coach_country: string;
  coach_age: string;
}

export interface TeamStanding {
  country_name: string;
  league_id: string;
  league_name: string;
  team_id: string;
  team_name: string;
  overall_promotion: string;
  overall_league_position: string;
  overall_league_payed: string;
  overall_league_W: string;
  overall_league_D: string;
  overall_league_L: string;
  overall_league_GF: string;
  overall_league_GA: string;
  overall_league_PTS: string;
  home_league_position: string;
  home_league_payed: string;
  home_league_W: string;
  home_league_D: string;
  home_league_L: string;
  home_league_GF: string;
  home_league_GA: string;
  home_league_PTS: string;
  away_league_position: string;
  away_league_payed: string;
  away_league_W: string;
  away_league_D: string;
  away_league_L: string;
  away_league_GF: string;
  away_league_GA: string;
  away_league_PTS: string;
}

export interface Match {
  match_id: string;
  country_id: string;
  country_name: string;
  league_id: string;
  league_name: string;
  match_date: string;
  match_status: string;
  match_time: string;
  match_hometeam_id: string;
  match_hometeam_name: string;
  match_hometeam_score: string;
  match_awayteam_id: string;
  match_awayteam_name: string;
  match_awayteam_score: string;
  match_hometeam_halftime_score: string;
  match_awayteam_halftime_score: string;
  match_hometeam_ft_score: string;
  match_awayteam_ft_score: string;
  match_hometeam_system: string;
  match_awayteam_system: string;
  match_live: string;
  match_round: string;
  match_stadium: string;
  match_referee: string;
  team_home_badge: string;
  team_away_badge: string;
  league_logo: string;
  country_logo: string;
  // Additional match details
  goalscorer?: GoalScorer[];
  cards?: Card[];
  substitutions?: Substitution;
  lineup?: Lineup;
  statistics?: Statistic[];
  statistics_1half?: Statistic[];
}

export interface GoalScorer {
  time: string;
  home_scorer: string;
  home_scorer_id: string;
  home_assist: string;
  home_assist_id: string;
  score: string;
  away_scorer: string;
  away_scorer_id: string;
  away_assist: string;
  away_assist_id: string;
}

export interface Card {
  time: string;
  home_fault: string;
  home_player_id: string;
  card: string;
  away_fault: string;
  away_player_id: string;
}

export interface Substitution {
  home: HomeAwaySub[];
  away: HomeAwaySub[];
}

export interface HomeAwaySub {
  time: string;
  substitution: string;
  substitution_player_id: string;
}

export interface Lineup {
  home: LineupTeam;
  away: LineupTeam;
}

export interface LineupTeam {
  starting_lineups: LineupPlayer[];
  substitutes: LineupPlayer[];
  coach: LineupCoach[];
  missing_players: MissingPlayer[];
}

export interface LineupPlayer {
  player_key: number | string;
  player_image?: string;
  lineup_player: string;
  lineup_number: string;
  lineup_position: string;
  player?: string;
  player_id?: string;
  player_number?: string;
  player_position?: string;
  player_country?: string;
}

export interface LineupCoach {
  player_key?: number | string;
  player_image?: string;
  lineup_player: string;
  coach?: string;
  coach_country?: string;
}

export interface MissingPlayer {
  player_key: number | string;
  player_image?: string;
  lineup_player: string;
  player_reason?: string;
  player?: string;
  player_id?: string;
}

export interface Statistic {
  type: string;
  home: string;
  away: string;
}

export interface H2H {
  firstTeam_VS_secondTeam: Match[];
  firstTeam_lastResults: Match[];
  secondTeam_lastResults: Match[];
}

export interface TopScorer {
  player_place?: string;
  player_name: string;
  player_key?: string;
  player_id?: string;
  team_name: string;
  team_key?: string;
  goals: string;
  assists?: string;
  penalty_goals?: string;
}

// News types
export interface News {
  id: number;
  title: string;
  slug: string;
  content: string;
  image: string;
  tags: string[];
  authorId: number;
  publishedAt: string;
}

// Analytics types
export interface DailyAnalytics {
  date: string;
  visits: number;
}

// Admin Log types
export interface AdminLog {
  id: number;
  adminId: number;
  action: string;
  entityType: string;
  entityId?: number;
  details?: any;
  createdAt: string;
}