import { useLocation } from 'wouter';
import { generateSlug } from './seo';

// SEO-friendly URL routes
export interface RouteConfig {
  path: string;
  title: string;
  description: string;
}

// Centralized route definitions for consistent routing and SEO
export const ROUTES = {
  HOME: { 
    path: '/',
    title: 'Sibola - Football Live Scores, News, and More',
    description: 'Get the latest football information, live scores, match details, and news from around the world.'
  },
  MATCHES: { 
    path: '/matches',
    title: 'Football Matches - Live Scores and Fixtures | Sibola',
    description: 'View upcoming matches, live scores, and football fixtures from around the world. Follow your favorite teams in real-time.'
  },
  MATCH: (id: string, homeTeam?: string, awayTeam?: string) => {
    // If team names are provided, create a SEO-friendly URL
    if (homeTeam && awayTeam) {
      return {
        path: `/match/${id}/${generateSlug(homeTeam)}-vs-${generateSlug(awayTeam)}`,
        title: `${homeTeam} vs ${awayTeam} - Live Score | Sibola`,
        description: `Follow ${homeTeam} vs ${awayTeam} match live. Get real-time score updates, lineups, and match statistics.`
      };
    }
    
    return {
      path: `/match/${id}`,
      title: 'Match Details | Sibola',
      description: 'View detailed football match information, live scores, lineups, and statistics.'
    };
  },
  LEAGUES: { 
    path: '/leagues',
    title: 'Football Leagues and Competitions | Sibola',
    description: 'Browse football leagues and competitions from around the world. View standings, fixtures, and results.'
  },
  LEAGUE: (id: string, name?: string) => {
    // If league name is provided, create a SEO-friendly URL
    if (name) {
      return {
        path: `/league/${id}/${generateSlug(name)}`,
        title: `${name} - Standings, Fixtures, and Results | Sibola`,
        description: `Follow ${name} standings, fixtures, results, and top scorers. Get the latest updates and statistics.`
      };
    }
    
    return {
      path: `/league/${id}`,
      title: 'League Details | Sibola',
      description: 'View league standings, fixtures, results, and top scorers. Stay updated with the latest information.'
    };
  },
  TEAM: (id: string, name?: string) => {
    // If team name is provided, create a SEO-friendly URL
    if (name) {
      return {
        path: `/team/${id}/${generateSlug(name)}`,
        title: `${name} - Squad, Fixtures, and Results | Sibola`,
        description: `Get the latest information about ${name}. View squad, fixtures, results, and statistics.`
      };
    }
    
    return {
      path: `/team/${id}`,
      title: 'Team Information | Sibola',
      description: 'View team information, squad, fixtures, results, and statistics.'
    };
  },
  PLAYER: (id: string, name?: string) => {
    // If player name is provided, create a SEO-friendly URL
    if (name) {
      return {
        path: `/player/${id}/${generateSlug(name)}`,
        title: `${name} - Player Profile and Stats | Sibola`,
        description: `View ${name}'s player profile, statistics, career history, and performance data.`
      };
    }
    
    return {
      path: `/player/${id}`,
      title: 'Player Profile | Sibola',
      description: 'View detailed player information, statistics, and career history.'
    };
  },
  NEWS: { 
    path: '/news',
    title: 'Football News and Updates | Sibola',
    description: 'Read the latest football news, updates, transfer rumors, and analysis from around the world.'
  },
  NEWS_DETAIL: (slug: string, title?: string) => {
    return {
      path: `/news/${slug}`,
      title: title ? `${title} | Sibola News` : 'Football News Article | Sibola',
      description: title ? `Read about ${title}. Get the latest football news and updates.` : 'Read the latest football news and updates.'
    };
  },
  SEARCH: { 
    path: '/search',
    title: 'Search Football Information | Sibola',
    description: 'Search for football teams, players, matches, and news. Find exactly what you are looking for.'
  },
  LOGIN: { 
    path: '/login',
    title: 'Login | Sibola',
    description: 'Log in to your Sibola account. Access your personalized football experience.'
  },
  REGISTER: { 
    path: '/register',
    title: 'Register | Sibola',
    description: 'Create a new Sibola account. Personalize your football experience and get access to premium features.'
  },
  ACCOUNT: { 
    path: '/account',
    title: 'My Account | Sibola',
    description: 'Manage your Sibola account settings, preferences, and followed teams.'
  },
  PINNED: { 
    path: '/pinned',
    title: 'My Pinned Matches | Sibola',
    description: 'View your pinned football matches. Get quick access to the matches you care about.'
  },
  // Admin routes
  ADMIN: { 
    path: '/admin',
    title: 'Admin Dashboard | Sibola',
    description: 'Manage site content, users, and settings from the admin dashboard.'
  },
  OWNER: { 
    path: '/owner',
    title: 'Owner Dashboard | Sibola',
    description: 'Access owner-level controls and settings for your Sibola site.'
  },
};

// Custom navigation hook with enhanced functionality
export function useNavigation() {
  const [location, navigate] = useLocation();
  
  // Navigate to a route with SEO-friendly URL
  const navigateTo = (route: RouteConfig) => {
    document.title = route.title;
    navigate(route.path);
  };
  
  // Navigate to a specific match with SEO-friendly URL
  const navigateToMatch = (id: string, homeTeam?: string, awayTeam?: string) => {
    const route = ROUTES.MATCH(id, homeTeam, awayTeam);
    navigateTo(route);
  };
  
  // Navigate to a specific league with SEO-friendly URL
  const navigateToLeague = (id: string, name?: string) => {
    const route = ROUTES.LEAGUE(id, name);
    navigateTo(route);
  };
  
  // Navigate to a specific team with SEO-friendly URL
  const navigateToTeam = (id: string, name?: string) => {
    const route = ROUTES.TEAM(id, name);
    navigateTo(route);
  };
  
  // Navigate to a specific player with SEO-friendly URL
  const navigateToPlayer = (id: string, name?: string) => {
    const route = ROUTES.PLAYER(id, name);
    navigateTo(route);
  };
  
  // Navigate to a specific news article with SEO-friendly URL
  const navigateToNews = (slug: string, title?: string) => {
    const route = ROUTES.NEWS_DETAIL(slug, title);
    navigateTo(route);
  };
  
  return {
    location,
    navigateTo,
    navigateToMatch,
    navigateToLeague,
    navigateToTeam,
    navigateToPlayer,
    navigateToNews,
  };
}