// Helper function to generate SEO-friendly slug from a string
export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/-+/g, '-') // Replace multiple hyphens with a single hyphen
    .trim(); // Remove leading and trailing spaces/hyphens
}

// Helper to extract relevant metadata from URL
export function extractIdFromPath(path: string): string | null {
  const match = path.match(/\/([^\/]+)\/([^\/]+)/);
  return match ? match[2] : null;
}

// Function to extract title and slug for SEO purposes
export function extractSlugFromPath(path: string): string | null {
  const parts = path.split('/').filter(Boolean);
  return parts.length > 1 ? parts[parts.length - 1] : null;
}

// Function to generate canonical URL for SEO
export function generateCanonicalUrl(path: string): string {
  const baseUrl = window.location.origin;
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  return `${baseUrl}${cleanPath}`;
}

// Generate structured data for rich snippets in search results
export function generateStructuredData(type: 'Article' | 'Event' | 'Organization' | 'Person', data: any): string {
  let structuredData: any = {
    '@context': 'https://schema.org',
    '@type': type,
  };

  switch (type) {
    case 'Article':
      structuredData = {
        ...structuredData,
        headline: data.title,
        description: data.description,
        image: data.image,
        author: {
          '@type': 'Person',
          name: data.author,
        },
        datePublished: data.publishedDate,
        dateModified: data.modifiedDate,
        publisher: {
          '@type': 'Organization',
          name: 'Sibola',
          logo: {
            '@type': 'ImageObject',
            url: `${window.location.origin}/sibola-logo.png`,
          },
        },
      };
      break;
    case 'Event':
      structuredData = {
        ...structuredData,
        name: data.title,
        description: data.description,
        startDate: data.startDate,
        endDate: data.endDate,
        location: {
          '@type': 'Place',
          name: data.venue,
          address: data.address,
        },
        performer: [
          {
            '@type': 'SportsTeam',
            name: data.homeTeam,
          },
          {
            '@type': 'SportsTeam',
            name: data.awayTeam,
          },
        ],
      };
      break;
    case 'Organization':
      structuredData = {
        ...structuredData,
        name: data.name,
        description: data.description,
        url: data.url,
        logo: data.logo,
      };
      break;
    case 'Person':
      structuredData = {
        ...structuredData,
        name: data.name,
        description: data.description,
        image: data.image,
        url: data.url,
      };
      break;
  }

  return JSON.stringify(structuredData);
}

// Optimize title for SEO
export function optimizeTitle(title: string, siteTitle: string = 'Sibola'): string {
  if (title.includes(siteTitle)) {
    return title;
  }
  return `${title} | ${siteTitle}`;
}

// Generate meta description if none provided
export function generateMetaDescription(content: string, maxLength: number = 160): string {
  if (!content) return '';
  
  // Strip HTML tags
  const textContent = content.replace(/<[^>]*>/g, '');
  
  // Truncate to maxLength and add ellipsis if needed
  if (textContent.length <= maxLength) {
    return textContent;
  }
  
  // Find the last space before maxLength to avoid cutting words
  const truncated = textContent.substring(0, maxLength);
  const lastSpace = truncated.lastIndexOf(' ');
  
  return `${truncated.substring(0, lastSpace)}...`;
}