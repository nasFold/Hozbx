
import React, { useState, useEffect } from 'react';
import { Match } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, User } from 'lucide-react';

// Tambahan interface untuk menyesuaikan API response
interface LineupPlayerExtended {
  player_key: number | string;
  player_image?: string;
  lineup_player: string;
  lineup_number: string;
  lineup_position: string;
  player?: string;
  player_id?: string;
  player_number?: string;
  player_position?: string;
  player_country?: string;
}

interface MissingPlayerExtended {
  player_key: number | string;
  player_image?: string;
  lineup_player: string;
  player_reason?: string;
  player?: string;
  player_id?: string;
}

interface CoachExtended {
  player_key?: number | string;
  player_image?: string;
  lineup_player: string;
  coach?: string;
  coach_country?: string;
}

interface LineupProps {
  match: Match;
  className?: string;
}

export default function Lineup({ match, className }: LineupProps) {
  // Check if lineup data exists
  if (!match.lineup || !match.lineup.home || !match.lineup.away) {
    return (
      <div className={cn("bg-card p-4 rounded-lg shadow", className)}>
        <p className="text-muted-foreground text-center py-8">Lineup information is not available yet.</p>
      </div>
    );
  }

  const homeTeam = match.lineup.home;
  const awayTeam = match.lineup.away;
  const homeFormation = match.match_hometeam_system || '4-4-2';
  const awayFormation = match.match_awayteam_system || '4-4-2';
  
  // Use team badge as fallback for player images
  const homeBadge = match.team_home_badge;
  const awayBadge = match.team_away_badge;

  // Calculate player positions based on formation
  const calculatePositions = (formation: string, isHome = true) => {
    // Parse formation (e.g., "4-3-3" => [4, 3, 3])
    const formationParts = formation.split('-').map(Number);
    const totalLines = formationParts.length;
    
    // Function to calculate player positions
    return (player: LineupPlayer) => {
      const pos = parseInt(player.lineup_position);
      if (isNaN(pos)) return isHome ? 'row-8 col-4' : 'row-2 col-4'; // Default fallback
      
      // Goalkeeper position
      if (pos === 1) return isHome ? 'row-10 col-4' : 'row-1 col-4';
      
      let currentPos = 2; // Start with first outfield player
      let formationIndex = 0;
      
      // Find player's line and position in formation
      for (let i = 0; i < formationParts.length; i++) {
        const playersInLine = formationParts[i];
        
        // Check if player is in this line
        if (pos >= currentPos && pos < currentPos + playersInLine) {
          const posInLine = pos - currentPos;
          formationIndex = i;
          
          // Calculate horizontal position (evenly distributed)
          const totalWidth = 7; // grid cols
          const step = totalWidth / (playersInLine + 1);
          const col = Math.round((posInLine + 1) * step);
          
          // Calculate row based on whether it's home or away team
          let row;
          if (isHome) {
            // Home team (bottom to top)
            row = 9 - formationIndex * 2; // Start from bottom (row 9) and move up
          } else {
            // Away team (top to bottom)
            row = 2 + formationIndex * 2; // Start from top (row 2) and move down
          }
          
          return `row-${row} col-${col}`;
        }
        
        currentPos += playersInLine;
      }
      
      // Fallback positions
      return isHome ? 'row-8 col-4' : 'row-2 col-4';
    };
  };
  
  // Get position classes for players
  const getHomePosition = calculatePositions(homeFormation, true);
  const getAwayPosition = calculatePositions(awayFormation, false);
  
  return (
    <div className={cn("bg-card p-4 rounded-lg shadow", className)}>
      <h3 className="text-md font-semibold mb-2">Match Lineup</h3>
      
      {/* Field Visualization with both teams - MODERNIZED */}
      <div className="relative w-full aspect-[2/3] bg-gradient-to-b from-green-600 via-green-500 to-green-600 rounded-lg mb-5 overflow-hidden shadow-lg">
        {/* Field texture overlay */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCI+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZmZmZmZmMTAiPjxwYXRoIGQ9Ik0wIDBoMjB2MjBIMHoiLz48L2c+PC9zdmc+')] opacity-20"></div>
        
        {/* Field markings */}
        <div className="absolute inset-0 flex flex-col items-center">
          {/* Center circle */}
          <div className="w-24 h-24 rounded-full border-2 border-white/50 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
          <div className="w-4 h-4 rounded-full bg-white/50 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
          
          {/* Center line */}
          <div className="w-full h-[2px] bg-white/60 absolute top-1/2 transform -translate-y-1/2"></div>
          
          {/* Penalty areas */}
          <div className="w-3/4 h-1/5 border-2 border-white/60 absolute top-0 left-1/2 transform -translate-x-1/2"></div>
          <div className="w-3/4 h-1/5 border-2 border-white/60 absolute bottom-0 left-1/2 transform -translate-x-1/2"></div>
          
          {/* Goal areas */}
          <div className="w-1/3 h-[10%] border-2 border-white/60 absolute top-0 left-1/2 transform -translate-x-1/2"></div>
          <div className="w-1/3 h-[10%] border-2 border-white/60 absolute bottom-0 left-1/2 transform -translate-x-1/2"></div>
          
          {/* Penalty spots */}
          <div className="w-2 h-2 rounded-full bg-white/70 absolute top-[15%] left-1/2 transform -translate-x-1/2"></div>
          <div className="w-2 h-2 rounded-full bg-white/70 absolute bottom-[15%] left-1/2 transform -translate-x-1/2"></div>
        </div>

        {/* Team labels with gradients */}
        <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/80 to-black/40 py-2 px-2 text-center text-white text-sm font-semibold backdrop-blur-sm">
          {match.match_awayteam_name} {awayFormation && `(${awayFormation})`}
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-black/40 py-2 px-2 text-center text-white text-sm font-semibold backdrop-blur-sm">
          {match.match_hometeam_name} {homeFormation && `(${homeFormation})`}
        </div>

        {/* Field grid for positioning players */}
        <div className="grid grid-cols-7 grid-rows-11 absolute inset-0">
          {Array.isArray(homeTeam.starting_lineups) && homeTeam.starting_lineups.length > 0 ? (
            homeTeam.starting_lineups.map((player, index) => (
              <div 
                key={`home-player-${player?.player_key || index}`}
                className={cn(
                  "flex flex-col items-center justify-center scale-75 transform",
                  getHomePosition(player)
                )}
              >
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold mb-1 overflow-hidden border-2 border-white shadow-md">
                  {player.player_image ? (
                    <img 
                      src={player.player_image} 
                      alt={player.lineup_player}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).onerror = null; 
                        (e.target as HTMLImageElement).src = homeBadge || 'https://via.placeholder.com/40';
                      }}
                    />
                  ) : (
                    <span>{player.lineup_number || '?'}</span>
                  )}
                </div>
                <div className="flex flex-col items-center">
                  <span className="bg-black/80 px-1 py-0.5 rounded text-white text-[10px] font-medium">
                    {player.lineup_number}
                  </span>
                  <span className="bg-black/80 mt-0.5 px-1 py-0.5 rounded text-white text-[10px] max-w-24 truncate text-center">
                    {player.lineup_player}
                  </span>
                </div>
              </div>
            ))
          ) : null}
          
          {/* Away team players (top) */}
          {Array.isArray(awayTeam.starting_lineups) && awayTeam.starting_lineups.length > 0 ? (
            awayTeam.starting_lineups.map((player, index) => (
              <div 
                key={`away-player-${player?.player_key || index}`}
                className={cn(
                  "flex flex-col items-center justify-center scale-75 transform",
                  getAwayPosition(player)
                )}
              >
                <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-white text-xs font-bold mb-1 overflow-hidden border-2 border-white shadow-md">
                  {player.player_image ? (
                    <img 
                      src={player.player_image} 
                      alt={player.lineup_player}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).onerror = null; 
                        (e.target as HTMLImageElement).src = awayBadge || 'https://via.placeholder.com/40';
                      }}
                    />
                  ) : (
                    <span>{player.lineup_number || '?'}</span>
                  )}
                </div>
                <div className="flex flex-col items-center">
                  <span className="bg-black/80 px-1 py-0.5 rounded text-white text-[10px] font-medium">
                    {player.lineup_number}
                  </span>
                  <span className="bg-black/80 mt-0.5 px-1 py-0.5 rounded text-white text-[10px] max-w-24 truncate text-center">
                    {player.lineup_player}
                  </span>
                </div>
              </div>
            ))
          ) : null}
        </div>
      </div>
      
      {/* Substitutes, Coach, and Missing Players */}
      <Tabs defaultValue="homeTeam" className="mt-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="homeTeam">{match.match_hometeam_name}</TabsTrigger>
          <TabsTrigger value="awayTeam">{match.match_awayteam_name}</TabsTrigger>
        </TabsList>
        
        {/* Home Team Tab */}
        <TabsContent value="homeTeam" className="space-y-4 mt-3">
          <div>
            <h4 className="text-sm font-semibold mb-2">Substitutes</h4>
            {Array.isArray(homeTeam?.substitutes) && homeTeam.substitutes.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {homeTeam.substitutes.map((player, index) => (
                  <PlayerItem 
                    key={`home-sub-${player?.player_key || index}`} 
                    player={player} 
                    teamBadge={homeBadge}
                    teamColor="bg-blue-600"
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No substitutes available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Coach</h4>
            {Array.isArray(homeTeam?.coach) && homeTeam.coach.length > 0 ? (
              <div className="space-y-2">
                {homeTeam.coach.map((coach, index) => (
                  <CoachItem 
                    key={`home-coach-${index}`} 
                    coach={coach} 
                    teamBadge={homeBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No coach information available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Missing Players</h4>
            {Array.isArray(homeTeam?.missing_players) && homeTeam.missing_players.length > 0 ? (
              <div className="space-y-2">
                {homeTeam.missing_players.map((player, index) => (
                  <MissingPlayerItem 
                    key={`home-missing-${player?.player_key || index}`} 
                    player={player}
                    teamBadge={homeBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No missing players</p>
            )}
          </div>
        </TabsContent>
        
        {/* Away Team Tab */}
        <TabsContent value="awayTeam" className="space-y-4 mt-3">
          <div>
            <h4 className="text-sm font-semibold mb-2">Substitutes</h4>
            {Array.isArray(awayTeam?.substitutes) && awayTeam.substitutes.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {awayTeam.substitutes.map((player, index) => (
                  <PlayerItem 
                    key={`away-sub-${player?.player_key || index}`} 
                    player={player} 
                    teamBadge={awayBadge}
                    teamColor="bg-red-600"
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No substitutes available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Coach</h4>
            {Array.isArray(awayTeam?.coach) && awayTeam.coach.length > 0 ? (
              <div className="space-y-2">
                {awayTeam.coach.map((coach, index) => (
                  <CoachItem 
                    key={`away-coach-${index}`} 
                    coach={coach} 
                    teamBadge={awayBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No coach information available</p>
            )}
          </div>
          
          <div>
            <h4 className="text-sm font-semibold mb-2">Missing Players</h4>
            {Array.isArray(awayTeam?.missing_players) && awayTeam.missing_players.length > 0 ? (
              <div className="space-y-2">
                {awayTeam.missing_players.map((player, index) => (
                  <MissingPlayerItem 
                    key={`away-missing-${player?.player_key || index}`} 
                    player={player}
                    teamBadge={awayBadge}
                  />
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-2">No missing players</p>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Helper Components
interface PlayerItemProps {
  player: LineupPlayer;
  teamBadge: string;
  teamColor?: string;
}

const PlayerItem = ({ player, teamBadge, teamColor = "bg-secondary" }: PlayerItemProps) => {
  if (!player) return null;
  
  const playerName = player.lineup_player || "Unknown";
  const playerNumber = player.lineup_number || '?';
  
  return (
    <div className="flex items-center p-2 rounded-lg hover:bg-muted">
      <div className={`w-8 h-8 rounded-full overflow-hidden mr-2 border-2 border-white ${teamColor}`}>
        {player.player_image ? (
          <img 
            src={player.player_image} 
            alt={playerName}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).onerror = null; 
              (e.target as HTMLImageElement).src = teamBadge || 'https://via.placeholder.com/32';
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-white text-xs font-bold">
            {playerNumber}
          </div>
        )}
      </div>
      <div>
        <div className="flex items-center">
          <span className={`text-xs font-semibold px-1 py-0.5 rounded mr-1 ${teamColor} text-white`}>
            {playerNumber}
          </span>
          <span className="text-sm font-medium">{playerName}</span>
        </div>
      </div>
    </div>
  );
};

interface CoachItemProps {
  coach: Coach;
  teamBadge: string;
}

const CoachItem = ({ coach, teamBadge }: CoachItemProps) => {
  if (!coach) return null;
  
  const coachName = coach.lineup_player || "Unknown Coach";
  
  return (
    <div className="flex items-center p-2 rounded-lg hover:bg-muted">
      <div className="w-8 h-8 rounded-full overflow-hidden mr-2 border-2 border-amber-500">
        {coach.player_image ? (
          <img 
            src={coach.player_image} 
            alt={coachName}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).onerror = null; 
              (e.target as HTMLImageElement).src = teamBadge || 'https://via.placeholder.com/32';
            }}
          />
        ) : (
          <div className="w-full h-full bg-amber-500/20 flex items-center justify-center text-amber-600 text-xs">
            C
          </div>
        )}
      </div>
      <div>
        <span className="text-sm font-medium block">{coachName}</span>
        <span className="text-xs px-1 py-0.5 bg-amber-500/20 text-amber-700 rounded">Head Coach</span>
      </div>
    </div>
  );
};

interface MissingPlayerItemProps {
  player: MissingPlayer;
  teamBadge: string;
}

const MissingPlayerItem = ({ player, teamBadge }: MissingPlayerItemProps) => {
  if (!player) return null;
  
  const playerName = player.lineup_player || "Unknown";
  const playerReason = player.player_reason || "Unknown reason";
  
  return (
    <div className="flex items-center p-2 rounded-lg hover:bg-muted">
      <div className="w-8 h-8 rounded-full overflow-hidden mr-2 border-2 border-red-300 opacity-60">
        {player.player_image ? (
          <img 
            src={player.player_image} 
            alt={playerName}
            className="w-full h-full object-cover grayscale"
            onError={(e) => {
              (e.target as HTMLImageElement).onerror = null; 
              (e.target as HTMLImageElement).src = teamBadge || 'https://via.placeholder.com/32';
            }}
          />
        ) : (
          <div className="w-full h-full bg-muted flex items-center justify-center text-xs font-medium">
            ?
          </div>
        )}
      </div>
      <div>
        <span className="text-sm font-medium text-muted-foreground">{playerName}</span>
        <span className="text-xs block text-red-500">{playerReason}</span>
      </div>
    </div>
  );
};
