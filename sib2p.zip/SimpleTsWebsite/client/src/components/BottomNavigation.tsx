import React from 'react';
import { useLocation } from 'wouter';
import { Home, Volleyball, Trophy, Newspaper, User } from 'lucide-react';

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  // Helper function to check if the route is active
  const isActive = (path: string) => {
    if (path === '/' && location === '/') return true;
    if (path !== '/' && location.startsWith(path)) return true;
    return false;
  };

  // Navigate to a route
  const navigateTo = (path: string) => {
    setLocation(path);
  };

  return (
    <nav className="bg-card border-t border-border shadow-md z-10">
      <div className="flex justify-between px-6 py-2">
        <div 
          onClick={() => navigateTo('/')}
          className={`nav-item flex flex-col items-center pt-1 pb-1 cursor-pointer ${isActive('/') ? 'text-primary' : 'text-muted-foreground'}`}
        >
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1">Home</span>
        </div>
        
        <div 
          onClick={() => navigateTo('/matches')}
          className={`nav-item flex flex-col items-center pt-1 pb-1 cursor-pointer ${isActive('/matches') ? 'text-primary' : 'text-muted-foreground'}`}
        >
          <Volleyball className="h-5 w-5" />
          <span className="text-xs mt-1">Matches</span>
        </div>
        
        <div 
          onClick={() => navigateTo('/leagues')}
          className={`nav-item flex flex-col items-center pt-1 pb-1 cursor-pointer ${isActive('/leagues') ? 'text-primary' : 'text-muted-foreground'}`}
        >
          <Trophy className="h-5 w-5" />
          <span className="text-xs mt-1">Leagues</span>
        </div>
        
        <div 
          onClick={() => navigateTo('/news')}
          className={`nav-item flex flex-col items-center pt-1 pb-1 cursor-pointer ${isActive('/news') ? 'text-primary' : 'text-muted-foreground'}`}
        >
          <Newspaper className="h-5 w-5" />
          <span className="text-xs mt-1">News</span>
        </div>
        
        <div 
          onClick={() => navigateTo('/account')}
          className={`nav-item flex flex-col items-center pt-1 pb-1 cursor-pointer ${isActive('/account') ? 'text-primary' : 'text-muted-foreground'}`}
        >
          <User className="h-5 w-5" />
          <span className="text-xs mt-1">Account</span>
        </div>
      </div>
    </nav>
  );
}
