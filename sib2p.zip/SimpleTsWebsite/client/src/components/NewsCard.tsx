import React from 'react';
import { useLocation } from 'wouter';
import { News } from '@/lib/types';
import { getRelativeTime } from '@/lib/api';
import { cn } from '@/lib/utils';

interface NewsCardProps {
  news: News;
  compact?: boolean;
  className?: string;
}

export default function NewsCard({ news, compact = false, className }: NewsCardProps) {
  const [, setLocation] = useLocation();
  
  const handleClick = () => {
    setLocation(`/news/${news.slug}`);
  };
  
  if (compact) {
    return (
      <div
        className={cn("flex items-start space-x-3 p-3 bg-card rounded-lg shadow cursor-pointer", className)}
        onClick={handleClick}
      >
        <img
          src={news.image}
          alt={news.title}
          className="w-16 h-16 object-cover rounded-md flex-shrink-0"
          onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/64/121F3D/FFFFFF?text=News' }}
        />
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-sm mb-1 line-clamp-2">{news.title}</h3>
          <div className="flex items-center text-xs text-muted-foreground">
            {news.tags.length > 0 && (
              <span className="bg-secondary rounded px-1 py-0.5 mr-2">
                {news.tags[0]}
              </span>
            )}
            <span>{getRelativeTime(news.publishedAt)}</span>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div
      className={cn("bg-card rounded-lg overflow-hidden shadow cursor-pointer", className)}
      onClick={handleClick}
    >
      <img
        src={news.image}
        alt={news.title}
        className="w-full h-40 object-cover"
        onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/400x200/121F3D/FFFFFF?text=News' }}
      />
      <div className="p-3">
        <div className="flex items-center space-x-2 mb-2">
          {news.tags.length > 0 && (
            <span className="text-xs bg-secondary px-2 py-0.5 rounded text-muted-foreground">
              {news.tags[0]}
            </span>
          )}
          <span className="text-xs text-muted-foreground">{getRelativeTime(news.publishedAt)}</span>
        </div>
        <h3 className="font-medium mb-1 line-clamp-2">{news.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {news.content.replace(/<[^>]*>?/gm, '').substring(0, 120)}...
        </p>
      </div>
    </div>
  );
}
