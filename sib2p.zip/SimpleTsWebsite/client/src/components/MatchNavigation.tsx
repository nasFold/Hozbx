import { cn } from "@/lib/utils";
import { useCallback } from "react";

interface MatchNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  className?: string;
}

export default function MatchNavigation({ activeTab, onTabChange, className }: MatchNavigationProps) {
  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "timeline", label: "Timeline" },
    { id: "stats", label: "Stats" },
    { id: "lineup", label: "Lineup" },
    { id: "h2h", label: "H2H" },
    { id: "standings", label: "Standings" },
  ];

  // Optimasi event handler dengan useCallback
  const handleTabChange = useCallback((tabId: string) => {
    onTabChange(tabId);
  }, [onTabChange]);

  return (
    <div className={cn("bg-background border-b border-border mb-2 sticky top-0 z-10 shadow-sm", className)}>
      <div className="container px-4 mx-auto">
        <div className="flex overflow-x-auto space-x-6 justify-between md:justify-start no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={cn(
                "py-3 font-medium text-sm whitespace-nowrap transition-colors relative",
                activeTab === tab.id
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-primary/80"
              )}
              onClick={() => handleTabChange(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}