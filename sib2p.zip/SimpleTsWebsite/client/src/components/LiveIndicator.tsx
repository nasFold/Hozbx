import React from 'react';
import { cn } from '@/lib/utils';

interface LiveIndicatorProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export default function LiveIndicator({ className, size = 'md', showText = true }: LiveIndicatorProps) {
  const sizeMap = {
    sm: 'w-1.5 h-1.5',
    md: 'w-2 h-2',
    lg: 'w-2.5 h-2.5'
  };
  
  const textSizeMap = {
    sm: 'text-xs',
    md: 'text-xs',
    lg: 'text-sm'
  };
  
  return (
    <span className={cn(
      "bg-destructive px-2 py-0.5 rounded-full text-destructive-foreground font-medium flex items-center",
      textSizeMap[size],
      className
    )}>
      <span className={cn(
        "bg-white rounded-full mr-1 live-indicator",
        sizeMap[size]
      )} />
      {showText && 'LIVE'}
    </span>
  );
}
