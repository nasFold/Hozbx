import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

interface StatRingProps {
  homeStat: number | string;
  awayStat: number | string;
  homeTeam: string;
  awayTeam: string;
  label: string;
  className?: string;
  icon?: React.ReactNode;
}

export default function StatRing({ 
  homeStat, 
  awayStat, 
  homeTeam,
  awayTeam,
  label, 
  className,
  icon
}: StatRingProps) {
  // Convert stats to numbers if they're strings
  const homeValue = typeof homeStat === 'string' ? parseFloat(homeStat) || 0 : homeStat;
  const awayValue = typeof awayStat === 'string' ? parseFloat(awayStat) || 0 : awayStat;
  
  // Create data for the pie chart
  const data = [
    { name: homeTeam, value: homeValue },
    { name: awayTeam, value: awayValue }
  ];
  
  // Calculate total and percentages
  const total = homeValue + awayValue;
  const homePercent = total > 0 ? Math.round((homeValue / total) * 100) : 0;
  const awayPercent = total > 0 ? Math.round((awayValue / total) * 100) : 0;
  
  return (
    <div className={cn("flex flex-col items-center", className)}>
      <h3 className="text-sm font-medium text-center mb-2">{label}</h3>
      
      <div className="relative w-[120px] h-[120px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={30}
              outerRadius={45}
              paddingAngle={2}
              dataKey="value"
              startAngle={90}
              endAngle={-270}
              animationDuration={300}
              animationEasing="linear"
              isAnimationActive={total > 0}
            >
              <Cell fill="hsl(var(--primary))" stroke="hsl(var(--primary))" strokeWidth={1} />
              <Cell fill="hsl(var(--destructive))" stroke="hsl(var(--destructive))" strokeWidth={1} />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        
        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {icon && (
            <div className="text-muted-foreground mb-1">
              {icon}
            </div>
          )}
          <span className="text-lg font-bold">
            {homePercent}%
          </span>
          <span className="text-[10px] text-muted-foreground">
            vs {awayPercent}%
          </span>
        </div>
      </div>
      
      <div className="mt-3 flex justify-center w-full gap-4 text-xs">
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-primary mr-1"></div>
          <span>{homeTeam}</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-destructive mr-1"></div>
          <span>{awayTeam}</span>
        </div>
      </div>
    </div>
  );
}
