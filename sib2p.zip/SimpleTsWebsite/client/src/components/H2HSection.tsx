import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Match } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatRelativeDate } from '@/lib/api';
import { CalendarDays, RefreshCcw, Trophy } from 'lucide-react';

interface H2HSectionProps {
  match: Match;
  className?: string;
}

export default function H2HSection({ match, className }: H2HSectionProps) {
  const [location, setLocation] = useLocation();
  const [debug, setDebug] = useState({
    fetchAttempt: 0,
    lastResponse: null as any,
    responseType: ''
  });

  const { data: h2hData, isLoading, error, refetch } = useQuery({
    queryKey: ['h2h', match.match_hometeam_id, match.match_awayteam_id],
    queryFn: async () => {
      if (!match.match_hometeam_id || !match.match_awayteam_id) {
        console.warn("Both team IDs are required for H2H");
        return { firstTeam_VS_secondTeam: [] };
      }

      setDebug(prev => ({ ...prev, fetchAttempt: prev.fetchAttempt + 1 }));

      try {
        console.log(`Fetching H2H for ${match.match_hometeam_name} (${match.match_hometeam_id}) vs ${match.match_awayteam_name} (${match.match_awayteam_id})`);

        // Menggunakan format endpoint yang benar untuk H2H
        const response = await fetch(`/api/football/h2h?firstTeam_id=${match.match_hometeam_id}&secondTeam_id=${match.match_awayteam_id}`);
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        setDebug(prev => ({ 
          ...prev, 
          lastResponse: data,
          responseType: Array.isArray(data) ? 'array' : (typeof data === 'object' ? 'object' : typeof data)
        }));

        // Improved data handling, with better error tracking
        console.log('H2H raw data received:', typeof data);

        // Handle different API response formats
        if (Array.isArray(data)) {
          // Direct array format
          console.log('H2H returned as array format with', data.length, 'matches');
          return { firstTeam_VS_secondTeam: data };
        } else if (data && typeof data === 'object' && Array.isArray(data.firstTeam_VS_secondTeam)) {
          // Nested object format
          console.log('H2H returned in nested object format with', data.firstTeam_VS_secondTeam.length, 'matches');
          return data;
        } else if (data && typeof data === 'object') {
          // Some other object format, we'll try to extract matches
          console.log('H2H returned in unexpected format, attempting to normalize');
          const matches = Object.values(data).filter(item => 
            typeof item === 'object' && 
            item !== null && 
            'match_hometeam_score' in item && 
            'match_awayteam_score' in item
          );
          return { firstTeam_VS_secondTeam: matches };
        }
        
        console.warn('Unexpected H2H data format, returning empty array');
        return { firstTeam_VS_secondTeam: [] };
      } catch (error) {
        console.error('Error fetching H2H data in component:', error);
        return { firstTeam_VS_secondTeam: [] }; 
      }
    },
    enabled: Boolean(match.match_hometeam_id && match.match_awayteam_id),
    retry: 2,
    staleTime: 300000, 
  });

  const [stats, setStats] = useState({
    total: 0,
    homeWins: 0,
    draws: 0,
    awayWins: 0,
  });

  useEffect(() => {
    if (h2hData?.firstTeam_VS_secondTeam && Array.isArray(h2hData.firstTeam_VS_secondTeam)) {
      const matches = h2hData.firstTeam_VS_secondTeam;
      let homeWins = 0;
      let draws = 0;
      let awayWins = 0;

      for (const m of matches) {
        const homeScore = parseInt(m.match_hometeam_score);
        const awayScore = parseInt(m.match_awayteam_score);

        if (isNaN(homeScore) || isNaN(awayScore)) continue;

        if (homeScore === awayScore) {
          draws++;
        } else if (homeScore > awayScore) {
          homeWins += (m.match_hometeam_id === match.match_hometeam_id) ? 1 : 0;
          awayWins += (m.match_hometeam_id !== match.match_hometeam_id) ? 1 : 0;

        } else {
          homeWins += (m.match_awayteam_id === match.match_hometeam_id) ? 1 : 0;
          awayWins += (m.match_awayteam_id !== match.match_hometeam_id) ? 1 : 0;
        }
      }

      setStats({
        homeWins,
        draws,
        awayWins,
        total: matches.length,
      });
    }
  }, [h2hData, match.match_hometeam_id]);

  if (isLoading) {
    return (
      <Card className={cn("bg-card shadow", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Head-to-Head</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Skeleton className="w-full h-6" />
            <Skeleton className="w-full h-24" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={cn("bg-card shadow", className)}>
        <CardHeader className="pb-2 flex justify-between items-center">
          <CardTitle className="text-lg">Head-to-Head</CardTitle>
          <button 
            className="text-primary hover:text-primary/80 p-1 rounded-full hover:bg-primary/10 transition-colors"
            onClick={() => refetch()}
            title="Retry loading H2H data"
          >
            <RefreshCcw size={18} />
          </button>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 space-y-3">
            <p className="text-muted-foreground">
              Error loading head-to-head information.
            </p>
            <div className="text-xs text-muted-foreground/70 text-center">
              {String(error).includes('404') 
                ? 'No records found for these teams' 
                : 'There was a problem connecting to the server'}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const hasH2H = h2hData?.firstTeam_VS_secondTeam?.length > 0;

  if (!hasH2H) {
    return (
      <Card className={cn("bg-card shadow", className)}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Head-to-Head</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center text-muted-foreground">
              <Trophy size={32} className="opacity-50" />
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold">First Meeting</h3>
              <p className="text-muted-foreground text-sm max-w-md">
                This appears to be the first recorded match between {match.match_hometeam_name} and {match.match_awayteam_name}.
              </p>
            </div>
            <div className="flex items-center text-sm text-muted-foreground space-x-1 mt-2">
              <CalendarDays size={14} />
              <span>No previous match history</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("bg-card shadow", className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Head-to-Head</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <div className="text-center">
            <div className="text-lg font-bold text-primary">{stats.homeWins}</div>
            <div className="text-xs text-muted-foreground">{match.match_hometeam_name}</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold">{stats.draws}</div>
            <div className="text-xs text-muted-foreground">Draws</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-destructive">{stats.awayWins}</div>
            <div className="text-xs text-muted-foreground">{match.match_awayteam_name}</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold">{stats.total}</div>
            <div className="text-xs text-muted-foreground">Total</div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-sm font-medium">Previous Matches</h3>
          {h2hData.firstTeam_VS_secondTeam.slice(0, 5).map((h2hMatch: any, index: number) => (
            <div 
              key={index} 
              className="flex items-center justify-between py-2 border-b border-border last:border-0 hover:bg-secondary/20 rounded-md px-2 cursor-pointer transition-colors"
              onClick={() => h2hMatch.match_id && setLocation(`/match/${h2hMatch.match_id}`)}
            >
              <div className="flex items-center space-x-3">
                <div className="text-xs text-muted-foreground">
                  {formatRelativeDate(h2hMatch.match_date)}
                </div>
              </div>

              <div className="flex items-center justify-center space-x-2">
                <span className="text-sm font-medium hover:text-primary">
                  {h2hMatch.match_hometeam_name}
                </span>
                <div className="px-2 text-sm font-bold bg-background/80 rounded-md py-1">
                  {h2hMatch.match_hometeam_score} - {h2hMatch.match_awayteam_score}
                </div>
                <span className="text-sm font-medium hover:text-primary">
                  {h2hMatch.match_awayteam_name}
                </span>
              </div>

              <div className="text-xs text-muted-foreground">
                {h2hMatch.league_name}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}