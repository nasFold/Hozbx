import { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

interface MatchMomentumGraphProps {
  homeTeam: string;
  awayTeam: string;
  homeAttacks: string[] | number[];
  awayAttacks: string[] | number[];
  className?: string;
}

export default function MatchMomentumGraph({
  homeTeam,
  awayTeam,
  homeAttacks,
  awayAttacks,
  className
}: MatchMomentumGraphProps) {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    try {
      // Convert string values to numbers if needed
      const processedHomeAttacks = (homeAttacks || []).map(val => 
        typeof val === 'string' ? parseInt(val, 10) || 0 : (val || 0)
      );
      const processedAwayAttacks = (awayAttacks || []).map(val => 
        typeof val === 'string' ? parseInt(val, 10) || 0 : (val || 0)
      );
      
      // Reduce data points for better performance (maximum 9 points)
      const maxPoints = 9;
      const interval = Math.max(1, Math.ceil(processedHomeAttacks.length / maxPoints));
      
      // Create data points for the chart (with reduced number of points)
      const chartData = [];
      for (let i = 0; i < processedHomeAttacks.length; i += interval) {
        chartData.push({
          minute: (i + 1) * 10, // 10-minute intervals
          home: processedHomeAttacks[i] || 0,
          away: processedAwayAttacks[i] || 0
        });
      }
      
      // If we don't have data, show placeholder data points
      if (chartData.length === 0) {
        // Add three sample points for empty visualization
        [15, 45, 75].forEach(minute => {
          chartData.push({
            minute,
            home: 0,
            away: 0
          });
        });
      }
      
      setData(chartData);
    } catch (error) {
      console.error('Error processing momentum graph data:', error);
      // Provide fallback data to prevent UI errors
      setData([{ minute: 45, home: 0, away: 0 }]);
    }
  }, [homeAttacks, awayAttacks]);

  return (
    <div className={cn("w-full h-64", className)}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 10, right: 0, left: 0, bottom: 0 }}
        >
          <defs>
            <linearGradient id="homeGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
              <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.1} />
            </linearGradient>
            <linearGradient id="awayGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.8} />
              <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0.1} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} vertical={false} />
          <XAxis 
            dataKey="minute" 
            tick={{ fontSize: 10 }}
            tickCount={5}
          />
          <YAxis 
            tick={{ fontSize: 10 }}
            tickCount={3}
          />
          <Tooltip 
            formatter={(value, name) => {
              const teamName = name === 'home' ? homeTeam : awayTeam;
              return [`${value} attacks`, teamName];
            }}
            labelFormatter={(label) => `Minute ${label}`}
            contentStyle={{ 
              fontSize: '11px', 
              padding: '4px 8px',
              borderRadius: '4px',
              boxShadow: '0 2px 5px rgba(0,0,0,0.15)'
            }}
            wrapperStyle={{ zIndex: 5 }}
            isAnimationActive={false}
          />
          <Area 
            type="monotone" 
            dataKey="home" 
            name="home"
            stroke="hsl(var(--primary))" 
            fillOpacity={1} 
            fill="url(#homeGradient)" 
            strokeWidth={2}
          />
          <Area 
            type="monotone" 
            dataKey="away" 
            name="away"
            stroke="hsl(var(--destructive))" 
            fillOpacity={1} 
            fill="url(#awayGradient)" 
            strokeWidth={2}
          />
        </AreaChart>
      </ResponsiveContainer>
      
      <div className="flex justify-center mt-2">
        <div className="flex items-center mr-4">
          <div className="w-3 h-3 bg-primary rounded-full mr-1"></div>
          <span className="text-xs">{homeTeam}</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-destructive rounded-full mr-1"></div>
          <span className="text-xs">{awayTeam}</span>
        </div>
      </div>
    </div>
  );
}
