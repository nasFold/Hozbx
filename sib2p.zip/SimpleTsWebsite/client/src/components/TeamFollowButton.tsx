import React, { useState } from 'react';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/api';
import useUserTeams from '@/hooks/useUserTeams';
import useAuth from '@/hooks/useAuth';
import { useLocation } from 'wouter';

interface TeamFollowButtonProps {
  teamId: string;
  teamName: string;
  teamLogo?: string;
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'default' | 'lg';
}

export default function TeamFollowButton({
  teamId,
  teamName,
  teamLogo,
  className,
  variant = 'outline',
  size = 'default'
}: TeamFollowButtonProps) {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const { followedTeams, addTeam, removeTeam, isLoading } = useUserTeams();
  const [, setLocation] = useLocation();
  
  const isFollowing = followedTeams?.some(team => team.id === teamId);
  
  const handleToggleFollow = async () => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication required",
        description: "Please log in to follow teams",
        variant: "destructive"
      });
      setLocation('/login');
      return;
    }
    
    try {
      if (isFollowing) {
        await removeTeam(teamId);
        toast({
          title: "Team unfollowed",
          description: `You are no longer following ${teamName}`
        });
      } else {
        await addTeam({
          id: teamId,
          name: teamName,
          logo: teamLogo
        });
        toast({
          title: "Team followed",
          description: `You are now following ${teamName}`
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update followed teams",
        variant: "destructive"
      });
    }
  };
  
  return (
    <Button
      variant={isFollowing ? 'default' : variant}
      size={size}
      className={cn(className)}
      onClick={handleToggleFollow}
      disabled={isLoading}
    >
      <Star 
        className={cn(
          "mr-1",
          size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4',
          isFollowing ? 'fill-current' : ''
        )} 
      />
      {isFollowing ? 'Following' : 'Follow'}
    </Button>
  );
}
