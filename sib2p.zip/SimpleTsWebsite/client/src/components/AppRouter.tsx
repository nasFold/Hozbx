import { lazy, Suspense } from 'react';
import { Route, Switch } from 'wouter';
import { ROUTES } from '@/lib/router';
import { ErrorBoundary } from './ErrorBoundary';

// Loading component for Suspense fallback
const PageLoading = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
  </div>
);

// Lazy load pages for better performance
const HomePage = lazy(() => import("@/pages/HomePage"));
const MatchesPage = lazy(() => import("@/pages/MatchesPage"));
const MatchDetailPage = lazy(() => import("@/pages/MatchDetailPage"));
const LeaguesPage = lazy(() => import("@/pages/LeaguesPage"));
const LeagueDetailPage = lazy(() => import("@/pages/LeagueDetailPage"));
const TeamPage = lazy(() => import("@/pages/TeamPage"));
const PlayerPage = lazy(() => import("@/pages/PlayerPage"));
const NewsPage = lazy(() => import("@/pages/NewsPage"));
const NewsDetailPage = lazy(() => import("@/pages/NewsDetailPage"));
const SearchPage = lazy(() => import("@/pages/SearchPage"));
const LoginPage = lazy(() => import("@/pages/LoginPage"));
const RegisterPage = lazy(() => import("@/pages/RegisterPage"));
const AccountPage = lazy(() => import("@/pages/AccountPage"));
const PinnedMatchesPage = lazy(() => import("@/pages/PinnedMatchesPage"));
const AdminPage = lazy(() => import("@/pages/AdminPage"));
const OwnerPage = lazy(() => import("@/pages/OwnerPage"));
const NotFound = lazy(() => import("@/pages/not-found"));

export default function AppRouter() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<PageLoading />}>
        <Switch>
          {/* Main Pages */}
          <Route path={ROUTES.HOME.path} component={HomePage} />
          <Route path={ROUTES.MATCHES.path} component={MatchesPage} />
          <Route path={ROUTES.LEAGUES.path} component={LeaguesPage} />
          <Route path={ROUTES.NEWS.path} component={NewsPage} />
          <Route path={ROUTES.SEARCH.path} component={SearchPage} />
          
          {/* Auth Pages */}
          <Route path={ROUTES.LOGIN.path} component={LoginPage} />
          <Route path={ROUTES.REGISTER.path} component={RegisterPage} />
          <Route path={ROUTES.ACCOUNT.path} component={AccountPage} />
          <Route path={ROUTES.PINNED.path} component={PinnedMatchesPage} />
          
          {/* Detail Pages with standard and SEO-friendly URLs */}
          <Route path="/match/:id/:slug?" component={MatchDetailPage} />
          <Route path="/league/:id/:slug?" component={LeagueDetailPage} />
          <Route path="/team/:id/:slug?" component={TeamPage} />
          <Route path="/player/:id/:slug?" component={PlayerPage} />
          <Route path="/news/:slug" component={NewsDetailPage} />
          
          {/* Admin Pages */}
          <Route path={ROUTES.ADMIN.path} component={AdminPage} />
          <Route path={ROUTES.OWNER.path} component={OwnerPage} />
          
          {/* 404 Not Found */}
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </ErrorBoundary>
  );
}