declare module 'react-lazy-load-image-component' {
  import * as React from 'react';

  export interface LazyLoadImageProps {
    alt?: string;
    height?: number | string;
    width?: number | string;
    src: string;
    effect?: 'blur' | 'black-and-white' | 'opacity';
    placeholder?: React.ReactNode;
    threshold?: number;
    className?: string;
    placeholderSrc?: string;
    wrapperClassName?: string;
    afterLoad?: () => void;
    beforeLoad?: () => void;
    delayMethod?: 'debounce' | 'throttle';
    delayTime?: number;
    visibleByDefault?: boolean;
    scrollPosition?: {
      x: number;
      y: number;
    };
  }

  export class LazyLoadImage extends React.Component<LazyLoadImageProps> {}

  export interface TrackWindowScrollProps {
    children: React.ReactNode;
    offset?: number;
    debounce?: boolean;
    throttle?: boolean;
  }

  export function trackWindowScroll<P extends TrackWindowScrollProps>(
    BaseComponent: React.ComponentType<P>
  ): React.ComponentType<P>;
}