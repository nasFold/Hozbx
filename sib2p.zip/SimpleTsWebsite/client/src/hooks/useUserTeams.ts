import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { API, apiRequest } from '@/lib/api';
import { FollowedTeam } from '@/lib/types';
import useAuth from './useAuth';

export default function useUserTeams() {
  const queryClient = useQueryClient();
  const { isAuthenticated } = useAuth();
  
  // Fetch user's followed teams
  const { 
    data,
    isLoading,
    error
  } = useQuery<{ followedTeams: FollowedTeam[] }>({
    queryKey: [API.user.teams],
    enabled: isAuthenticated,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Add team mutation
  const addTeamMutation = useMutation({
    mutationFn: (team: FollowedTeam) => 
      apiRequest('POST', API.user.teams, {
        teamId: team.id,
        teamName: team.name,
        teamLogo: team.logo
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [API.user.teams] });
    }
  });
  
  // Remove team mutation
  const removeTeamMutation = useMutation({
    mutationFn: (teamId: string) => 
      apiRequest('DELETE', API.user.removeTeam(teamId)),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [API.user.teams] });
    }
  });
  
  return {
    followedTeams: data?.followedTeams || [],
    isLoading,
    error: error as Error | null,
    addTeam: addTeamMutation.mutate,
    removeTeam: removeTeamMutation.mutate,
    isAddingTeam: addTeamMutation.isPending,
    isRemovingTeam: removeTeamMutation.isPending
  };
}
