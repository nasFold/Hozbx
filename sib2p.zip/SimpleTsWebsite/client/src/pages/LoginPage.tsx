import React from 'react';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import PageContainer from '@/components/PageContainer';
import useAuth from '@/hooks/useAuth';
import LoadingSpinner from '@/components/LoadingSpinner';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';

// Define the login form schema
const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  rememberMe: z.boolean().optional()
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { login, loginLoading, loginError, isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  // Initialize form
  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false
    }
  });
  
  // If already logged in, redirect to account page
  React.useEffect(() => {
    if (isAuthenticated) {
      setLocation('/account');
    }
  }, [isAuthenticated, setLocation]);
  
  // Form submission handler
  const onSubmit = async (values: LoginFormValues) => {
    try {
      console.log(`Attempting login for user: ${values.username}`);
      
      const result = await login({ 
        username: values.username,
        password: values.password
      });
      
      console.log("Login result:", result);
      
      // If remember me is checked, store in localStorage
      if (values.rememberMe) {
        localStorage.setItem('sibola_remember_username', values.username);
      } else {
        localStorage.removeItem('sibola_remember_username');
      }
      
      toast({
        title: "Login successful",
        description: "Welcome back to Sibola!"
      });
      
      // Redirect to account page
      setLocation('/account');
    } catch (error) {
      // Log the error for debugging
      console.error("Login error:", error);
      console.error("Login error details:", loginError);
      
      // Show error toast with more specific details
      toast({
        title: "Login gagal",
        description: loginError?.message || "Kredensial tidak valid. Pastikan username dan password benar, atau pastikan Anda telah terdaftar.",
        variant: "destructive"
      });
    }
  };
  
  // Get remembered username from localStorage on mount
  React.useEffect(() => {
    const rememberedUsername = localStorage.getItem('sibola_remember_username');
    if (rememberedUsername) {
      form.setValue('username', rememberedUsername);
      form.setValue('rememberMe', true);
    }
  }, [form]);
  
  return (
    <PageContainer showBack title="Login">
      <div className="max-w-md mx-auto">
        <Card>
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold">Login</CardTitle>
            <CardDescription>
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your username" 
                          {...field} 
                          autoComplete="username"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Enter your password" 
                          {...field} 
                          autoComplete="current-password"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="rememberMe"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <FormLabel className="text-sm font-normal cursor-pointer">
                        Remember me
                      </FormLabel>
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={loginLoading}
                >
                  {loginLoading ? (
                    <LoadingSpinner size="sm" />
                  ) : "Sign In"}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-sm text-center text-muted-foreground">
              Don't have an account?{" "}
              <Button 
                variant="link" 
                className="p-0 h-auto" 
                onClick={() => setLocation('/register')}
              >
                Register
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </PageContainer>
  );
}
