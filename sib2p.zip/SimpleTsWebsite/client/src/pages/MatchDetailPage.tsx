import React, { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import {
  API,
  formatDateForAPI,
  formatTime,
  formatDate,
  getUserTimezone,
  getHistoricalStartDate,
} from "@/lib/api";
import { Match, H2H, TeamStanding } from "@/lib/types";
import { useWebSocket } from "@/contexts/WebSocketContext";
import PageContainer from "@/components/PageContainer";
import MatchHeader from "@/components/MatchHeader";
import MatchNavigation from "@/components/MatchNavigation";
import MatchTimeline from "@/components/MatchTimeline";
import MatchStatBar from "@/components/MatchStatBar";
import StatBarAdvanced from "@/components/StatBarAdvanced";
import Lineup from "@/components/Lineup";
import StatDoughnut from "@/components/StatDoughnut";
import StatRing from "@/components/StatRing";
import MatchMomentumGraph from "@/components/MatchMomentumGraph";
import LoadingSpinner from "@/components/LoadingSpinner";
import TeamFollowButton from "@/components/TeamFollowButton";
import H2HSection from "@/components/H2HSection";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Activity, Target, Zap, Trophy, Shield } from "lucide-react";

export default function MatchDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState("overview");
  const { subscribeToMatch, matchDetails } = useWebSocket();
  const timezone = getUserTimezone();

  // Fetch match details with complete data
  const { data: matchData, isLoading: matchLoading } = useQuery<Match[]>({
    queryKey: [
      API.football.events,
      { match_id: id, withPlayerStats: "1", timezone },
    ],
    enabled: !!id,
    staleTime: 1000 * 60, // 1 minute
    refetchOnWindowFocus: false,
  });

  // Fetch H2H data
  const { data: h2hData, isLoading: h2hLoading } = useQuery<H2H>({
    queryKey: [
      API.football.h2h,
      {
        firstTeam_id: matchData?.[0]?.match_hometeam_id,
        secondTeam_id: matchData?.[0]?.match_awayteam_id,
      },
    ],
    queryFn: async () => {
      try {
        console.log('Fetching H2H data for', matchData?.[0]?.match_hometeam_name, 'vs', matchData?.[0]?.match_awayteam_name);
        const response = await fetch(
          `${API.football.h2h}?firstTeam_id=${matchData?.[0]?.match_hometeam_id}&secondTeam_id=${matchData?.[0]?.match_awayteam_id}`,
        );
        
        if (!response.ok) {
          console.error(`H2H Network response was not ok: ${response.status}`);
          return { firstTeam_VS_secondTeam: [] }; // Return valid empty data structure
        }
        
        const data = await response.json();
        console.log('H2H data received:', data);
        
        // Selalu kembalikan format data yang diharapkan bahkan jika API mengembalikan format lain
        if (!data || !data.firstTeam_VS_secondTeam) {
          console.log('Transforming H2H data to expected format');
          return { firstTeam_VS_secondTeam: [] };
        }
        
        return data;
      } catch (error) {
        console.error('Error fetching H2H data:', error);
        return { firstTeam_VS_secondTeam: [] }; // Return valid empty data structure on error
      }
    },
    enabled:
      !!matchData?.[0]?.match_hometeam_id &&
      !!matchData?.[0]?.match_awayteam_id,
    retry: 1,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Determine which match data to use (WebSocket or API)
  const match = matchDetails[id] || matchData?.[0];

  // Fetch league standings
  const { data: standingsData, isLoading: standingsLoading } = useQuery<
    TeamStanding[]
  >({
    queryKey: [
      API.football.standings,
      { league_id: match?.league_id || matchData?.[0]?.league_id },
    ],
    queryFn: async () => {
      // Gunakan data league_id dari match WebSocket data jika tersedia, atau dari matchData
      const leagueId = match?.league_id || matchData?.[0]?.league_id;
      
      if (!leagueId) {
        throw new Error("League ID is required");
      }
      
      console.log(`Fetching standings for league ID: ${leagueId}`);
      
      try {
        const response = await fetch(
          `${API.football.standings}?league_id=${leagueId}`,
        );
        
        if (!response.ok) {
          console.error(`Standings API error: ${response.status} - ${response.statusText}`);
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        
        const data = await response.json();
        console.log(`Successfully fetched standings for league ID: ${leagueId}`);
        return data;
      } catch (error) {
        console.error("Error fetching standings:", error);
        throw error;
      }
    },
    enabled: !!(match?.league_id || matchData?.[0]?.league_id),
    retry: 3,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Subscribe to real-time match updates - optimized to prevent excessive resubscribes
  useEffect(() => {
    if (id) {
      // Subscribe only once per match ID
      subscribeToMatch(id);
      
      // No need for refresh interval since WebSocket connection
      // will provide real-time updates automatically
    }
  }, [id, subscribeToMatch]);
  
  // Helper function to generate progressive attacks array for momentum chart
  function getProgressiveAttacks(match: Match, side: "home" | "away"): number[] {
    if (!match.statistics) return [0];
    
    // Find attack statistics
    const attacks = match.statistics?.find(s => s.type === "Dangerous Attacks")?.[side] ||
      match.statistics?.find(s => s.type === "Attacks")?.[side] ||
      "0";
    
    // Convert to number
    const attacksNum = typeof attacks === 'string' ? parseInt(attacks) || 0 : attacks;
    
    // Generate progressive array (9 data points for better performance)
    if (attacksNum <= 0) return [0];
    
    return Array.from({ length: 9 }, (_, i) => 
      Math.round((i + 1) * attacksNum / 9)
    );
  }

  // Log untuk debugging sumber data - tanpa interval refresh berlebihan
  useEffect(() => {
    if (matchDetails[id]) {
      // Using WebSocket data - no need to log full details
      console.log('Using WebSocket data for match:', id);
    } else if (matchData?.[0]) {
      // Using API data - no need to log full details
      console.log('Using API data for match:', id);
    }
    
    // Tidak perlu resubscribe setiap 10 detik karena WebSocket
    // akan otomatis memberikan update secara real-time
  }, [id, matchDetails, matchData]);

  // Check for various loading states and handle them appropriately
  if (matchLoading) {
    return (
      <PageContainer showBack title="Match Details">
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading match details..." />
        </div>
      </PageContainer>
    );
  }

  // Skip checking h2hLoading because we'll handle that at the component level
  
  if (!match && !matchLoading) {
    return (
      <PageContainer showBack title="Match Details">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Match not found</p>
          <p className="text-muted-foreground">
            The match you're looking for doesn't exist or has been removed.
          </p>
        </div>
      </PageContainer>
    );
  }
  
  // Ensure we have match data before proceeding
  if (!match) {
    console.error('Unexpected state: No match data but not in loading state');
    return (
      <PageContainer showBack title="Match Details">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Something went wrong</p>
          <p className="text-muted-foreground">
            An error occurred while loading match data. Please try again.
          </p>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer showBack title="Match Details" noPadding>
      {/* Match Header */}
      <MatchHeader match={match} />

      {/* Match Navigation */}
      <MatchNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Tab Content */}
      <div className="px-4 py-3">
        {activeTab === "overview" && (
          <div>
            {/* Team Actions */}
            <div className="flex justify-between mb-4">
              <TeamFollowButton
                teamId={match.match_hometeam_id}
                teamName={match.match_hometeam_name}
                teamLogo={match.team_home_badge}
                size="sm"
              />
              <TeamFollowButton
                teamId={match.match_awayteam_id}
                teamName={match.match_awayteam_name}
                teamLogo={match.team_away_badge}
                size="sm"
              />
            </div>

            {/* Scorers Section */}
            {match.goalscorer && match.goalscorer.length > 0 && (
              <Card className="mb-4">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    Goal Scorers
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {match.goalscorer.map((goal, index) => (
                      <div key={index} className="flex items-center">
                        {goal.home_scorer && (
                          <div className="w-8 h-8 flex-shrink-0">
                            <img
                              src={match.team_home_badge}
                              alt={match.match_hometeam_name}
                              className="w-6 h-6 object-contain"
                            />
                          </div>
                        )}
                        {goal.home_scorer && (
                          <div className="flex-grow">
                            <div className="flex items-center">
                              <span className="text-sm">
                                {goal.home_scorer}
                              </span>
                              <span className="text-xs text-muted-foreground ml-2">
                                {goal.time}'
                              </span>
                              <svg
                                className="ml-auto text-primary h-4 w-4"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 512 512"
                                fill="currentColor"
                              >
                                <path d="M417.3 360.1l-71.6-4.8c-5.2-.3-10.3 1.1-14.5 4.2s-7.2 7.4-8.4 12.5l-17.6 69.6C289.5 445.8 273 448 256 448s-33.5-2.2-49.2-6.4L189.2 372c-1.3-5-4.3-9.4-8.4-12.5s-9.3-4.5-14.5-4.2l-71.6 4.8c-17.6-27.2-28.5-59.2-30.4-93.6L125 218.6c4.4-2.8 7.6-7 9.2-11.9s1.4-10.2-.5-15l-26.7-66.6C128 109.2 151.7 96 178.3 96h14.6c6.4 0 12.3-3.2 15.8-8.5s4.2-12 1.6-17.7l-14.6-32.7C205.9 34.5 216 33 226.3 32h0 0 59.4 0 0c10.3 1 20.4 2.5 30.1 5.1L301.2 69.8c-2.6 5.7-1.9 12.4 1.6 17.7s9.4 8.5 15.8 8.5h14.6c26.7 0 50.3 13.2 65.1 33.6l-26.7 66.6c-1.9 4.8-2 10.1-.5 15s4.8 9.1 9.2 11.9l60.8 39c-1.9 34.4-12.8 66.4-30.4 93.6zM256 512c141.4 0 256-114.6 256-256S397.4 0 256 0S0 114.6 0 256S114.6 512 256 512zm14.1-325.7c-8.4-6.1-19.8-6.1-28.2 0L194 221c-8.4 6.1-11.9 16.9-8.7 26.8l18.3 56.3c3.2 9.9 12.4 16.6 22.8 16.6h59.2c10.4 0 19.6-6.7 22.8-16.6l18.3-56.3c3.2-9.9-.3-20.7-8.7-26.8l-47.9-34.8z" />
                              </svg>
                            </div>
                            {goal.home_assist && (
                              <div className="text-xs text-muted-foreground">
                                Assist: {goal.home_assist}
                              </div>
                            )}
                          </div>
                        )}
                        {goal.away_scorer && (
                          <div className="flex-grow">
                            <div className="flex items-center">
                              <svg
                                className="mr-auto text-destructive h-4 w-4"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 512 512"
                                fill="currentColor"
                              >
                                <path d="M417.3 360.1l-71.6-4.8c-5.2-.3-10.3 1.1-14.5 4.2s-7.2 7.4-8.4 12.5l-17.6 69.6C289.5 445.8 273 448 256 448s-33.5-2.2-49.2-6.4L189.2 372c-1.3-5-4.3-9.4-8.4-12.5s-9.3-4.5-14.5-4.2l-71.6 4.8c-17.6-27.2-28.5-59.2-30.4-93.6L125 218.6c4.4-2.8 7.6-7 9.2-11.9s1.4-10.2-.5-15l-26.7-66.6C128 109.2 151.7 96 178.3 96h14.6c6.4 0 12.3-3.2 15.8-8.5s4.2-12 1.6-17.7l-14.6-32.7C205.9 34.5 216 33 226.3 32h0 0 59.4 0 0c10.3 1 20.4 2.5 30.1 5.1L301.2 69.8c-2.6 5.7-1.9 12.4 1.6 17.7s9.4 8.5 15.8 8.5h14.6c26.7 0 50.3 13.2 65.1 33.6l-26.7 66.6c-1.9 4.8-2 10.1-.5 15s4.8 9.1 9.2 11.9l60.8 39c-1.9 34.4-12.8 66.4-30.4 93.6zM256 512c141.4 0 256-114.6 256-256S397.4 0 256 0S0 114.6 0 256S114.6 512 256 512zm14.1-325.7c-8.4-6.1-19.8-6.1-28.2 0L194 221c-8.4 6.1-11.9 16.9-8.7 26.8l18.3 56.3c3.2 9.9 12.4 16.6 22.8 16.6h59.2c10.4 0 19.6-6.7 22.8-16.6l18.3-56.3c3.2-9.9-.3-20.7-8.7-26.8l-47.9-34.8z" />
                              </svg>
                              <span className="text-sm">
                                {goal.away_scorer}
                              </span>
                              <span className="text-xs text-muted-foreground ml-2">
                                {goal.time}'
                              </span>
                            </div>
                            {goal.away_assist && (
                              <div className="text-xs text-muted-foreground text-right">
                                Assist: {goal.away_assist}
                              </div>
                            )}
                          </div>
                        )}
                        {goal.away_scorer && (
                          <div className="w-8 h-8 flex-shrink-0 flex justify-end">
                            <img
                              src={match.team_away_badge}
                              alt={match.match_awayteam_name}
                              className="w-6 h-6 object-contain"
                            />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Match Stats Preview */}
            {match.statistics && match.statistics.length > 0 && (
              <Card className="mb-4">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    Match Stats
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {match.statistics.map((stat, index) => {
                    // Only show important stats in overview
                    if (
                      stat.type === "Possession %" ||
                      stat.type === "Total shots" ||
                      stat.type === "Shots on goal" ||
                      stat.type === "Fouls"
                    ) {
                      return (
                        <MatchStatBar
                          key={index}
                          homeStat={stat.home}
                          awayStat={stat.away}
                          label={stat.type}
                          invert={stat.type === "Fouls"}
                        />
                      );
                    }
                    return null;
                  })}

                  <div className="mt-3 text-center">
                    <button
                      className="text-primary text-sm font-medium"
                      onClick={() => setActiveTab("stats")}
                    >
                      View Full Stats
                    </button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Timeline Preview */}
            <Card>
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium">
                  Key Events
                </CardTitle>
                <button
                  className="text-primary text-sm font-medium"
                  onClick={() => setActiveTab("timeline")}
                >
                  View All
                </button>
              </CardHeader>
              <CardContent>
                <MatchTimeline match={match} />
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "timeline" && (
          <Card>
            <CardHeader>
              <CardTitle>Match Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <MatchTimeline match={match} />
            </CardContent>
          </Card>
        )}

        {activeTab === "lineup" && <Lineup match={match} />}

        {activeTab === "stats" && (
          <div>
            {/* Match Momentum Chart */}
            {match.statistics && (
              <Card className="mb-4">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="w-5 h-5 mr-2" />
                    Match Momentum
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <MatchMomentumGraph
                    homeTeam={match.match_hometeam_name}
                    awayTeam={match.match_awayteam_name}
                    homeAttacks={getProgressiveAttacks(match, "home")}
                    awayAttacks={getProgressiveAttacks(match, "away")}
                  />
                  <p className="text-xs text-center mt-2 text-muted-foreground">
                    Team attack intensity over match duration
                  </p>
                </CardContent>
              </Card>
            )}
            
            <Card className="mb-4">
              <CardHeader>
                <CardTitle>Key Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                {match.statistics && match.statistics.length > 0 ? (
                  <div>
                    {/* Key stats as modern ring charts */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-6 mb-8">
                      {/* Possession */}
                      {(() => {
                        const possessionStat = match.statistics.find(stat => stat.type === "Possession %");
                        if (possessionStat) {
                          return (
                            <StatRing
                              homeStat={possessionStat.home || "0"}
                              awayStat={possessionStat.away || "0"}
                              homeTeam={match.match_hometeam_name}
                              awayTeam={match.match_awayteam_name}
                              label="Possession"
                              icon={<Zap className="w-5 h-5" />}
                            />
                          );
                        }
                        return null;
                      })()}

                      {/* Passes */}
                      {(() => {
                        const passesStat = match.statistics.find(stat => stat.type === "Total passes");
                        if (passesStat) {
                          return (
                            <StatRing
                              homeStat={passesStat.home || "0"}
                              awayStat={passesStat.away || "0"}
                              homeTeam={match.match_hometeam_name}
                              awayTeam={match.match_awayteam_name}
                              label="Passes"
                            />
                          );
                        }
                        return null;
                      })()}
                        
                      {/* Shots */}
                      {(() => {
                        const shotsStat = match.statistics.find(stat => stat.type === "Total shots");
                        if (shotsStat) {
                          return (
                            <StatRing
                              homeStat={shotsStat.home || "0"}
                              awayStat={shotsStat.away || "0"}
                              homeTeam={match.match_hometeam_name}
                              awayTeam={match.match_awayteam_name}
                              label="Shots"
                              icon={<Target className="w-5 h-5" />}
                            />
                          );
                        }
                        return null;
                      })()}
                    </div>

                    {/* Advanced statistics with racing bars */}
                    <div className="mb-8">
                      <h3 className="font-medium mb-4 text-lg">Attacks</h3>
                      
                      {/* Attack statistics */}
                      {match.statistics && match.statistics.length > 0 && (
                        <>
                          {match.statistics.filter(stat => 
                            ["Shots on goal", "Shots off goal", "Blocked shots"].includes(stat.type)
                          ).map(stat => (
                            <StatBarAdvanced
                              key={stat.type}
                              homeStat={stat.home || "0"}
                              awayStat={stat.away || "0"}
                              homeTeam={match.match_hometeam_name}
                              awayTeam={match.match_awayteam_name}
                              label={stat.type}
                            />
                          ))}
                        </>
                      )}
                    </div>

                    <Separator className="my-6" />

                    <div className="mb-8">
                      <h3 className="font-medium mb-4 text-lg">Discipline</h3>
                      {/* Discipline statistics */}
                      {match.statistics && match.statistics.length > 0 && (
                        <>
                          {match.statistics.filter(stat => 
                            ["Fouls", "Yellow cards", "Red cards", "Offsides"].includes(stat.type)
                          ).map(stat => (
                            <StatBarAdvanced
                              key={stat.type}
                              homeStat={stat.home || "0"}
                              awayStat={stat.away || "0"}
                              homeTeam={match.match_hometeam_name}
                              awayTeam={match.match_awayteam_name}
                              label={stat.type}
                              invert={true}
                            />
                          ))}
                        </>
                      )}
                    </div>

                    <Separator className="my-6" />

                    <div>
                      <h3 className="font-medium mb-4 text-lg">Set Pieces</h3>
                      {/* Set piece statistics */}
                      {match.statistics && match.statistics.length > 0 && (
                        <>
                          {match.statistics.filter(stat => 
                            ["Corner kicks", "Free kicks"].includes(stat.type)
                          ).map(stat => (
                            <StatBarAdvanced
                              key={stat.type}
                              homeStat={stat.home || "0"}
                              awayStat={stat.away || "0"}
                              homeTeam={match.match_hometeam_name}
                              awayTeam={match.match_awayteam_name}
                              label={stat.type}
                            />
                          ))}
                        </>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <p className="text-muted-foreground">
                      No statistics available for this match.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Half-time stats if available */}
            {match.statistics_1half && match.statistics_1half.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>First Half Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Important statistics for first half */}
                  {match.statistics_1half
                    .filter(stat => [
                      "Possession %",
                      "Total shots",
                      "Shots on goal",
                      "Fouls",
                      "Yellow cards",
                      "Corner kicks"
                    ].includes(stat.type))
                    .map((stat, index) => (
                      <MatchStatBar
                        key={index}
                        homeStat={stat.home || "0"}
                        awayStat={stat.away || "0"}
                        label={stat.type}
                        invert={
                          stat.type === "Fouls" ||
                          stat.type === "Yellow cards" ||
                          stat.type === "Red cards"
                        }
                      />
                    ))
                  }
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {activeTab === "standings" && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5" /> League Standings
              </CardTitle>
            </CardHeader>
            <CardContent>
              {standingsLoading ? (
                <div className="h-40 flex items-center justify-center">
                  <LoadingSpinner text="Loading standings..." />
                </div>
              ) : standingsData && standingsData.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left font-medium py-2 pl-2">#</th>
                        <th className="text-left font-medium py-2">Team</th>
                        <th className="text-center font-medium py-2">P</th>
                        <th className="text-center font-medium py-2">W</th>
                        <th className="text-center font-medium py-2">D</th>
                        <th className="text-center font-medium py-2">L</th>
                        <th className="text-center font-medium py-2">GD</th>
                        <th className="text-center font-medium py-2 pr-2">
                          PTS
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Gunakan Set untuk mencegah duplikasi tim */}
                      {Array.from(new Set(standingsData.map(team => team.team_id)))
                        .map(uniqueId => standingsData.find(team => team.team_id === uniqueId))
                        .filter(Boolean)
                        .map((team) => {
                          const isHomeTeam = team?.team_id === match.match_hometeam_id;
                          const isAwayTeam = team?.team_id === match.match_awayteam_id;
                          const isHighlighted = isHomeTeam || isAwayTeam;

                          return team ? (
                            <tr
                              key={team.team_id}
                              className={
                                isHighlighted
                                  ? "bg-primary/10 font-medium"
                                  : "hover:bg-secondary/50 cursor-pointer"
                              }
                              onClick={() => setLocation(`/team/${team.team_id}`)}
                            >
                              <td className="py-2 pl-2">
                                {team.overall_league_position}
                              </td>
                              <td className="py-2 flex items-center space-x-2">
                                {team.team_badge && (
                                  <img 
                                    src={team.team_badge} 
                                    alt={team.team_name} 
                                    className="w-5 h-5 object-contain"
                                    loading="lazy"
                                  />
                                )}
                                <span className="hover:text-primary transition-colors">{team.team_name}</span>
                              </td>
                              <td className="text-center py-2">
                                {team.overall_league_payed}
                              </td>
                              <td className="text-center py-2">
                                {team.overall_league_W}
                              </td>
                              <td className="text-center py-2">
                                {team.overall_league_D}
                              </td>
                              <td className="text-center py-2">
                                {team.overall_league_L}
                              </td>
                              <td className="text-center py-2">
                                {parseInt(team.overall_league_GF || "0") -
                                  parseInt(team.overall_league_GA || "0")}
                              </td>
                              <td className="text-center py-2 pr-2 font-semibold">
                                {team.overall_league_PTS}
                              </td>
                            </tr>
                          ) : null;
                        })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">
                    No standings available for this league.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {activeTab === "h2h" && <H2HSection match={match} />}

        {/* End of active tab sections */}
      </div>
    </PageContainer>
  );
}
