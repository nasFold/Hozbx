import { useEffect } from 'react';
import { Link } from 'wouter';
import { SEOHead } from '@/components/SEOHead';
import { ROUTES } from '@/lib/router';

export default function NotFound() {
  // Update document title when component mounts
  useEffect(() => {
    document.title = 'Page Not Found | Sibola';
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-5 text-center">
      <SEOHead 
        title="Page Not Found | Sibola"
        description="The page you are looking for does not exist or has been moved."
        noIndex={true}
      />
      
      <div className="space-y-6 max-w-md">
        <h1 className="text-4xl font-bold">404</h1>
        <h2 className="text-2xl font-semibold">Halaman Tidak Ditemukan</h2>
        
        <p className="text-muted-foreground">
          Maaf, halaman yang Anda cari tidak ditemukan atau telah dipindahkan.
        </p>
        
        <div className="pt-4">
          <Link href={ROUTES.HOME.path}>
            <button className="inline-flex items-center justify-center rounded-md bg-primary px-6 py-3 text-primary-foreground transition-colors hover:bg-primary/90">
              Kembali ke Beranda
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}