import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { API, getRelativeTime } from '@/lib/api';
import { News } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Share2, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NewsDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [, setLocation] = useLocation();
  
  // Fetch news article
  const { data: news, isLoading } = useQuery<News>({
    queryKey: [API.news.detail(slug)],
    enabled: !!slug,
  });
  
  const handleTagClick = (tag: string) => {
    setLocation(`/news?tag=${tag}`);
  };
  
  const handleShareClick = () => {
    if (navigator.share) {
      navigator.share({
        title: news?.title,
        text: news?.title,
        url: window.location.href,
      }).catch(error => console.log('Error sharing', error));
    } else {
      // Fallback
      navigator.clipboard.writeText(window.location.href)
        .then(() => {
          alert('Link copied to clipboard!');
        })
        .catch(err => {
          console.error('Failed to copy link: ', err);
        });
    }
  };
  
  if (!slug) {
    return (
      <PageContainer showBack title="News Article">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Invalid Article</p>
          <p className="text-muted-foreground">No article slug was provided.</p>
        </div>
      </PageContainer>
    );
  }
  
  if (isLoading) {
    return (
      <PageContainer showBack title="News Article">
        <div className="h-60 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading article..." />
        </div>
      </PageContainer>
    );
  }
  
  if (!news) {
    return (
      <PageContainer showBack title="News Article">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Article not found</p>
          <p className="text-muted-foreground">The article you're looking for doesn't exist or has been removed.</p>
        </div>
      </PageContainer>
    );
  }
  
  return (
    <PageContainer showBack title="News Article" noPadding>
      {/* Featured Image */}
      <div className="w-full h-64 relative">
        <img 
          src={news.image} 
          alt={news.title} 
          className="w-full h-full object-cover"
          onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/1200x600/121F3D/FFFFFF?text=News' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        
        {/* Tags */}
        <div className="absolute bottom-4 left-4 flex flex-wrap gap-2">
          {news.tags.map(tag => (
            <Badge 
              key={tag}
              className="cursor-pointer bg-primary"
              onClick={() => handleTagClick(tag)}
            >
              {tag}
            </Badge>
          ))}
        </div>
        
        {/* Share button */}
        <Button 
          variant="ghost" 
          size="icon"
          className="absolute top-4 right-4 bg-black/30 text-white hover:bg-black/50 rounded-full"
          onClick={handleShareClick}
        >
          <Share2 className="h-5 w-5" />
        </Button>
      </div>
      
      {/* Article content */}
      <div className="p-4">
        <h1 className="text-2xl font-bold mt-2 mb-3">{news.title}</h1>
        
        <div className="flex justify-between items-center mb-6 text-sm text-muted-foreground">
          <span>{getRelativeTime(news.publishedAt)}</span>
        </div>
        
        <Card>
          <CardContent className="p-6">
            <div 
              className="prose prose-sm dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: news.content }}
            ></div>
          </CardContent>
        </Card>
        
        {/* Related tags section */}
        <div className="mt-8">
          <div className="flex items-center mb-3">
            <Tag className="w-4 h-4 mr-2 text-muted-foreground" />
            <h3 className="text-sm font-medium">Related Topics</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {news.tags.map(tag => (
              <Badge 
                key={tag}
                variant="secondary"
                className="cursor-pointer"
                onClick={() => handleTagClick(tag)}
              >
                {tag}
              </Badge>
            ))}
          </div>
        </div>
        
        {/* Back to news button */}
        <div className="mt-8 mb-4">
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => setLocation('/news')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to News
          </Button>
        </div>
      </div>
    </PageContainer>
  );
}
