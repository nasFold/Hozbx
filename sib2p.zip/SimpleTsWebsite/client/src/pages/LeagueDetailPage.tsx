import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams } from 'wouter';
import { API, formatDateForAPI, getUserTimezone, getHistoricalStartDate, getFutureEndDate, sortMatches, getCurrentSeasonDateRange, getCurrentSeasonName } from '@/lib/api';
import { League, TeamStanding, Match, TopScorer, Team } from '@/lib/types';
import PageContainer from '@/components/PageContainer';
import MatchCard from '@/components/MatchCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import TeamBadge from '@/components/TeamBadge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function LeagueDetailPage() {
  const { id } = useParams<{ id: string }>();
  const timezone = getUserTimezone();
  const today = formatDateForAPI(new Date());
  const [matchFilter, setMatchFilter] = useState<'all' | 'upcoming' | 'live' | 'finished'>('all');

  // Fetch league data
  const { data: leagues } = useQuery<League[]>({
    queryKey: [API.football.leagues, { league_id: id }],
    enabled: !!id,
  });

  // Get league data if available
  const league = leagues?.find(l => l.league_id === id);

  // Fetch standings
  const { data: standingsData, isLoading: standingsLoading } = useQuery<TeamStanding[]>({
    queryKey: [API.football.standings, { league_id: id }],
    queryFn: async () => {
      const response = await fetch(`${API.football.standings}?league_id=${id}`);
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      return response.json();
    },
    enabled: !!id
  });
  
  // Menghilangkan duplikasi dengan memfilter data standings
  const standings = useMemo(() => {
    if (!standingsData) return [];
    
    // Menciptakan map untuk menyimpan tim unik berdasarkan team_id
    const uniqueTeams = new Map();
    
    standingsData.forEach(team => {
      // Jika team_id belum ada di map atau posisi tim ini lebih baik, simpan tim ini
      if (!uniqueTeams.has(team.team_id) || 
          parseInt(team.overall_league_position) < parseInt(uniqueTeams.get(team.team_id).overall_league_position)) {
        uniqueTeams.set(team.team_id, team);
      }
    });
    
    // Ubah map kembali ke array dan urutkan berdasarkan posisi
    return Array.from(uniqueTeams.values()).sort((a, b) => 
      parseInt(a.overall_league_position) - parseInt(b.overall_league_position)
    );
  }, [standingsData]);

  // Dapatkan rentang tanggal untuk data matches season saat ini
  const { start: currentSeasonStart, end: currentSeasonEnd } = getCurrentSeasonDateRange();
  const currentSeasonName = getCurrentSeasonName();

  // Log informasi rentang waktu
  console.log(`Fetching current season (${currentSeasonName}) match data from ${currentSeasonStart} to ${currentSeasonEnd}`);

  // Fetch all matches for this league khusus untuk season saat ini
  const { data: allMatches, isLoading: allMatchesLoading } = useQuery<Match[]>({
    queryKey: [API.football.events, { 
      league_id: id, 
      from: currentSeasonStart,
      to: currentSeasonEnd,
      timezone
    }],
    queryFn: async () => {
      // Buat URL dengan parameter yang spesifik seperti contoh PHP
      const url = `${API.football.events}?league_id=${id}&from=${currentSeasonStart}&to=${currentSeasonEnd}&timezone=${encodeURIComponent(timezone)}`;
      console.log('Fetching matches with URL:', url);

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }

      const data = await response.json();
      console.log(`Fetched ${data?.length || 0} matches for league ${id}`, data);
      return data;
    },
    enabled: !!id
  });

  // Determine which matches to display based on current filter
  const filteredMatches = useMemo(() => {
    if (!allMatches) return [];

    // Data dari API harusnya sudah difilter berdasarkan league_id
    // Pastikan data valid dan tidak ada invalid date
    const leagueMatches = allMatches.filter(match => {
      // Always include the match regardless of date validity
      // We'll handle the proper date display in the MatchCard component
      return true;
    });

    console.log(`Filtering ${leagueMatches.length} valid matches for league ${id} with filter: ${matchFilter}`);

    // Tanggal saat ini untuk menentukan match yang upcoming vs finished
    const now = new Date();

    switch (matchFilter) {
      case 'all':
        // Use the global sortMatches function to ensure consistent sorting
        return sortMatches(leagueMatches);

      case 'upcoming':
        // Filter for upcoming matches and use the sortMatches for consistent sorting
        const upcomingMatches = leagueMatches.filter(match => {
          try {
            // Parse match date and time
            const matchDateTime = new Date(match.match_date + 'T' + match.match_time);
            // Filter upcoming matches (date in the future and not finished)
            return matchDateTime > now && match.match_status !== 'Finished' && match.match_live !== '1';
          } catch (e) {
            return false;
          }
        });
        // Sort upcoming matches by time (closest first)
        return sortMatches(upcomingMatches);

      case 'live':
        // Sort live matches by match time
        return sortMatches(leagueMatches.filter(match => match.match_live === '1'));

      case 'finished':
        // Filter for finished matches
        const finishedMatches = leagueMatches.filter(match => {
          return match.match_status === 'Finished' || 
                 (new Date(match.match_date + 'T' + match.match_time) < now && match.match_live !== '1');
        });
        // Sort finished matches (most recent first)
        return sortMatches(finishedMatches);

      default:
        return leagueMatches;
    }
  }, [matchFilter, allMatches, id]);

  // Determine loading state
  const matchesLoading = allMatchesLoading;

  // Fetch top scorers
  const { data: topScorers, isLoading: topScorersLoading } = useQuery<TopScorer[]>({
    queryKey: [API.football.topscorers, { league_id: id }],
    queryFn: async () => {
      const url = `${API.football.topscorers}?league_id=${id}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      
      return response.json();
    },
    enabled: !!id
  });

  // Fetch teams
  const { data: teams, isLoading: teamsLoading } = useQuery<Team[]>({
    queryKey: [API.football.teams, { league_id: id }],
    queryFn: async () => {
      const url = `${API.football.teams}?league_id=${id}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }
      
      return response.json();
    },
    enabled: !!id
  });

  // Group matches by month and year
  const groupMatchesByMonth = (matches: Match[]) => {
    const grouped: { [key: string]: Match[] } = {};
    const userTimezone = getUserTimezone();

    matches.forEach(match => {
      if (!match.match_date) return;

      try {
        // Create date with time for proper timezone handling
        const dateTimeString = `${match.match_date}T${match.match_time || '00:00'}:00`;
        const date = new Date(dateTimeString);

        // Format month/year in user's timezone
        const monthYear = new Intl.DateTimeFormat(undefined, {
          month: 'long',
          year: 'numeric',
          timeZone: userTimezone
        }).format(date);

        if (!grouped[monthYear]) {
          grouped[monthYear] = [];
        }

        grouped[monthYear].push(match);
      } catch (error) {
        console.error('Error parsing date:', match.match_date, error);
      }
    });

    return grouped;
  };


  if (!id) {
    return (
      <PageContainer showBack title="League Details">
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="text-lg font-semibold mb-2">Invalid League</p>
          <p className="text-muted-foreground">No league ID was provided.</p>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer showBack title={league?.league_name || "League"}>
      {/* League Header */}
      <div className="bg-card rounded-lg p-4 mb-6 shadow flex items-center">
        <div className="w-16 h-16 flex items-center justify-center mr-4">
          <img 
            src={league?.league_logo}
            alt={league?.league_name}
            className="w-14 h-14 object-contain"
            onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/56/121F3D/FFFFFF?text=L' }}
          />
        </div>
        <div>
          <h1 className="text-xl font-bold">{league?.league_name}</h1>
          <div className="flex items-center text-sm text-muted-foreground">
            <img 
              src={league?.country_logo}
              alt={league?.country_name}
              className="w-4 h-4 object-contain mr-2"
            />
            {league?.country_name} • {league?.league_season}
          </div>
        </div>
      </div>

      {/* League Content Tabs */}
      <Tabs defaultValue="standings" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="standings">Standings</TabsTrigger>
          <TabsTrigger value="matches">Matches</TabsTrigger>
          <TabsTrigger value="scorers">Top Scorers</TabsTrigger>
          <TabsTrigger value="teams">Teams</TabsTrigger>
        </TabsList>

        {/* Standings Tab */}
        <TabsContent value="standings">
          {standingsLoading ? (
            <div className="h-60 flex items-center justify-center">
              <LoadingSpinner text="Loading standings..." />
            </div>
          ) : standings && standings.length > 0 ? (
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left font-medium py-3 pl-4">#</th>
                        <th className="text-left font-medium py-3">Team</th>
                        <th className="text-center font-medium py-3">P</th>
                        <th className="text-center font-medium py-3">W</th>
                        <th className="text-center font-medium py-3">D</th>
                        <th className="text-center font-medium py-3">L</th>
                        <th className="text-center font-medium py-3">GD</th>
                        <th className="text-center font-medium py-3 pr-4">PTS</th>
                      </tr>
                    </thead>
                    <tbody>
                      {standings.map((team) => {
                        // Calculate goal difference
                        const goalDiff = parseInt(team.overall_league_GF) - parseInt(team.overall_league_GA);
                        const goalDiffStr = goalDiff > 0 ? `+${goalDiff}` : goalDiff.toString();

                        // Determine promotion or relegation status color
                        let statusClass = "";
                        if (team.overall_promotion && team.overall_promotion.includes("Champions League")) {
                          statusClass = "border-l-4 border-blue-500";
                        } else if (team.overall_promotion && team.overall_promotion.includes("Europa League")) {
                          statusClass = "border-l-4 border-orange-500";
                        } else if (team.overall_promotion && team.overall_promotion.includes("Relegation")) {
                          statusClass = "border-l-4 border-red-500";
                        }

                        // Construct team badge URL (standard pattern based on team_id)
                        const teamBadgeUrl = `https://apiv3.apifootball.com/badges/${team.team_id}_${team.team_name.toLowerCase().replace(/\s+/g, '-')}.jpg`;

                        return (
                          <tr 
                            key={team.team_id} 
                            className={`hover:bg-secondary/50 cursor-pointer ${statusClass}`}
                            onClick={() => window.location.assign(`/team/${team.team_id}`)}
                          >
                            <td className="py-3 pl-4">{team.overall_league_position}</td>
                            <td className="py-3">
                              <div className="flex items-center">
                                <TeamBadge 
                                  teamId={team.team_id}
                                  teamName={team.team_name}
                                  teamLogo={team.team_badge}
                                  size="sm"
                                  className="mr-2"
                                />
                                <span className="truncate">{team.team_name}</span>
                              </div>
                            </td>
                            <td className="text-center py-3">{team.overall_league_payed}</td>
                            <td className="text-center py-3">{team.overall_league_W}</td>
                            <td className="text-center py-3">{team.overall_league_D}</td>
                            <td className="text-center py-3">{team.overall_league_L}</td>
                            <td className="text-center py-3">{goalDiffStr}</td>
                            <td className="text-center py-3 pr-4 font-semibold">
                              {team.overall_league_PTS}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="bg-card rounded-lg p-6 text-center">
              <p className="text-muted-foreground">No standings available for this league.</p>
            </div>
          )}
        </TabsContent>

        {/* Matches Tab */}
        <TabsContent value="matches">
          <Card className="mb-4">
            <CardContent className="p-2">
              <div className="flex flex-wrap justify-start space-x-2">
                <button 
                  className={`px-3 py-1.5 rounded-full text-sm font-medium ${matchFilter === 'all' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
                  onClick={() => setMatchFilter('all')}
                >
                  All
                </button>
                <button 
                  className={`px-3 py-1.5 rounded-full text-sm font-medium ${matchFilter === 'upcoming' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
                  onClick={() => setMatchFilter('upcoming')}
                >
                  Upcoming
                </button>
                <button 
                  className={`px-3 py-1.5 rounded-full text-sm font-medium ${matchFilter === 'live' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
                  onClick={() => setMatchFilter('live')}
                >
                  <span className="flex items-center">
                    {matchFilter === 'live' && (
                      <span className="w-2 h-2 bg-red-500 rounded-full mr-1.5 animate-pulse"></span>
                    )}
                    Live
                  </span>
                </button>
                <button 
                  className={`px-3 py-1.5 rounded-full text-sm font-medium ${matchFilter === 'finished' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
                  onClick={() => setMatchFilter('finished')}
                >
                  Finished
                </button>
              </div>
            </CardContent>
          </Card>

          {matchesLoading ? (
            <div className="h-60 flex items-center justify-center">
              <LoadingSpinner text="Loading matches..." />
            </div>
          ) : filteredMatches && filteredMatches.length > 0 ? (
            <div>
              {matchFilter !== 'all' ? (
                // Tampilkan matches tanpa grouping untuk filter selain 'all'
                <div className="space-y-3">
                  {filteredMatches.map((match) => (
                    <MatchCard key={match.match_id} match={match} compact />
                  ))}
                </div>
              ) : (
                // Tampilkan hanya matches dari season saat ini untuk filter 'all'
                (() => {
                  const currentSeasonName = getCurrentSeasonName();
                  const currentDate = new Date();

                  const groupedByMonth = groupMatchesByMonth(filteredMatches);

                  // Urutkan bulan berdasarkan urutan kronologis, dari bulan yang paling dekat dengan bulan saat ini
                  const getMonthYearTimestamp = (monthYearString: string): number => {
                    try {
                      // Parse string bulan tahun menjadi tanggal
                      const monthNames = ['januari', 'februari', 'maret', 'april', 'mei', 'juni', 'juli', 'agustus', 'september', 'oktober', 'november', 'desember'];

                      // Split string (contoh: "Mei 2025")
                      const parts = monthYearString.split(' ');
                      if (parts.length === 2) {
                        const monthName = parts[0].toLowerCase();
                        const year = parseInt(parts[1]);
                        const monthIndex = monthNames.indexOf(monthName);

                        if (monthIndex !== -1 && !isNaN(year)) {
                          // Buat tanggal untuk perbandingan (hari selalu 1)
                          return new Date(year, monthIndex, 1).getTime();
                        }
                      }

                      // Jika format tidak dikenali, tempatkan di akhir
                      return Number.MAX_SAFE_INTEGER;
                    } catch (e) {
                      console.warn(`Error parsing month-year string: ${monthYearString}`);
                      return Number.MAX_SAFE_INTEGER;
                    }
                  };

                  // Urutkan bulan berdasarkan waktu (paling dekat dengan bulan saat ini duluan)
                  const currentMonthTimestamp = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getTime();
                  const sortedMonths = Object.keys(groupedByMonth).sort((a, b) => {
                    if (a === 'Unknown') return 1; // Tempatkan 'Unknown' di akhir
                    if (b === 'Unknown') return -1;

                    const timestampA = getMonthYearTimestamp(a);
                    const timestampB = getMonthYearTimestamp(b);

                    // Hitung selisih dengan bulan saat ini
                    const diffA = Math.abs(timestampA - currentMonthTimestamp);
                    const diffB = Math.abs(timestampB - currentMonthTimestamp);

                    // Urutkan berdasarkan kedekatan dengan bulan saat ini
                    return diffA - diffB;
                  });

                  return (
                    <div className="space-y-6">
                      <h2 className="font-bold text-lg mb-3 px-1">Season {currentSeasonName}</h2>
                      {sortedMonths.map(month => (
                        <div key={month}>
                          <h3 className="font-semibold text-md mb-3 px-1">{month}</h3>
                          <div className="space-y-3">
                            {groupedByMonth[month].map(match => (
                              <MatchCard key={match.match_id} match={match} compact />
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()
              )}
            </div>
          ) : (
            <div className="bg-card rounded-lg p-6 text-center">
              <p className="text-muted-foreground">
                {matchFilter === 'all' && `No matches available for ${league?.league_name || 'this league'}.`}
                {matchFilter === 'upcoming' && `No upcoming matches for ${league?.league_name || 'this league'}.`}
                {matchFilter === 'live' && `No live matches currently for ${league?.league_name || 'this league'}.`}
                {matchFilter === 'finished' && `No finished matches for ${league?.league_name || 'this league'}.`}
              </p>
            </div>
          )}
        </TabsContent>

        {/* Top Scorers Tab */}
        <TabsContent value="scorers">
          {topScorersLoading ? (
            <div className="h-60 flex items-center justify-center">
              <LoadingSpinner text="Loading top scorers..." />
            </div>
          ) : topScorers && topScorers.length > 0 ? (
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left font-medium py-3 pl-4">#</th>
                        <th className="text-left font-medium py-3">Player</th>
                        <th className="text-left font-medium py-3">Team</th>
                        <th className="text-center font-medium py-3">Goals</th>
                        <th className="text-center font-medium py-3 pr-4">Assists</th>
                      </tr>
                    </thead>
                    <tbody>
                      {topScorers.map((scorer, index) => (
                        <tr 
                          key={scorer.player_key || index} 
                          className="hover:bg-secondary/50 cursor-pointer"
                          onClick={() => window.location.assign(`/player/${scorer.player_key}`)}
                        >
                          <td className="py-3 pl-4">{scorer.player_place || (index + 1)}</td>
                          <td className="py-3 font-medium">{scorer.player_name}</td>
                          <td className="py-3">{scorer.team_name}</td>
                          <td className="text-center py-3 font-semibold">{scorer.goals}</td>
                          <td className="text-center py-3 pr-4">{scorer.assists || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="bg-card rounded-lg p-6 text-center">
              <p className="text-muted-foreground">No top scorers data available for this league.</p>
            </div>
          )}
        </TabsContent>

        {/* Teams Tab */}
        <TabsContent value="teams">
          {teamsLoading ? (
            <div className="h-60 flex items-center justify-center">
              <LoadingSpinner text="Loading teams..." />
            </div>
          ) : teams && teams.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {teams.map((team, index) => (
                <Card 
                  key={team.team_key || team.team_id || index} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => window.location.assign(`/team/${team.team_key || team.team_id}`)}
                >
                  <CardContent className="p-4 flex flex-col items-center">
                    <div className="w-16 h-16 flex items-center justify-center my-2">
                      <img 
                        src={team.team_badge || team.team_logo}
                        alt={team.team_name}
                        className="max-w-full max-h-full object-contain"
                        onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/64/121F3D/FFFFFF?text=Team' }}
                      />
                    </div>
                    <h3 className="font-medium text-center mt-2">{team.team_name}</h3>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-card rounded-lg p-6 text-center">
              <p className="text-muted-foreground">No teams data available for this league.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}