import { useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { WebSocketProvider } from "@/contexts/WebSocketContext";
import { useEffect } from "react";
import AppRouter from "@/components/AppRouter";

// Prefetch component to preload page data
const Prefetcher = () => {
  const [location] = useLocation();
  
  useEffect(() => {
    // Prefetch related pages based on current location
    if (location === '/') {
      import("@/pages/NewsPage");
      import("@/pages/MatchesPage");
    } else if (location.startsWith('/match/')) {
      import("@/pages/MatchesPage");
      import("@/pages/TeamPage");
    } else if (location.startsWith('/news/')) {
      import("@/pages/NewsPage");
    }
    
    // Scroll to top on page change for better UX
    window.scrollTo(0, 0);
  }, [location]);
  
  return null;
};

export default function App() {
  return (
    <WebSocketProvider>
      <div className="min-h-screen bg-background font-sans antialiased">
        <div className="relative flex min-h-screen flex-col pb-16 md:pb-0">
          <div className="flex-1">
            <Prefetcher />
            <AppRouter />
          </div>
        </div>
        <Toaster />
      </div>
    </WebSocketProvider>
  );
}