import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { 
  connectWebSocket, 
  disconnectWebSocket, 
  addWebSocketListener, 
  removeWebSocketListener,
  subscribeToMatch,
  WebSocketListener
} from '@/lib/websocket';
import { Match } from '@/lib/types';

interface WebSocketContextType {
  liveMatches: Match[];
  isConnected: boolean;
  subscribeToMatch: (matchId: string) => void;
  matchDetails: Record<string, Match>;
  lastUpdated: Date | null;
}

const WebSocketContext = createContext<WebSocketContextType>({
  liveMatches: [],
  isConnected: false,
  subscribeToMatch: () => {},
  matchDetails: {},
  lastUpdated: null
});

export const useWebSocket = () => useContext(WebSocketContext);

export const WebSocketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [liveMatches, setLiveMatches] = useState<Match[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [matchDetails, setMatchDetails] = useState<Record<string, Match>>({});
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Handle WebSocket messages
  const handleMessage: WebSocketListener = useCallback((event) => {
    try {
      const data = JSON.parse(event.data);
      console.log('WebSocket message received:', data.type);
      
      if (data.type === 'matchUpdate') {
        console.log('Updating live matches, count:', data.matches?.length || 0);
        setLiveMatches(data.matches || []);
        setLastUpdated(new Date(data.timestamp));
      } else if (data.type === 'matchDetail' && data.matchId) {
        console.log('Received match details for match ID:', data.matchId, 'Data:', data.data);
        // Pastikan data yang diterima adalah yang terbaru dengan mencatat timestamp
        setMatchDetails(prev => {
          const updatedDetails = {
            ...prev,
            [data.matchId]: Array.isArray(data.data) ? data.data[0] : data.data
          };
          console.log('Updated match details state for ID:', data.matchId);
          return updatedDetails;
        });
      }
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  }, []);

  // Handle WebSocket connection status
  const handleOpen = useCallback(() => {
    setIsConnected(true);
  }, []);

  const handleClose = useCallback(() => {
    setIsConnected(false);
  }, []);

  // Connect to WebSocket on component mount
  useEffect(() => {
    connectWebSocket().catch(console.error);
    
    // Add event listeners
    addWebSocketListener('message', handleMessage);
    addWebSocketListener('open', handleOpen);
    addWebSocketListener('close', handleClose);
    
    // Clean up on component unmount
    return () => {
      removeWebSocketListener('message', handleMessage);
      removeWebSocketListener('open', handleOpen);
      removeWebSocketListener('close', handleClose);
      disconnectWebSocket();
    };
  }, [handleMessage, handleOpen, handleClose]);

  // Subscribe to a specific match
  const handleSubscribeToMatch = useCallback((matchId: string) => {
    subscribeToMatch(matchId);
  }, []);

  const value = {
    liveMatches,
    isConnected,
    subscribeToMatch: handleSubscribeToMatch,
    matchDetails,
    lastUpdated
  };

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  );
};
