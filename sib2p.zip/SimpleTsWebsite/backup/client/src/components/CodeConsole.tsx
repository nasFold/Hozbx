import { useState, useRef, useEffect } from "react";

interface CodeConsoleProps {
  initialOutput?: string[];
}

const CodeConsole = ({ initialOutput = [] }: CodeConsoleProps) => {
  const [output, setOutput] = useState<Array<{ text: string; type: "command" | "result" | "error" }>>(
    initialOutput.map((text) => ({ text, type: "result" }))
  );
  const [command, setCommand] = useState("");
  const consoleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [output]);

  const handleClear = () => {
    setOutput([]);
  };

  const executeCommand = () => {
    if (!command.trim()) return;

    setOutput((prev) => [...prev, { text: `> ${command}`, type: "command" }]);

    try {
      // Simple command processing - in a real app, this would be much more robust
      let result;
      if (command.includes("console.log")) {
        // Extract the content inside console.log()
        const match = command.match(/console\.log\((.*)\)/);
        if (match && match[1]) {
          result = { text: eval(match[1]), type: "result" as const };
        } else {
          result = { text: "undefined", type: "result" as const };
        }
      } else if (command.startsWith("let ") || command.startsWith("const ") || command.startsWith("var ")) {
        // Handle variable declarations
        try {
          eval(command);
          result = { text: "undefined", type: "result" as const };
        } catch (err) {
          result = { text: `${err}`, type: "error" as const };
        }
      } else {
        // For other expressions, try to evaluate
        try {
          const evalResult = eval(command);
          result = {
            text: typeof evalResult === "undefined" ? "undefined" : String(evalResult),
            type: "result" as const,
          };
        } catch (err) {
          result = { text: `${err}`, type: "error" as const };
        }
      }

      setOutput((prev) => [...prev, result]);
    } catch (err) {
      setOutput((prev) => [...prev, { text: `Error: ${err}`, type: "error" }]);
    }

    setCommand("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      executeCommand();
    }
  };

  return (
    <div className="bg-gray-100 p-6 rounded-lg">
      <p className="text-gray-700 mb-4">Use the interactive console to test the concepts:</p>

      <div className="bg-gray-900 p-4 rounded-lg mb-4">
        <div className="flex justify-between items-center mb-4">
          <span className="text-white font-medium">Console</span>
          <button
            onClick={handleClear}
            className="text-gray-400 hover:text-white text-sm"
          >
            Clear
          </button>
        </div>
        <div
          ref={consoleRef}
          className="console-output font-mono text-sm p-2 h-32 overflow-y-auto"
        >
          {output.map((line, index) => (
            <div
              key={index}
              className={
                line.type === "error"
                  ? "text-red-400"
                  : line.type === "result"
                  ? "text-green-400"
                  : ""
              }
            >
              {line.text}
            </div>
          ))}
        </div>
      </div>

      <div className="flex">
        <input
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Try your own code here..."
          className="flex-1 p-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-[#3178c6] focus:border-transparent"
        />
        <button
          onClick={executeCommand}
          className="bg-[#3178c6] text-white px-4 py-2 rounded-r-md hover:bg-[#235a97] transition"
        >
          Run
        </button>
      </div>
    </div>
  );
};

export default CodeConsole;
