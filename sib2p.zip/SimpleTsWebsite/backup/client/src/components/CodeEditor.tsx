import { useState } from "react";
import { highlightCode } from "@/lib/syntax-highlighter";

interface CodeEditorProps {
  title: string;
  code: string;
  language?: string;
  runnable?: boolean;
  onRunCode?: () => void;
}

const CodeEditor = ({
  title,
  code,
  language = "typescript",
  runnable = true,
  onRunCode,
}: CodeEditorProps) => {
  const [copied, setCopied] = useState(false);

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunCode = () => {
    if (onRunCode) {
      onRunCode();
    }
  };

  return (
    <div className="mb-6">
      <div className="code-editor-header">
        <span className="font-medium text-gray-700">{title}</span>
        <div className="flex space-x-2">
          <button
            onClick={copyCode}
            className="text-gray-600 hover:text-gray-800"
            title="Copy code"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
              />
            </svg>
          </button>
        </div>
      </div>
      <div className="code-editor">
        <pre className="leading-relaxed">
          <div dangerouslySetInnerHTML={{ __html: highlightCode(code, language) }} />
        </pre>
      </div>
      {runnable && (
        <div className="code-editor-footer">
          <button
            onClick={handleRunCode}
            className="text-xs bg-[#3178c6] text-white px-3 py-1 rounded hover:bg-[#235a97] transition"
          >
            Run Code
          </button>
          <a
            href="https://www.typescriptlang.org/docs"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-gray-600 hover:text-gray-800"
          >
            See Documentation
          </a>
        </div>
      )}
    </div>
  );
};

export default CodeEditor;
