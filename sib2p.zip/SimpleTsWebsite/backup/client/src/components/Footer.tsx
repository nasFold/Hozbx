import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">TypeScript Learning Platform</h3>
            <p className="text-gray-300 text-sm">
              A comprehensive guide to mastering TypeScript with interactive examples and best practices.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="text-gray-300 text-sm">
              <li className="mb-2"><a href="https://www.typescriptlang.org/docs/" className="hover:text-white">Documentation</a></li>
              <li className="mb-2"><a href="https://www.typescriptlang.org/docs/handbook/intro.html" className="hover:text-white">TypeScript Handbook</a></li>
              <li className="mb-2"><a href="https://www.typescriptlang.org/play" className="hover:text-white">Playground</a></li>
              <li className="mb-2"><a href="https://github.com/microsoft/TypeScript/discussions" className="hover:text-white">Community</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect</h3>
            <ul className="text-gray-300 text-sm">
              <li className="mb-2"><a href="https://github.com/microsoft/TypeScript" className="hover:text-white">GitHub</a></li>
              <li className="mb-2"><a href="https://twitter.com/typescript" className="hover:text-white">Twitter</a></li>
              <li className="mb-2"><a href="https://stackoverflow.com/questions/tagged/typescript" className="hover:text-white">Stack Overflow</a></li>
              <li className="mb-2"><a href="https://discord.gg/typescript" className="hover:text-white">Discord</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-8 text-sm text-gray-400 text-center">
          <p>© {new Date().getFullYear()} TypeScript Learning Platform. This is an educational resource. TypeScript is maintained by Microsoft.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
