import TabNavigation from "@/components/TabNavigation";
import CodeEditor from "@/components/CodeEditor";
import CodeConsole from "@/components/CodeConsole";

const errorBasicsCode = `// Error Handling Basics in TypeScript

// Standard JavaScript try-catch block with typed errors
function divide(a: number, b: number): number {
  if (b === 0) {
    throw new Error("Division by zero is not allowed");
  }
  return a / b;
}

try {
  const result = divide(10, 0);
  console.log(result);
} catch (error) {
  // In TypeScript, error is of type 'unknown' in catch blocks
  if (error instanceof Error) {
    console.error(\`Error message: \${error.message}\`);
  } else {
    console.error("An unexpected error occurred");
  }
}

// Multiple catch blocks (works in JavaScript, but not TypeScript)
// try {
//   // code that might throw different types of errors
// } catch (e if e instanceof TypeError) {
//   // Handle TypeError
// } catch (e if e instanceof RangeError) {
//   // Handle RangeError
// } catch (e) {
//   // Handle other errors
// }

// Instead, use type guards in a single catch block
try {
  // code that might throw
  throw new TypeError("Type error example");
} catch (error) {
  if (error instanceof TypeError) {
    console.error("Type error:", error.message);
  } else if (error instanceof RangeError) {
    console.error("Range error:", error.message);
  } else if (error instanceof Error) {
    console.error("Generic error:", error.message);
  } else {
    console.error("Unknown error:", error);
  }
}`;

const customErrorsCode = `// Custom Error Types

// Creating custom error classes
class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
    
    // This is necessary for proper instanceof checking in TypeScript
    Object.setPrototypeOf(this, ValidationError.prototype);
  }
}

class DatabaseError extends Error {
  code: number;
  
  constructor(message: string, code: number) {
    super(message);
    this.name = "DatabaseError";
    this.code = code;
    
    Object.setPrototypeOf(this, DatabaseError.prototype);
  }
}

// Function that might throw different types of errors
function saveUser(user: { username: string, email: string }): void {
  // Validation checks
  if (!user.username || user.username.length < 3) {
    throw new ValidationError("Username must be at least 3 characters long");
  }
  
  if (!user.email || !user.email.includes("@")) {
    throw new ValidationError("Invalid email format");
  }
  
  // Simulate database operation error
  const connectionFailed = Math.random() > 0.7;
  if (connectionFailed) {
    throw new DatabaseError("Failed to connect to database", 500);
  }
  
  console.log("User saved successfully:", user);
}

// Using the function with error handling
try {
  saveUser({ username: "jo", email: "john@example.com" });
} catch (error) {
  if (error instanceof ValidationError) {
    console.error("Validation failed:", error.message);
  } else if (error instanceof DatabaseError) {
    console.error(\`Database error (\${error.code}): \${error.message}\`);
    // Maybe retry the operation
  } else {
    console.error("Unexpected error:", error);
  }
}`;

const errorHandlingPatternsCode = `// Advanced Error Handling Patterns

// 1. Result type pattern
type Result<T, E = Error> = 
  | { success: true; value: T }
  | { success: false; error: E };

function divide(a: number, b: number): Result<number> {
  if (b === 0) {
    return { 
      success: false, 
      error: new Error("Division by zero") 
    };
  }
  
  return { 
    success: true, 
    value: a / b 
  };
}

// Using the Result type
const result = divide(10, 2);

if (result.success) {
  console.log("Result:", result.value);
} else {
  console.error("Error:", result.error.message);
}

// 2. Either type pattern (similar to Result)
type Either<L, R> = 
  | { tag: "left"; left: L }
  | { tag: "right"; right: R };

// Left typically represents errors, Right represents success
function fetchUserData(id: string): Either<Error, { name: string, email: string }> {
  // Simulating an error for certain IDs
  if (id === "invalid") {
    return { 
      tag: "left", 
      left: new Error("User not found") 
    };
  }
  
  return { 
    tag: "right", 
    right: { 
      name: "John Doe", 
      email: "john@example.com" 
    } 
  };
}

// Using Either type
const userResult = fetchUserData("123");

if (userResult.tag === "right") {
  console.log("User:", userResult.right);
} else {
  console.error("Failed to fetch user:", userResult.left.message);
}

// 3. Option/Maybe pattern (for null/undefined values)
type Option<T> = 
  | { some: true; value: T }
  | { some: false };

function findUser(id: string): Option<{ name: string, email: string }> {
  // Simulate user lookup
  if (id === "123") {
    return { 
      some: true, 
      value: { 
        name: "Jane Smith", 
        email: "jane@example.com" 
      } 
    };
  }
  
  return { some: false };
}

// Using Option type
const userOption = findUser("456");

if (userOption.some) {
  console.log("Found user:", userOption.value);
} else {
  console.log("User not found");
}`;

const nullsAndUndefinedsCode = `// Handling Nulls and Undefined in TypeScript

// 1. Using the non-null assertion operator (!)
// Use with caution - overrides TypeScript's null checks
function printLength(text: string | null) {
  // This tells TypeScript "I know this isn't null"
  console.log(text!.length);
}

// 2. Using type guards
function printLengthSafe(text: string | null | undefined) {
  if (text) {
    // Inside this block, TypeScript knows text is a string
    console.log(text.length);
  } else {
    console.log("Text is null or undefined");
  }
}

// 3. Nullish coalescing operator (??) - default values
function getDisplayName(user: { name?: string }): string {
  // Uses right side only when left is null or undefined
  return user.name ?? "Anonymous";
}

// 4. Optional chaining (?.) - safe property access
function getUserCity(user: {
  address?: {
    city?: string;
  };
}): string | undefined {
  // Returns undefined if any part of the chain is null/undefined
  return user.address?.city;
}

// 5. Using default parameters
function greet(name: string = "Guest"): string {
  return \`Hello, \${name}!\`;
}

// 6. Combining optional chaining and nullish coalescing
function getUserLocation(
  user: {
    address?: {
      city?: string;
      country?: string;
    };
  }
): string {
  return user.address?.city ?? user.address?.country ?? "Unknown location";
}

// 7. Handling nulls in callbacks and method chains
const numbers: (number | null)[] = [1, null, 3, 4, null, 6];

// Remove nulls with type guard
const validNumbers = numbers.filter((num): num is number => num !== null);

// Now we can safely use methods on all items
const sum = validNumbers.reduce((total, num) => total + num, 0);

// 8. Using type assertions for complex cases
function processValue(value: unknown) {
  if (typeof value === "string") {
    // TypeScript knows value is a string here
    return value.toUpperCase();
  } else if (Array.isArray(value)) {
    // TypeScript doesn't know what's in the array
    return (value as string[]).map(item => item.toUpperCase());
  }
  return String(value);
}`;

const asyncErrorsCode = `// Handling Errors in Asynchronous Code

// 1. Traditional Promise catch method
function fetchData(url: string): Promise<any> {
  return fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error(\`HTTP error: \${response.status}\`);
      }
      return response.json();
    })
    .catch(error => {
      console.error("Fetch error:", error);
      throw error; // Rethrow to propagate
    });
}

// Using the function
fetchData("https://api.example.com/data")
  .then(data => {
    console.log("Data:", data);
  })
  .catch(error => {
    console.error("Failed to fetch data:", error);
  });

// 2. Async/await with try-catch
async function fetchUserData(userId: string): Promise<any> {
  try {
    const response = await fetch(\`https://api.example.com/users/\${userId}\`);
    
    if (!response.ok) {
      throw new Error(\`HTTP error: \${response.status}\`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error fetching user data:", error);
    // Optionally rethrow or return a default value
    throw error;
  }
}

// 3. Higher-order function for error handling
function withErrorHandling<T>(
  fn: (...args: any[]) => Promise<T>,
  errorHandler: (error: unknown) => Promise<T>
): (...args: any[]) => Promise<T> {
  return async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      return errorHandler(error);
    }
  };
}

// Usage
const safeFetchUser = withErrorHandling(
  (id: string) => fetchUserData(id),
  async (error) => {
    console.error("Could not fetch user, returning default:", error);
    return { id: "default", name: "Unknown User" };
  }
);

// 4. Using Result type with async functions
interface SuccessResult<T> {
  status: "success";
  data: T;
}

interface ErrorResult {
  status: "error";
  error: Error;
}

type AsyncResult<T> = SuccessResult<T> | ErrorResult;

async function fetchWithResult<T>(url: string): Promise<AsyncResult<T>> {
  try {
    const response = await fetch(url);
    
    if (!response.ok) {
      return {
        status: "error",
        error: new Error(\`HTTP error: \${response.status}\`)
      };
    }
    
    const data = await response.json();
    return {
      status: "success",
      data
    };
  } catch (error) {
    return {
      status: "error",
      error: error instanceof Error 
        ? error 
        : new Error(String(error))
    };
  }
}

// Using the Result pattern
async function displayUserProfile(userId: string): Promise<void> {
  const result = await fetchWithResult<{name: string, email: string}>(
    \`https://api.example.com/users/\${userId}\`
  );
  
  if (result.status === "success") {
    console.log("User profile:", result.data);
  } else {
    console.error("Failed to load profile:", result.error.message);
    // Handle the error appropriately
  }
}`;

const ErrorHandling = () => {
  const consoleOutput = [
    "try {",
    "  throw new Error('Something went wrong');",
    "} catch (error) {",
    "  if (error instanceof Error) {",
    "    console.log(error.message);",
    "  }",
    "}",
    "Something went wrong",
    "type Result<T> = { success: true; data: T } | { success: false; error: string };",
    "function safeDivide(a: number, b: number): Result<number> {",
    "  if (b === 0) return { success: false, error: 'Division by zero' };",
    "  return { success: true, data: a / b };",
    "}",
    "const result = safeDivide(10, 2);",
    "if (result.success) console.log(result.data);",
    "5"
  ];

  return (
    <main className="container mx-auto px-4 py-8">
      <TabNavigation />

      <section className="mb-12">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Error Handling in TypeScript</h2>
        <p className="text-gray-600 mb-6">
          Error handling is critical for building robust applications. TypeScript provides type-safe mechanisms for capturing, propagating, and handling errors.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Basic Error Handling</h3>
            <p className="text-gray-600 mb-4">
              TypeScript uses JavaScript's try-catch mechanism with enhanced type checking:
            </p>
            
            <CodeEditor
              title="error-basics.ts"
              code={errorBasicsCode}
              language="typescript"
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Custom Error Types</h3>
            <p className="text-gray-600 mb-4">
              Create specialized error classes to distinguish between different error conditions:
            </p>
            
            <CodeEditor
              title="custom-errors.ts"
              code={customErrorsCode}
              language="typescript"
              runnable={false}
            />
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Error Handling Patterns</h3>
            <p className="text-gray-600 mb-4">
              TypeScript enables several functional programming patterns for safer error handling:
            </p>
            
            <CodeEditor
              title="error-patterns.ts"
              code={errorHandlingPatternsCode}
              language="typescript"
              runnable={false}
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Try It Yourself</h3>
            <CodeConsole initialOutput={consoleOutput} />
          </div>
        </div>
      </section>

      <section className="mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Handling Nulls and Undefined</h3>
            <p className="text-gray-600 mb-4">
              TypeScript provides several ways to handle null and undefined values safely:
            </p>
            
            <CodeEditor
              title="null-handling.ts"
              code={nullsAndUndefinedsCode}
              language="typescript"
              runnable={false}
            />

            <div className="bg-yellow-50 rounded-lg p-4 border-l-4 border-yellow-400 mt-6">
              <h4 className="font-medium text-yellow-800">Null Safety Best Practices</h4>
              <ul className="text-sm text-yellow-700 list-disc pl-5 mt-2">
                <li>Enable <code>strictNullChecks</code> in your tsconfig.json</li>
                <li>Avoid using the non-null assertion operator (<code>!</code>) when possible</li>
                <li>Use optional chaining (<code>?.</code>) for safe property access</li>
                <li>Provide default values with nullish coalescing (<code>??</code>)</li>
                <li>Always check for null/undefined before accessing properties</li>
              </ul>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Asynchronous Error Handling</h3>
            <p className="text-gray-600 mb-4">
              Handle errors in Promises and async/await code:
            </p>
            
            <CodeEditor
              title="async-errors.ts"
              code={asyncErrorsCode}
              language="typescript"
              runnable={false}
            />
            
            <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-400 mt-6">
              <h4 className="font-medium text-blue-800">Async Error Handling Tips</h4>
              <ul className="text-sm text-blue-700 list-disc pl-5 mt-2">
                <li>Never forget to add <code>catch</code> handlers to promises</li>
                <li>Use <code>try/catch</code> with <code>async/await</code> for cleaner code</li>
                <li>Consider using the Result pattern for predictable error handling</li>
                <li>Create utility functions to standardize error handling across your application</li>
                <li>Log detailed error information for debugging</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Next Steps</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">TypeScript Compiler Options</h3>
            <p className="text-gray-600 text-sm mb-4">Learn about strict type checking options that help catch more errors.</p>
            <a href="https://www.typescriptlang.org/tsconfig" target="_blank" rel="noopener noreferrer" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore TSConfig →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Type Testing</h3>
            <p className="text-gray-600 text-sm mb-4">Explore techniques for testing and validating types at compile time.</p>
            <a href="https://www.typescriptlang.org/docs/handbook/2/types-from-types.html" target="_blank" rel="noopener noreferrer" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Types from Types →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Advanced Types</h3>
            <p className="text-gray-600 text-sm mb-4">Revisit advanced types for creating robust error-handling patterns.</p>
            <a href="/advanced-types" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Advanced Types →</a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default ErrorHandling;
