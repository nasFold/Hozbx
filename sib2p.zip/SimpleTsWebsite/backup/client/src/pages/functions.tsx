import TabNavigation from "@/components/TabNavigation";
import CodeEditor from "@/components/CodeEditor";
import CodeConsole from "@/components/CodeConsole";

const basicFunctionsCode = `// Function declarations with parameter and return types

// Basic function with parameter and return type
function add(a: number, b: number): number {
  return a + b;
}

// Function with optional parameter (?)
function greet(name: string, title?: string): string {
  if (title) {
    return \`Hello, \${title} \${name}!\`;
  }
  return \`Hello, \${name}!\`;
}

// Function with default parameter
function calculateTax(amount: number, taxRate: number = 0.2): number {
  return amount * taxRate;
}

// Function with rest parameters
function sumAll(...numbers: number[]): number {
  return numbers.reduce((total, n) => total + n, 0);
}

// Using the functions
console.log(add(5, 3));                  // 8
console.log(greet("Alice"));             // "Hello, Alice!"
console.log(greet("Bob", "Mr."));        // "Hello, Mr. Bob!"
console.log(calculateTax(100));          // 20
console.log(calculateTax(100, 0.3));     // 30
console.log(sumAll(1, 2, 3, 4, 5));      // 15`;

const functionTypesCode = `// Function types and expressions

// Function type expression
type MathFunction = (x: number, y: number) => number;

// Arrow function with explicit type
const multiply: MathFunction = (a, b) => a * b;

// Function as parameter using inline type
function applyOperation(a: number, b: number, operation: (x: number, y: number) => number): number {
  return operation(a, b);
}

// Using function types as parameters
function applyMathFn(a: number, b: number, operation: MathFunction): number {
  return operation(a, b);
}

// Using the functions
console.log(multiply(4, 5));                     // 20
console.log(applyOperation(10, 5, (a, b) => a / b)); // 2
console.log(applyMathFn(10, 5, multiply));       // 50

// Function interface
interface Calculator {
  (x: number, y: number): number;
  description?: string;
}

// Creating a function with interface properties
const subtract: Calculator = (a, b) => a - b;
subtract.description = "Subtracts second number from first";

console.log(subtract(10, 4));                   // 6
console.log(subtract.description);              // "Subtracts second number from first"`;

const functionOverloadsCode = `// Function overloads

// Overload signatures
function process(value: number): number;
function process(value: string): string;

// Implementation signature - must be compatible with all overloads
function process(value: number | string): number | string {
  if (typeof value === "number") {
    return value * 2;
  } else {
    return value.toUpperCase();
  }
}

// Using the overloaded function
console.log(process(42));       // 84
console.log(process("hello"));  // "HELLO"

// More complex overload example
interface ElementPosition {
  top: number;
  left: number;
  width?: number;
  height?: number;
}

// Overloads with different parameter counts and types
function moveElement(id: string, position: ElementPosition): void;
function moveElement(id: string, top: number, left: number): void;
function moveElement(id: string, topOrPosition: number | ElementPosition, leftOrUndefined?: number): void {
  let top: number;
  let left: number;
  
  if (typeof topOrPosition === "object") {
    // First overload - called with position object
    top = topOrPosition.top;
    left = topOrPosition.left;
  } else {
    // Second overload - called with separate coordinates
    top = topOrPosition;
    left = leftOrUndefined!;
  }
  
  console.log(\`Moving element \${id} to position: (top: \${top}, left: \${left})\`);
  // Implementation would actually move the element
}

// Using the overloaded function
moveElement("box1", { top: 100, left: 200 });
moveElement("box2", 50, 75);`;

const thisInFunctionsCode = `// Working with 'this' in functions

// Interface with 'this' type annotation
interface User {
  id: number;
  name: string;
  email: string;
  greetWithThis(): string;
  updateEmail(this: User, newEmail: string): void;
}

const user: User = {
  id: 1,
  name: "John Doe",
  email: "john@example.com",
  greetWithThis() {
    // 'this' refers to the User object
    return \`Hello, my name is \${this.name}\`;
  },
  updateEmail(this: User, newEmail: string) {
    // Explicit 'this' parameter ensures correct context
    this.email = newEmail;
    console.log(\`Email updated to \${this.email}\`);
  }
};

console.log(user.greetWithThis()); // "Hello, my name is John Doe"
user.updateEmail("john.doe@example.com");

// Function that loses 'this' context
const greet = user.greetWithThis;
// console.log(greet()); // Error: 'this' is undefined

// Explicit 'this' parameter in standalone function
function displayUser(this: User) {
  console.log(\`User: \${this.name}, Email: \${this.email}\`);
}

// Using call or apply to set 'this' context
displayUser.call(user); // "User: John Doe, Email: john.doe@example.com"

// Arrow functions and 'this'
function createCounter() {
  let count = 0;
  
  return {
    count: count,
    increment(this: { count: number }) {
      // Regular function, 'this' depends on call site
      this.count += 1;
      return this.count;
    },
    decrement: function(this: { count: number }) {
      this.count -= 1;
      return this.count;
    },
    reset: () => {
      // Arrow function, 'this' is lexically scoped (from createCounter)
      // count = 0; // This would reference the outer count variable
      // return count;
      
      // But arrow functions can't have 'this' parameters
      // this.count = 0; // Error if this is a typed method
      return "Can't access this.count in arrow function";
    }
  };
}

const counter = createCounter();
console.log(counter.increment()); // 1
console.log(counter.increment()); // 2
console.log(counter.decrement()); // 1
console.log(counter.reset());     // Can't access this.count in arrow function`;

const genericFunctionsCode = `// Generic functions

// Generic function with a single type parameter
function identity<T>(arg: T): T {
  return arg;
}

// Using the generic function with explicit type argument
const num = identity<number>(42);
console.log(num); // 42

// Type inference with generics - compiler determines T is string
const str = identity("hello");
console.log(str); // "hello"

// Generic function with multiple type parameters
function pair<T, U>(first: T, second: U): [T, U] {
  return [first, second];
}

const result = pair<string, number>("key", 123);
console.log(result); // ["key", 123]

// Generic function with constraints
interface Lengthwise {
  length: number;
}

function getLength<T extends Lengthwise>(arg: T): number {
  return arg.length;
}

console.log(getLength("hello"));           // 5
console.log(getLength([1, 2, 3]));         // 3
console.log(getLength({ length: 10 }));    // 10
// console.log(getLength(123)); // Error: number does not have 'length' property

// Generic function with default type parameter
function createPair<T, U = string>(first: T, second: U): [T, U] {
  return [first, second];
}

const pair1 = createPair(42, "hello");  // [number, string]
const pair2 = createPair<number, boolean>(42, true); // [number, boolean]

// Generic function with type inference from arguments
function mergeObjects<T extends object, U extends object>(obj1: T, obj2: U): T & U {
  return { ...obj1, ...obj2 };
}

const merged = mergeObjects(
  { name: "John" },
  { age: 30 }
);

console.log(merged); // { name: "John", age: 30 }
console.log(merged.name); // "John"
console.log(merged.age);  // 30`;

const Functions = () => {
  const consoleOutput = [
    "function add(a: number, b: number): number { return a + b; }",
    "console.log(add(5, 3));",
    "8",
    "function getFullName(firstName: string, lastName?: string): string { return lastName ? firstName + ' ' + lastName : firstName; }",
    "console.log(getFullName('John'));",
    "John",
    "console.log(getFullName('John', 'Doe'));",
    "John Doe",
    "let myFunc: (x: number, y: number) => number = (a, b) => a * b;",
    "console.log(myFunc(4, 5));",
    "20"
  ];

  return (
    <main className="container mx-auto px-4 py-8">
      <TabNavigation />

      <section className="mb-12">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Functions in TypeScript</h2>
        <p className="text-gray-600 mb-6">
          Functions are the fundamental building block of any application in TypeScript. They can have typed parameters, return types, and additional features like optional parameters and rest parameters.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Basic Functions</h3>
            <p className="text-gray-600 mb-4">
              TypeScript provides various ways to define function parameters and return types:
            </p>
            
            <CodeEditor
              title="basic-functions.ts"
              code={basicFunctionsCode}
              language="typescript"
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Function Types and Expressions</h3>
            <p className="text-gray-600 mb-4">
              TypeScript allows you to define and use function types:
            </p>
            
            <CodeEditor
              title="function-types.ts"
              code={functionTypesCode}
              language="typescript"
              runnable={false}
            />
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Function Overloads</h3>
            <p className="text-gray-600 mb-4">
              Function overloads allow a single function to handle different parameter types and counts:
            </p>
            
            <CodeEditor
              title="function-overloads.ts"
              code={functionOverloadsCode}
              language="typescript"
              runnable={false}
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Try It Yourself</h3>
            <CodeConsole initialOutput={consoleOutput} />
          </div>
        </div>
      </section>

      <section className="mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Working with 'this' in Functions</h3>
            <p className="text-gray-600 mb-4">
              TypeScript provides type checking for 'this' in functions:
            </p>
            
            <CodeEditor
              title="this-in-functions.ts"
              code={thisInFunctionsCode}
              language="typescript"
              runnable={false}
            />

            <div className="bg-yellow-50 rounded-lg p-4 border-l-4 border-yellow-400 mt-6">
              <h4 className="font-medium text-yellow-800">Working with 'this'</h4>
              <ul className="text-sm text-yellow-700 list-disc pl-5 mt-2">
                <li>Use 'this' parameter annotations to ensure correct context</li>
                <li>Arrow functions preserve the lexical 'this'</li>
                <li>Methods in classes automatically have correct 'this' context</li>
                <li>Avoid using 'this' in standalone functions when possible</li>
              </ul>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Generic Functions</h3>
            <p className="text-gray-600 mb-4">
              Generic functions allow you to create reusable components that work with different types:
            </p>
            
            <CodeEditor
              title="generic-functions.ts"
              code={genericFunctionsCode}
              language="typescript"
              runnable={false}
            />
            
            <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-400 mt-6">
              <h4 className="font-medium text-blue-800">When to Use Generics</h4>
              <ul className="text-sm text-blue-700 list-disc pl-5 mt-2">
                <li>When creating reusable functions that work with multiple types</li>
                <li>For collections or containers that should preserve type information</li>
                <li>When the relationship between input and output types needs to be preserved</li>
                <li>With constraints when functions need to operate on specific capabilities</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Next Concepts to Explore</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Advanced Types</h3>
            <p className="text-gray-600 text-sm mb-4">Explore more complex type scenarios with conditional and mapped types.</p>
            <a href="/advanced-types" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Advanced Types →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Error Handling</h3>
            <p className="text-gray-600 text-sm mb-4">Learn robust patterns for handling errors in TypeScript functions.</p>
            <a href="/error-handling" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Error Handling →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Classes</h3>
            <p className="text-gray-600 text-sm mb-4">Understand how functions, methods, and constructors work in classes.</p>
            <a href="/classes" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Classes →</a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default Functions;
