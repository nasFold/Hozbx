import TabNavigation from "@/components/TabNavigation";
import CodeEditor from "@/components/CodeEditor";
import CodeConsole from "@/components/CodeConsole";

const basicClassCode = `// Basic class structure

class Person {
  // Properties with type annotations
  name: string;
  age: number;
  
  // Constructor
  constructor(name: string, age: number) {
    this.name = name;
    this.age = age;
  }
  
  // Method
  greet(): string {
    return \`Hello, my name is \${this.name} and I am \${this.age} years old.\`;
  }
  
  // Method with parameters
  celebrateBirthday(): void {
    this.age++;
    console.log(\`\${this.name} is now \${this.age} years old!\`);
  }
}

// Creating an instance
const john = new Person("John", 30);
console.log(john.greet()); // "Hello, my name is John and I am 30 years old."
john.celebrateBirthday(); // "John is now 31 years old!"`;

const inheritanceCode = `// Inheritance and Polymorphism

// Base class
class Animal {
  name: string;
  
  constructor(name: string) {
    this.name = name;
  }
  
  move(distance: number = 0): void {
    console.log(\`\${this.name} moved \${distance}m.\`);
  }
}

// Derived classes
class Dog extends Animal {
  constructor(name: string) {
    super(name); // Call the parent constructor
  }
  
  // Override the parent method
  move(distance: number = 5): void {
    console.log(\`\${this.name} barks!\`);
    super.move(distance); // Call the parent method
  }
  
  // Add new method
  bark(): void {
    console.log("Woof! Woof!");
  }
}

class Snake extends Animal {
  constructor(name: string) {
    super(name);
  }
  
  move(distance: number = 5): void {
    console.log(\`\${this.name} slithers...\`);
    super.move(distance);
  }
}

// Using the classes
const dog = new Dog("Rex");
const snake = new Snake("Sly");

dog.move(); // "Rex barks!" then "Rex moved 5m."
snake.move(); // "Sly slithers..." then "Sly moved 5m."
dog.bark(); // "Woof! Woof!"

// Polymorphic behavior
const animals: Animal[] = [new Dog("Rover"), new Snake("Sammy")];
animals.forEach(animal => animal.move()); // Each animal moves in its own way`;

const accessModifiersCode = `// Access Modifiers and Properties

class BankAccount {
  // Public: accessible from anywhere (default)
  public accountHolder: string;
  
  // Private: only accessible within the class
  private _balance: number;
  
  // Protected: accessible within the class and subclasses
  protected accountNumber: string;
  
  // Readonly: can only be set during initialization
  readonly bankName: string = "TypeScript Bank";
  
  constructor(holder: string, initialBalance: number) {
    this.accountHolder = holder;
    this._balance = initialBalance;
    this.accountNumber = Math.floor(Math.random() * 1000000).toString();
  }
  
  // Public method to access private property
  public getBalance(): number {
    return this._balance;
  }
  
  // Method to update private property
  public deposit(amount: number): void {
    if (amount <= 0) {
      throw new Error("Deposit amount must be positive");
    }
    this._balance += amount;
  }
  
  public withdraw(amount: number): boolean {
    if (amount <= 0) {
      throw new Error("Withdrawal amount must be positive");
    }
    
    if (amount > this._balance) {
      console.log("Insufficient funds");
      return false;
    }
    
    this._balance -= amount;
    return true;
  }
  
  // Protected method
  protected generateStatement(): string {
    return \`Account: ****\${this.accountNumber.slice(-4)}, Balance: $\${this._balance}\`;
  }
  
  // Public method that uses protected method
  public printStatement(): void {
    console.log(this.generateStatement());
  }
}

// Child class that extends BankAccount
class SavingsAccount extends BankAccount {
  private _interestRate: number;
  
  constructor(holder: string, initialBalance: number, interestRate: number) {
    super(holder, initialBalance);
    this._interestRate = interestRate;
  }
  
  // Override protected method
  protected generateStatement(): string {
    return \`\${super.generateStatement()}, Interest Rate: \${this._interestRate}%\`;
  }
  
  // Add method to apply interest
  public applyInterest(): void {
    const interest = this.getBalance() * (this._interestRate / 100);
    this.deposit(interest);
    console.log(\`Applied interest: $\${interest.toFixed(2)}\`);
  }
}

// Using the classes
const account = new BankAccount("John Doe", 1000);
account.deposit(500);
account.printStatement(); // Account: ****1234, Balance: $1500

const savings = new SavingsAccount("Jane Smith", 2000, 2.5);
savings.deposit(1000);
savings.applyInterest();
savings.printStatement(); // Account: ****5678, Balance: $3075, Interest Rate: 2.5%

// Error examples (commented out):
// console.log(account._balance); // Error: Property '_balance' is private
// console.log(account.accountNumber); // Error: Property 'accountNumber' is protected
// account.bankName = "Other Bank"; // Error: Cannot assign to 'bankName' because it is a read-only property`;

const abstractClassCode = `// Abstract Classes and Interfaces

// Interface definition
interface Payable {
  calculatePay(): number;
}

// Abstract class
abstract class Employee implements Payable {
  name: string;
  id: number;
  
  constructor(name: string, id: number) {
    this.name = name;
    this.id = id;
  }
  
  // Regular method
  displayInfo(): void {
    console.log(\`Employee: \${this.name}, ID: \${this.id}\`);
  }
  
  // Abstract method - must be implemented by subclasses
  abstract calculatePay(): number;
  
  // Abstract method with parameters
  abstract performWork(hours: number): void;
}

// Concrete subclass
class FullTimeEmployee extends Employee {
  annualSalary: number;
  
  constructor(name: string, id: number, salary: number) {
    super(name, id);
    this.annualSalary = salary;
  }
  
  // Implementation of abstract method
  calculatePay(): number {
    return this.annualSalary / 12; // Monthly pay
  }
  
  performWork(hours: number): void {
    console.log(\`\${this.name} worked \${hours} hours as a full-time employee\`);
  }
}

// Another concrete subclass
class PartTimeEmployee extends Employee {
  hourlyRate: number;
  hoursWorked: number = 0;
  
  constructor(name: string, id: number, hourlyRate: number) {
    super(name, id);
    this.hourlyRate = hourlyRate;
  }
  
  calculatePay(): number {
    return this.hourlyRate * this.hoursWorked;
  }
  
  performWork(hours: number): void {
    this.hoursWorked += hours;
    console.log(\`\${this.name} worked \${hours} hours as a part-time employee\`);
  }
}

// Cannot instantiate abstract class
// const employee = new Employee("Test", 123); // Error

// Using the concrete classes
const fullTime = new FullTimeEmployee("John", 101, 60000);
fullTime.displayInfo();
fullTime.performWork(40);
console.log(\`Monthly pay: $\${fullTime.calculatePay().toFixed(2)}\`);

const partTime = new PartTimeEmployee("Jane", 102, 15);
partTime.displayInfo();
partTime.performWork(25);
console.log(\`Pay: $\${partTime.calculatePay().toFixed(2)}\`);`;

const gettersSettersCode = `// Getters and Setters

class Product {
  private _name: string;
  private _price: number;
  private _discount: number = 0;
  
  constructor(name: string, price: number) {
    this._name = name;
    this._price = price;
  }
  
  // Getter for name
  get name(): string {
    return this._name;
  }
  
  // Setter for name
  set name(newName: string) {
    if (newName.trim() === "") {
      throw new Error("Product name cannot be empty");
    }
    this._name = newName;
  }
  
  // Getter for price
  get price(): number {
    return this._price;
  }
  
  // Setter for price with validation
  set price(newPrice: number) {
    if (newPrice <= 0) {
      throw new Error("Price must be greater than zero");
    }
    this._price = newPrice;
  }
  
  // Getter for discount
  get discount(): number {
    return this._discount;
  }
  
  // Setter for discount with validation
  set discount(value: number) {
    if (value < 0 || value > 100) {
      throw new Error("Discount must be between 0 and 100");
    }
    this._discount = value;
  }
  
  // Computed property
  get discountedPrice(): number {
    return this._price * (1 - this._discount / 100);
  }
  
  displayInfo(): void {
    console.log(\`Product: \${this._name}\`);
    console.log(\`Original Price: $\${this._price.toFixed(2)}\`);
    if (this._discount > 0) {
      console.log(\`Discount: \${this._discount}%\`);
      console.log(\`Discounted Price: $\${this.discountedPrice.toFixed(2)}\`);
    }
  }
}

// Using the class
const laptop = new Product("Laptop", 1200);
laptop.displayInfo();

laptop.discount = 15; // Set discount to 15%
laptop.displayInfo();

// Using getters and setters
console.log(\`Product name: \${laptop.name}\`);
laptop.name = "Gaming Laptop"; // Setting a new name

// Error examples (commented out):
// laptop.price = -500; // Error: Price must be greater than zero
// laptop.discount = 110; // Error: Discount must be between 0 and 100
// laptop.discountedPrice = 1000; // Error: Cannot assign to 'discountedPrice' because it is a read-only property`;

const Classes = () => {
  const consoleOutput = [
    "class Car { make: string; year: number; constructor(make: string, year: number) { this.make = make; this.year = year; } }",
    "let myCar = new Car('Toyota', 2020);",
    "console.log(myCar);",
    "Car { make: 'Toyota', year: 2020 }",
    "myCar.year = 2021;",
    "console.log(myCar);",
    "Car { make: 'Toyota', year: 2021 }",
    "class ElectricCar extends Car { range: number; constructor(make: string, year: number, range: number) { super(make, year); this.range = range; } }",
    "let tesla = new ElectricCar('Tesla', 2022, 300);",
    "console.log(tesla);",
    "ElectricCar { make: 'Tesla', year: 2022, range: 300 }"
  ];

  return (
    <main className="container mx-auto px-4 py-8">
      <TabNavigation />

      <section className="mb-12">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Classes in TypeScript</h2>
        <p className="text-gray-600 mb-6">
          TypeScript offers full support for class-based object-oriented programming with features like inheritance, 
          access modifiers, and abstract classes. TypeScript classes compile down to standard JavaScript functions.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Basic Class Structure</h3>
            <p className="text-gray-600 mb-4">
              Classes in TypeScript have properties, methods, and constructors with strong typing:
            </p>
            
            <CodeEditor
              title="basic-class.ts"
              code={basicClassCode}
              language="typescript"
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Inheritance and Polymorphism</h3>
            <p className="text-gray-600 mb-4">
              Classes can inherit from other classes, override methods, and implement polymorphic behavior:
            </p>
            
            <CodeEditor
              title="inheritance.ts"
              code={inheritanceCode}
              language="typescript"
              runnable={false}
            />
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Access Modifiers and Properties</h3>
            <p className="text-gray-600 mb-4">
              TypeScript has three access modifiers to control visibility: public, private, and protected:
            </p>
            
            <CodeEditor
              title="access-modifiers.ts"
              code={accessModifiersCode}
              language="typescript"
              runnable={false}
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3 mt-6">Try It Yourself</h3>
            <CodeConsole initialOutput={consoleOutput} />
          </div>
        </div>
      </section>

      <section className="mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Abstract Classes</h3>
            <p className="text-gray-600 mb-4">
              Abstract classes provide a base class that cannot be instantiated but can define implementation details for subclasses:
            </p>
            
            <CodeEditor
              title="abstract-class.ts"
              code={abstractClassCode}
              language="typescript"
              runnable={false}
            />
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Getters and Setters</h3>
            <p className="text-gray-600 mb-4">
              TypeScript supports getters and setters to control access to class properties:
            </p>
            
            <CodeEditor
              title="getters-setters.ts"
              code={gettersSettersCode}
              language="typescript"
              runnable={false}
            />
            
            <div className="bg-yellow-50 rounded-lg p-4 border-l-4 border-yellow-400 mt-6">
              <h4 className="font-medium text-yellow-800">Best Practices</h4>
              <ul className="text-sm text-yellow-700 list-disc pl-5 mt-2">
                <li>Use private properties with getters/setters to encapsulate internal state</li>
                <li>Implement validation logic in setters</li>
                <li>Consider using readonly properties for immutable values</li>
                <li>Use abstract classes to share common functionality while enforcing API contract</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Next Concepts to Explore</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Functions</h3>
            <p className="text-gray-600 text-sm mb-4">Learn how to define and work with typed functions.</p>
            <a href="/functions" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Functions →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Advanced Types</h3>
            <p className="text-gray-600 text-sm mb-4">Master generic classes and advanced type systems.</p>
            <a href="/advanced-types" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Advanced Types →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Error Handling</h3>
            <p className="text-gray-600 text-sm mb-4">Learn TypeScript patterns for robust error handling.</p>
            <a href="/error-handling" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Error Handling →</a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default Classes;
