import TabNavigation from "@/components/TabNavigation";
import CodeEditor from "@/components/CodeEditor";
import CodeConsole from "@/components/CodeConsole";

const basicInterfaceCode = `// Interface basics

// Interface definition
interface User {
  id: number;
  name: string;
  email: string;
  isActive: boolean;
}

// Using the interface
const user: User = {
  id: 1,
  name: "John Doe",
  email: "john@example.com",
  isActive: true
};

// Function using interface as parameter type
function updateUser(id: number, userInfo: User): User {
  // Update logic here
  return { ...userInfo, id };
}

// Interface extending another interface
interface Employee extends User {
  department: string;
  salary: number;
}

const employee: Employee = {
  id: 2,
  name: "Jane Smith",
  email: "jane@example.com",
  isActive: true,
  department: "Engineering",
  salary: 85000
};`;

const optionalPropertiesCode = `// Optional and readonly properties

interface RegistrationForm {
  email: string;
  password: string;
  displayName?: string;      // Optional property
  readonly agreedToTerms: boolean;  // Can't be changed after creation
  preferences?: {
    theme: string;
    notifications: boolean;
  };
}

const newUser: RegistrationForm = {
  email: "user@example.com",
  password: "securePassword123",
  // displayName is optional, so it can be omitted
  agreedToTerms: true  // This can't be changed later
};

// Add optional property later
newUser.displayName = "CoolUser42";

// This would be an error:
// newUser.agreedToTerms = false; // Cannot assign to 'agreedToTerms' because it is a read-only property`;

const interfaceVsTypeCode = `// Interface vs Type Alias

// Interface
interface UserInterface {
  id: number;
  name: string;
}

// Type alias
type UserType = {
  id: number;
  name: string;
};

// Both can be used similarly
const user1: UserInterface = { id: 1, name: "Alice" };
const user2: UserType = { id: 2, name: "Bob" };

// Extending interfaces
interface AdminInterface extends UserInterface {
  permissions: string[];
}

// Extending types
type AdminType = UserType & {
  permissions: string[];
};

// Interface declaration merging (can add properties)
interface UserInterface {
  email: string; // Now UserInterface has id, name, and email
}

// Type aliases cannot be reopened to add new properties
// type UserType = { ... } // Error: Duplicate identifier 'UserType'`;

const indexSignaturesCode = `// Index signatures for dynamic properties

// Interface with index signature
interface Dictionary {
  [key: string]: string;
}

const colors: Dictionary = {
  red: "#ff0000",
  green: "#00ff00",
  blue: "#0000ff"
};

// We can add any string key
colors.purple = "#800080";
colors["yellow"] = "#ffff00";

// Mixed property types with index signatures
interface EmployeeRecord {
  id: number;
  name: string;
  [key: string]: string | number | boolean; // Must accommodate all possible value types
}

const record: EmployeeRecord = {
  id: 101,
  name: "Alice Henderson",
  department: "Engineering",
  isManager: true,
  yearsEmployed: 5
};`;

const Interfaces = () => {
  const consoleOutput = [
    "interface Person { name: string; age: number; }",
    "let alice: Person = { name: 'Alice', age: 30 };",
    "console.log(alice);",
    "{ name: 'Alice', age: 30 }",
    "alice.age = 31;",
    "console.log(alice);",
    "{ name: 'Alice', age: 31 }",
    "alice = { name: 'Alice' };",
    "Error: Property 'age' is missing in type '{ name: string; }' but required in type 'Person'."
  ];

  return (
    <main className="container mx-auto px-4 py-8">
      <TabNavigation />

      <section className="mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Interfaces in TypeScript</h2>
            <p className="text-gray-600 mb-6">
              Interfaces define the structure of objects in TypeScript, creating contracts that classes and objects must adhere to.
              They help provide strong type-checking and documentation.
            </p>

            <CodeEditor
              title="basic-interface.ts"
              code={basicInterfaceCode}
              language="typescript"
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3">Optional and Readonly Properties</h3>
            <p className="text-gray-600 mb-6">
              Interfaces can have optional properties (marked with ?) and readonly properties that cannot be modified after creation:
            </p>

            <CodeEditor
              title="optional-properties.ts"
              code={optionalPropertiesCode}
              language="typescript"
              runnable={false}
            />

            <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-400 mt-6">
              <h4 className="font-medium text-blue-800">When to Use Interfaces</h4>
              <ul className="text-sm text-blue-700 list-disc pl-5 mt-2">
                <li>Defining object shapes and class contracts</li>
                <li>When you need declaration merging</li>
                <li>For public API definitions</li>
                <li>When extending other interfaces</li>
              </ul>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Interface vs Type Alias</h2>
            <p className="text-gray-600 mb-4">
              While interfaces and type aliases can be used similarly, they have different capabilities:
            </p>

            <CodeEditor
              title="interface-vs-type.ts"
              code={interfaceVsTypeCode}
              language="typescript"
              runnable={false}
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3">Index Signatures</h3>
            <p className="text-gray-600 mb-4">
              You can define dynamic property names using index signatures:
            </p>

            <CodeEditor
              title="index-signatures.ts"
              code={indexSignaturesCode}
              language="typescript"
              runnable={false}
            />

            <h3 className="text-lg font-semibold text-gray-800 mb-3">Try It Yourself</h3>
            <CodeConsole initialOutput={consoleOutput} />
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Next Concepts to Explore</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Classes</h3>
            <p className="text-gray-600 text-sm mb-4">Learn how classes implement interfaces and inheritance in TypeScript.</p>
            <a href="/classes" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Classes →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Functions</h3>
            <p className="text-gray-600 text-sm mb-4">See how to use interfaces to type function parameters and return values.</p>
            <a href="/functions" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Functions →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Advanced Types</h3>
            <p className="text-gray-600 text-sm mb-4">Learn about mapped types, conditional types, and type manipulation.</p>
            <a href="/advanced-types" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Advanced Types →</a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default Interfaces;
