import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";

const Home = () => {
  return (
    <main className="container mx-auto px-4 py-8">
      <section className="mb-12">
        <div className="bg-white rounded-lg shadow-md p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            TypeScript Core Concepts
          </h2>
          <p className="text-gray-600 mb-6">
            TypeScript extends JavaScript by adding static type definitions, helping developers catch errors early and build more robust applications.
            This interactive guide will walk you through TypeScript's essential features with practical examples.
          </p>

          <div className="bg-blue-50 border-l-4 border-[#3178c6] p-4 mb-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg
                  className="h-5 w-5 text-[#3178c6]"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-700">
                  <strong>Pro tip:</strong> You can run and experiment with these
                  examples in the TypeScript Playground or in your local development
                  environment.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-100 p-5 rounded-md">
              <h3 className="font-medium text-gray-800 mb-2">Static Type Checking</h3>
              <p className="text-gray-600 text-sm">
                Catch errors during development rather than runtime
              </p>
            </div>
            <div className="bg-gray-100 p-5 rounded-md">
              <h3 className="font-medium text-gray-800 mb-2">Enhanced IDE Support</h3>
              <p className="text-gray-600 text-sm">
                Improved code completion and navigation
              </p>
            </div>
            <div className="bg-gray-100 p-5 rounded-md">
              <h3 className="font-medium text-gray-800 mb-2">
                ECMAScript Compatibility
              </h3>
              <p className="text-gray-600 text-sm">
                Use new JavaScript features with backward compatibility
              </p>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold text-gray-800 mb-4">
          Explore TypeScript Concepts
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white shadow-md border border-gray-100">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-2">Basic Types</h3>
              <p className="text-gray-600 text-sm mb-4">
                Learn about TypeScript's primitive types, arrays, tuples, and type annotations.
              </p>
              <Link href="/basic-types">
                <a className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">
                  Explore Basic Types →
                </a>
              </Link>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-md border border-gray-100">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-2">Interfaces & Type Aliases</h3>
              <p className="text-gray-600 text-sm mb-4">
                Learn how to define complex object shapes and create reusable type definitions.
              </p>
              <Link href="/interfaces">
                <a className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">
                  Explore Interfaces →
                </a>
              </Link>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-md border border-gray-100">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-2">Classes & OOP Features</h3>
              <p className="text-gray-600 text-sm mb-4">
                Understand TypeScript's implementation of classes, inheritance, and access modifiers.
              </p>
              <Link href="/classes">
                <a className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">
                  Explore Classes →
                </a>
              </Link>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-md border border-gray-100">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-2">Functions</h3>
              <p className="text-gray-600 text-sm mb-4">
                Learn about function types, parameters, return types, and function overloads.
              </p>
              <Link href="/functions">
                <a className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">
                  Explore Functions →
                </a>
              </Link>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-md border border-gray-100">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-2">Advanced Types</h3>
              <p className="text-gray-600 text-sm mb-4">
                Master generics, conditional types, and utility types for complex scenarios.
              </p>
              <Link href="/advanced-types">
                <a className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">
                  Explore Advanced Types →
                </a>
              </Link>
            </CardContent>
          </Card>
          <Card className="bg-white shadow-md border border-gray-100">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-2">Error Handling</h3>
              <p className="text-gray-600 text-sm mb-4">
                Learn TypeScript patterns for error handling, nullability and assertions.
              </p>
              <Link href="/error-handling">
                <a className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">
                  Explore Error Handling →
                </a>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
};

export default Home;
