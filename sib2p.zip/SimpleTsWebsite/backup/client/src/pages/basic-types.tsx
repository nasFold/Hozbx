import { useState } from "react";
import TabNavigation from "@/components/TabNavigation";
import CodeEditor from "@/components/CodeEditor";
import CodeConsole from "@/components/CodeConsole";

const basicTypesCode = `// Basic Types in TypeScript

// Boolean
let isComplete: boolean = true;

// Number
let decimal: number = 6;
let hex: number = 0xf00d;
let binary: number = 0b1010;

// String
let color: string = "blue";
let greeting: string = \`Hello, my name is \${name}\`;  // Template string

// Array
let list: number[] = [1, 2, 3];
let names: Array<string> = ["John", "Jane"]; // Generic array type

// Tuple
let person: [string, number] = ["Alice", 25]; // Fixed structure

// Enum
enum Color {Red, Green, Blue};
let c: Color = Color.Green;

// Any - avoid when possible
let notSure: any = 4;
notSure = "maybe a string";

// Void
function logMessage(message: string): void {
  console.log(message);
}

// Null and Undefined
let u: undefined = undefined;
let n: null = null;

// Never - represents values that never occur
function error(message: string): never {
  throw new Error(message);
}

// Object
let user: object = {name: "John", age: 30};

// Type assertions
let someValue: any = "this is a string";
let strLength: number = (someValue as string).length;
`;

const typeInferenceCode = `// Type inference examples

// TypeScript infers these types automatically
let x = 3;            // inferred as number
let y = [1, 2, 3];    // inferred as number[]
let z = "hello";      // inferred as string

// Type error would occur here:
// x = "string"; // Error: Type 'string' is not assignable to type 'number'`;

const typeCompatibilityCode = `// Type compatibility examples

interface Pet {
  name: string;
}

// Dog has all properties of Pet (and more)
interface Dog {
  name: string;
  breed: string;
}

let pet: Pet;
let dog: Dog = { name: "Rover", breed: "Labrador" };

// Dog is assignable to Pet because it has all required properties
pet = dog; // OK

// But Pet is not assignable to Dog
// dog = pet; // Error: Property 'breed' is missing`;

const unionIntersectionCode = `// Union and intersection types

interface Bird {
  fly(): void;
  layEggs(): void;
}

interface Fish {
  swim(): void;
  layEggs(): void;
}

// Union type - can be either type
type Pet = Bird | Fish;

function getSmallPet(): Pet {
  // ...
  return {
    layEggs: () => {},
    swim: () => {}
  } as Fish;
}

let pet = getSmallPet();
pet.layEggs(); // OK
// pet.swim();  // Error: Property 'swim' does not exist on type 'Bird | Fish'

// Type guard to narrow the type
if ('swim' in pet) {
  pet.swim(); // OK, TypeScript knows pet is Fish here
}

// Intersection type - has all properties of both types
type Amphibian = Bird & Fish;

let amphibian: Amphibian = {
  fly: () => {},
  layEggs: () => {},
  swim: () => {}
};

// Can access all methods
amphibian.fly();
amphibian.swim();`;

const BasicTypes = () => {
  const [consoleOutput] = useState([
    "let x: number = 10;",
    "let y: string = \"Hello\";",
    "console.log(x);",
    "10",
    "console.log(y);",
    "Hello",
    "x = \"world\";",
    "Error: Type 'string' is not assignable to type 'number'.",
    "let z: number | string = \"TypeScript\";",
    "z = 42; // This is valid",
    "console.log(z);",
    "42"
  ]);

  return (
    <main className="container mx-auto px-4 py-8">
      <TabNavigation />
      
      <section className="mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Basic Types in TypeScript</h2>
            <p className="text-gray-600 mb-6">
              TypeScript supports all JavaScript's primitive types and adds additional type-checking capabilities.
              Here are examples of basic type declarations:
            </p>

            <CodeEditor
              title="basic-types.ts"
              code={basicTypesCode}
              language="typescript"
            />
            
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Using Type Inference</h3>
            <p className="text-gray-600 mb-6">
              TypeScript can infer types when variables are initialized. This creates more concise code while maintaining type safety:
            </p>

            <CodeEditor
              title="type-inference.ts"
              code={typeInferenceCode}
              language="typescript"
              runnable={false}
            />
            
            <div className="bg-yellow-50 rounded-lg p-4 border-l-4 border-yellow-400">
              <h4 className="font-medium text-yellow-800">Best Practice</h4>
              <p className="text-sm text-yellow-700">Use explicit type annotations when the type is not obvious from initialization, or to document intent for future developers.</p>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Type Compatibility</h2>
            <p className="text-gray-600 mb-4">
              TypeScript uses structural typing to determine if types are compatible, focusing on the shape of objects rather than their declared type:
            </p>
            
            <CodeEditor
              title="type-compatibility.ts"
              code={typeCompatibilityCode}
              language="typescript"
              runnable={false}
            />
            
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Union and Intersection Types</h3>
            <p className="text-gray-600 mb-4">
              TypeScript allows combining types in flexible ways:
            </p>
            
            <CodeEditor
              title="union-intersection-types.ts"
              code={unionIntersectionCode}
              language="typescript"
              runnable={false}
            />
            
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Try It Yourself</h3>
            <CodeConsole initialOutput={consoleOutput} />
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Next Concepts to Explore</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Interfaces & Type Aliases</h3>
            <p className="text-gray-600 text-sm mb-4">Learn how to define complex object shapes and create reusable type definitions.</p>
            <a href="/interfaces" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Interfaces →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Classes & OOP Features</h3>
            <p className="text-gray-600 text-sm mb-4">Understand TypeScript's implementation of classes, inheritance, and access modifiers.</p>
            <a href="/classes" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Classes →</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <h3 className="font-semibold text-lg mb-2">Generics</h3>
            <p className="text-gray-600 text-sm mb-4">Master creating reusable components that work with any data type while maintaining type safety.</p>
            <a href="/advanced-types" className="text-[#3178c6] hover:text-[#235a97] font-medium text-sm">Explore Generics →</a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default BasicTypes;
