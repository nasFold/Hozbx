import { db } from "./index";
import * as schema from "@shared/schema";
import { categories, codeExamples } from "@shared/schema";

async function seed() {
  try {
    console.log("Seeding database with TypeScript examples...");
    
    // Insert categories
    const categoryData = [
      {
        name: "Basic Types",
        slug: "basic-types",
        description: "Core primitive and basic types in TypeScript",
        order: 1
      },
      {
        name: "Interfaces",
        slug: "interfaces",
        description: "Type definitions for object shapes",
        order: 2
      },
      {
        name: "Classes",
        slug: "classes",
        description: "Object-oriented programming with classes",
        order: 3
      },
      {
        name: "Functions",
        slug: "functions",
        description: "Function declarations, expressions, and types",
        order: 4
      },
      {
        name: "Advanced Types",
        slug: "advanced-types",
        description: "Generics, conditional types, and type manipulation",
        order: 5
      },
      {
        name: "Error Handling",
        slug: "error-handling",
        description: "Error handling patterns and techniques",
        order: 6
      }
    ];
    
    // First check if categories already exist
    const existingCategories = await db.query.categories.findMany();
    
    if (existingCategories.length === 0) {
      console.log("Inserting categories...");
      await db.insert(categories).values(categoryData);
    } else {
      console.log("Categories already exist, skipping insertion.");
    }
    
    // Check if code examples already exist
    const existingExamples = await db.query.codeExamples.findMany();
    
    if (existingExamples.length === 0) {
      console.log("Inserting code examples...");
      
      // Basic Types examples
      await db.insert(codeExamples).values([
        {
          title: "Primitive Types",
          description: "Basic primitive types in TypeScript",
          code: `// Boolean
let isComplete: boolean = true;

// Number
let decimal: number = 6;
let hex: number = 0xf00d;
let binary: number = 0b1010;

// String
let color: string = "blue";
let greeting: string = \`Hello, my name is \${name}\`;  // Template string

// Null and Undefined
let u: undefined = undefined;
let n: null = null;`,
          language: "typescript",
          category: "basic-types",
          tags: ["basics", "primitives"]
        },
        {
          title: "Arrays and Tuples",
          description: "Working with collections of data",
          code: `// Array
let list: number[] = [1, 2, 3];
let names: Array<string> = ["John", "Jane"]; // Generic array type

// Tuple
let person: [string, number] = ["Alice", 25]; // Fixed structure
`,
          language: "typescript",
          category: "basic-types",
          tags: ["basics", "arrays", "tuples"]
        },
        {
          title: "Enums",
          description: "Enumerated types in TypeScript",
          code: `// Enum
enum Color {Red, Green, Blue};
let c: Color = Color.Green; // 1

// Enum with custom values
enum HttpStatus {
  OK = 200,
  NotFound = 404,
  InternalServerError = 500
}
let status: HttpStatus = HttpStatus.OK; // 200`,
          language: "typescript",
          category: "basic-types",
          tags: ["basics", "enums"]
        }
      ]);
      
      // Interface examples
      await db.insert(codeExamples).values([
        {
          title: "Basic Interface",
          description: "Interface definition and usage",
          code: `// Interface definition
interface User {
  id: number;
  name: string;
  email: string;
  isActive: boolean;
}

// Using the interface
const user: User = {
  id: 1,
  name: "John Doe",
  email: "john@example.com",
  isActive: true
};`,
          language: "typescript",
          category: "interfaces",
          tags: ["interfaces", "objects"]
        },
        {
          title: "Optional Properties",
          description: "Interfaces with optional and readonly properties",
          code: `interface RegistrationForm {
  email: string;
  password: string;
  displayName?: string;      // Optional property
  readonly agreedToTerms: boolean;  // Can't be changed after creation
}

const newUser: RegistrationForm = {
  email: "user@example.com",
  password: "securePassword123",
  // displayName is optional, so it can be omitted
  agreedToTerms: true  // This can't be changed later
};`,
          language: "typescript",
          category: "interfaces",
          tags: ["interfaces", "optional", "readonly"]
        }
      ]);
      
      // Class examples
      await db.insert(codeExamples).values([
        {
          title: "Basic Class",
          description: "Class definition with properties and methods",
          code: `class Person {
  // Properties with type annotations
  name: string;
  age: number;
  
  // Constructor
  constructor(name: string, age: number) {
    this.name = name;
    this.age = age;
  }
  
  // Method
  greet(): string {
    return \`Hello, my name is \${this.name} and I am \${this.age} years old.\`;
  }
}

// Creating an instance
const john = new Person("John", 30);
console.log(john.greet()); // "Hello, my name is John and I am 30 years old."`,
          language: "typescript",
          category: "classes",
          tags: ["classes", "oop"]
        },
        {
          title: "Class Inheritance",
          description: "Inheritance and polymorphism with classes",
          code: `class Animal {
  name: string;
  
  constructor(name: string) {
    this.name = name;
  }
  
  move(distance: number = 0): void {
    console.log(\`\${this.name} moved \${distance}m.\`);
  }
}

class Dog extends Animal {
  constructor(name: string) {
    super(name); // Call the parent constructor
  }
  
  // Override the parent method
  move(distance: number = 5): void {
    console.log(\`\${this.name} barks!\`);
    super.move(distance); // Call the parent method
  }
  
  // Add new method
  bark(): void {
    console.log("Woof! Woof!");
  }
}`,
          language: "typescript",
          category: "classes",
          tags: ["classes", "inheritance", "polymorphism"]
        }
      ]);
      
      // Function examples
      await db.insert(codeExamples).values([
        {
          title: "Function Types",
          description: "Function type expressions",
          code: `// Function type expression
type MathFunction = (x: number, y: number) => number;

// Arrow function with explicit type
const multiply: MathFunction = (a, b) => a * b;

// Function as parameter using inline type
function applyOperation(a: number, b: number, operation: (x: number, y: number) => number): number {
  return operation(a, b);
}`,
          language: "typescript",
          category: "functions",
          tags: ["functions", "types"]
        },
        {
          title: "Function Overloads",
          description: "Function overloading in TypeScript",
          code: `// Overload signatures
function process(value: number): number;
function process(value: string): string;

// Implementation signature - must be compatible with all overloads
function process(value: number | string): number | string {
  if (typeof value === "number") {
    return value * 2;
  } else {
    return value.toUpperCase();
  }
}

// Using the overloaded function
console.log(process(42));       // 84
console.log(process("hello"));  // "HELLO"`,
          language: "typescript",
          category: "functions",
          tags: ["functions", "overloads"]
        }
      ]);
      
      // Advanced Types examples
      await db.insert(codeExamples).values([
        {
          title: "Generics",
          description: "Generic types and functions",
          code: `// Generic function with a single type parameter
function identity<T>(arg: T): T {
  return arg;
}

// Generic interface
interface Box<T> {
  value: T;
}

// Using generics
const numBox: Box<number> = { value: 42 };
const strBox: Box<string> = { value: "hello" };`,
          language: "typescript",
          category: "advanced-types",
          tags: ["generics", "advanced"]
        },
        {
          title: "Conditional Types",
          description: "Types that depend on type conditions",
          code: `// Basic conditional type
type TypeName<T> = 
  T extends string ? "string" :
  T extends number ? "number" :
  T extends boolean ? "boolean" :
  T extends undefined ? "undefined" :
  T extends Function ? "function" :
  "object";

// Extracting return type with infer
type ReturnType<T> = T extends (...args: any[]) => infer R ? R : any;`,
          language: "typescript",
          category: "advanced-types",
          tags: ["conditional-types", "advanced"]
        }
      ]);
      
      // Error Handling examples
      await db.insert(codeExamples).values([
        {
          title: "Try-Catch Blocks",
          description: "Basic error handling with try-catch",
          code: `// Standard JavaScript try-catch block with typed errors
function divide(a: number, b: number): number {
  if (b === 0) {
    throw new Error("Division by zero is not allowed");
  }
  return a / b;
}

try {
  const result = divide(10, 0);
  console.log(result);
} catch (error) {
  // In TypeScript, error is of type 'unknown' in catch blocks
  if (error instanceof Error) {
    console.error(\`Error message: \${error.message}\`);
  } else {
    console.error("An unexpected error occurred");
  }
}`,
          language: "typescript",
          category: "error-handling",
          tags: ["error-handling", "try-catch"]
        },
        {
          title: "Result Pattern",
          description: "Functional approach to error handling",
          code: `// Result type pattern
type Result<T, E = Error> = 
  | { success: true; value: T }
  | { success: false; error: E };

function divide(a: number, b: number): Result<number> {
  if (b === 0) {
    return { 
      success: false, 
      error: new Error("Division by zero") 
    };
  }
  
  return { 
    success: true, 
    value: a / b 
  };
}

// Using the Result type
const result = divide(10, 2);

if (result.success) {
  console.log("Result:", result.value);
} else {
  console.error("Error:", result.error.message);
}`,
          language: "typescript",
          category: "error-handling",
          tags: ["error-handling", "result-pattern", "functional"]
        }
      ]);
      
      console.log("Seeding complete!");
    } else {
      console.log("Code examples already exist, skipping insertion.");
    }
    
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
