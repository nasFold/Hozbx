import { db } from "../db";
import { codeExamples, categories, CodeExample, InsertCodeExample } from "../shared/schema";
import { eq, like, and, or, asc, desc } from "drizzle-orm";
import { SQL, sql } from "drizzle-orm";

export const storage = {
  // Categories
  async getAllCategories() {
    return await db.query.categories.findMany({
      orderBy: asc(categories.order)
    });
  },
  
  async getCategoryBySlug(slug: string) {
    return await db.query.categories.findFirst({
      where: eq(categories.slug, slug)
    });
  },
  
  // Code Examples
  async getAllCodeExamples() {
    return await db.query.codeExamples.findMany({
      orderBy: [
        asc(codeExamples.category),
        desc(codeExamples.created_at)
      ]
    });
  },
  
  async getCodeExamplesByCategory(categorySlug: string) {
    return await db.query.codeExamples.findMany({
      where: eq(codeExamples.category, categorySlug),
      orderBy: desc(codeExamples.created_at)
    });
  },
  
  async getCodeExampleById(id: number) {
    return await db.query.codeExamples.findFirst({
      where: eq(codeExamples.id, id)
    });
  },
  
  async searchCodeExamples(query?: string, categorySlug?: string) {
    let conditions: SQL[] = [];
    
    if (query) {
      conditions.push(
        or(
          like(codeExamples.title, `%${query}%`),
          like(codeExamples.description, `%${query}%`),
          like(codeExamples.code, `%${query}%`)
        )
      );
    }
    
    if (categorySlug) {
      conditions.push(eq(codeExamples.category, categorySlug));
    }
    
    if (conditions.length === 0) {
      return await this.getAllCodeExamples();
    }
    
    let whereCondition = conditions[0];
    for (let i = 1; i < conditions.length; i++) {
      whereCondition = and(whereCondition, conditions[i]);
    }
    
    return await db.query.codeExamples.findMany({
      where: whereCondition,
      orderBy: desc(codeExamples.created_at)
    });
  },
  
  async createCodeExample(data: InsertCodeExample) {
    const newExample = await db.insert(codeExamples)
      .values({
        ...data,
        created_at: new Date(),
        updated_at: new Date()
      })
      .returning();
      
    return newExample[0];
  },
  
  async updateCodeExample(id: number, data: Partial<InsertCodeExample>) {
    const updated = await db.update(codeExamples)
      .set({
        ...data,
        updated_at: new Date()
      })
      .where(eq(codeExamples.id, id))
      .returning();
      
    return updated[0];
  },
  
  async deleteCodeExample(id: number) {
    return await db.delete(codeExamples)
      .where(eq(codeExamples.id, id));
  }
};
