import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { CodeExample, InsertCodeExample, insertCodeExampleSchema } from "../shared/schema";
import { eq } from "drizzle-orm";
import { db } from "../db";
import { codeExamples, categories } from "../shared/schema";
import { z } from "zod";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const result = await storage.getAllCategories();
      res.json(result);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get code examples by category
  app.get("/api/categories/:slug/examples", async (req, res) => {
    try {
      const { slug } = req.params;
      const result = await storage.getCodeExamplesByCategory(slug);
      
      if (!result.length) {
        return res.status(404).json({ message: `No examples found for category: ${slug}` });
      }
      
      res.json(result);
    } catch (error) {
      console.error(`Error fetching examples for category ${req.params.slug}:`, error);
      res.status(500).json({ message: "Failed to fetch code examples" });
    }
  });

  // Get a specific code example by ID
  app.get("/api/examples/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const example = await storage.getCodeExampleById(id);
      
      if (!example) {
        return res.status(404).json({ message: "Code example not found" });
      }
      
      res.json(example);
    } catch (error) {
      console.error(`Error fetching example ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to fetch code example" });
    }
  });

  // Search code examples
  app.get("/api/examples", async (req, res) => {
    try {
      const query = req.query.q as string | undefined;
      const category = req.query.category as string | undefined;
      
      if (!query && !category) {
        const allExamples = await storage.getAllCodeExamples();
        return res.json(allExamples);
      }
      
      const results = await storage.searchCodeExamples(query, category);
      res.json(results);
    } catch (error) {
      console.error("Error searching examples:", error);
      res.status(500).json({ message: "Failed to search code examples" });
    }
  });

  // Create a new code example (admin functionality)
  app.post("/api/examples", async (req, res) => {
    try {
      const validatedData = insertCodeExampleSchema.parse(req.body);
      
      // Check if category exists
      const categoryExists = await db.query.categories.findFirst({
        where: eq(categories.slug, validatedData.category)
      });
      
      if (!categoryExists) {
        return res.status(400).json({ message: "Invalid category" });
      }
      
      const newExample = await storage.createCodeExample(validatedData);
      res.status(201).json(newExample);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      
      console.error("Error creating code example:", error);
      res.status(500).json({ message: "Failed to create code example" });
    }
  });

  // Update a code example (admin functionality)
  app.patch("/api/examples/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Partial validation of the request body
      const validationSchema = insertCodeExampleSchema.partial();
      const validatedData = validationSchema.parse(req.body);
      
      // Check if example exists
      const existingExample = await storage.getCodeExampleById(id);
      
      if (!existingExample) {
        return res.status(404).json({ message: "Code example not found" });
      }
      
      // Check if category exists if it's being updated
      if (validatedData.category) {
        const categoryExists = await db.query.categories.findFirst({
          where: eq(categories.slug, validatedData.category)
        });
        
        if (!categoryExists) {
          return res.status(400).json({ message: "Invalid category" });
        }
      }
      
      const updatedExample = await storage.updateCodeExample(id, validatedData);
      res.json(updatedExample);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      
      console.error(`Error updating example ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to update code example" });
    }
  });

  // Delete a code example (admin functionality)
  app.delete("/api/examples/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Check if example exists
      const existingExample = await storage.getCodeExampleById(id);
      
      if (!existingExample) {
        return res.status(404).json({ message: "Code example not found" });
      }
      
      await storage.deleteCodeExample(id);
      res.status(204).send();
    } catch (error) {
      console.error(`Error deleting example ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to delete code example" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
